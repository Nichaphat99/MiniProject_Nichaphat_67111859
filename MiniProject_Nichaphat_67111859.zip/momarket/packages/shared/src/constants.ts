// ค่าคงที่ที่ใช้ร่วมกันทั้ง frontend และ backend

export const ALLOWED_EMAIL_DOMAIN = 'dpu.ac.th';

/* ---------- ประเภทและหมวดหมู่ ---------- */

export const LISTING_TYPES = ['PRODUCT', 'SERVICE'] as const;
export type ListingType = (typeof LISTING_TYPES)[number];

export const LISTING_TYPE_LABELS: Record<ListingType, string> = {
  PRODUCT: 'ซื้อขายสินค้า',
  SERVICE: 'บริการและรับจ้าง',
};

export const PRODUCT_SUBCATEGORIES = [
  'FOOD',
  'CLOTHING',
  'STATIONERY',
  'COSMETICS',
  'HANDMADE',
  'GENERAL',
] as const;

export const SERVICE_SUBCATEGORIES = [
  'PROXY_ORDER',
  'PHOTOGRAPHY',
  'VIDEO_EDITING',
  'GRAPHIC_DESIGN',
] as const;

export const ALL_SUBCATEGORIES = [...PRODUCT_SUBCATEGORIES, ...SERVICE_SUBCATEGORIES] as const;
export type Subcategory = (typeof ALL_SUBCATEGORIES)[number];

export const SUBCATEGORY_LABELS: Record<Subcategory, string> = {
  FOOD: 'ของกิน',
  CLOTHING: 'เสื้อผ้า',
  STATIONERY: 'อุปกรณ์การเรียน',
  COSMETICS: 'เครื่องสำอาง',
  HANDMADE: 'งานแฮนด์เมด',
  GENERAL: 'ของใช้ทั่วไป',
  PROXY_ORDER: 'บริการรับหิ้ว / พรีออเดอร์',
  PHOTOGRAPHY: 'บริการถ่ายภาพ',
  VIDEO_EDITING: 'บริการตัดต่อวิดีโอ',
  GRAPHIC_DESIGN: 'บริการออกแบบกราฟิก',
};

/** หมวดย่อยที่ต้องติ๊กยืนยันว่าเป็นผลงานของตนเอง */
export const OWN_WORK_SUBCATEGORIES: readonly Subcategory[] = [
  'PHOTOGRAPHY',
  'VIDEO_EDITING',
  'GRAPHIC_DESIGN',
];

export function typeOfSubcategory(sub: Subcategory): ListingType {
  return (PRODUCT_SUBCATEGORIES as readonly string[]).includes(sub) ? 'PRODUCT' : 'SERVICE';
}

/* ---------- สภาพสินค้า / สถานะ ---------- */

export const CONDITIONS = ['NEW', 'USED'] as const;
export type Condition = (typeof CONDITIONS)[number];
export const CONDITION_LABELS: Record<Condition, string> = {
  NEW: 'มือ 1',
  USED: 'มือ 2',
};

export const LISTING_STATUSES = ['ACTIVE', 'SOLD'] as const;
export type ListingStatus = (typeof LISTING_STATUSES)[number];
export const LISTING_STATUS_LABELS: Record<ListingStatus, string> = {
  ACTIVE: 'กำลังขายอยู่',
  SOLD: 'ขายแล้ว',
};

/* ---------- จุดนัดรับ ---------- */

export const MEETUP_LOCATIONS: readonly string[] = [
  ...Array.from({ length: 22 }, (_, i) => `อาคาร ${i + 1}`),
  'อาคารเกตุพิทักษ์',
  'โรงอาหาร',
  'DPU Place',
  'ศูนย์กีฬา',
  'สนามฟุตบอล',
  'ลานจอดรถ',
];

/* ---------- พื้นที่รับงาน (บริการถ่ายภาพ) ---------- */

export const SERVICE_AREA_TYPES = ['ON_CAMPUS', 'OFF_CAMPUS'] as const;
export type ServiceAreaType = (typeof SERVICE_AREA_TYPES)[number];
export const SERVICE_AREA_LABELS: Record<ServiceAreaType, string> = {
  ON_CAMPUS: 'ในมหาวิทยาลัย',
  OFF_CAMPUS: 'นอกมหาวิทยาลัย (ระบุสถานที่)',
};

/* ---------- รายงาน ---------- */

export const REPORT_REASONS = [
  'NOT_AS_DESCRIBED',
  'NO_SHOW',
  'CLAIMING_OTHERS_WORK',
  'PROHIBITED_ITEM',
  'FAKE_CONTACT',
] as const;
export type ReportReason = (typeof REPORT_REASONS)[number];
export const REPORT_REASON_LABELS: Record<ReportReason, string> = {
  NOT_AS_DESCRIBED: 'ขายของไม่ตรงปก',
  NO_SHOW: 'เบี้ยวนัด / ไม่มารับของ',
  CLAIMING_OTHERS_WORK: 'แอบอ้างผลงาน',
  PROHIBITED_ITEM: 'สินค้าผิดกฎ',
  FAKE_CONTACT: 'คอนแทคไม่มีตัวตน',
};

export const REPORT_STATUSES = ['PENDING', 'RESOLVED', 'DISMISSED'] as const;
export type ReportStatus = (typeof REPORT_STATUSES)[number];
export const REPORT_STATUS_LABELS: Record<ReportStatus, string> = {
  PENDING: 'รอตรวจสอบ',
  RESOLVED: 'ดำเนินการแล้ว',
  DISMISSED: 'ไม่พบความผิด',
};

/* ---------- ขีดจำกัดต่าง ๆ ---------- */

export const MAX_IMAGES = 5;
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB ต่อรูป
export const ALLOWED_IMAGE_MIME = ['image/jpeg', 'image/png', 'image/webp'] as const;
export const BUMP_COOLDOWN_HOURS = 24;
export const WARNING_BANNER_DAYS = 30;
export const TEMP_BAN_DAYS = 7;

/* ---------- ข้อความมาตรฐาน ---------- */

export const COMMUNITY_RULES: readonly string[] = [
  'ใช้งานได้เฉพาะนักศึกษาและบุคลากรของมหาวิทยาลัยธุรกิจบัณฑิตย์ (DPU) ที่มีอีเมล @dpu.ac.th',
  'momarket เป็นเพียงตัวกลางลงประกาศ ไม่มีระบบชำระเงิน ไม่มีตะกร้าสินค้า และไม่มีแชทในเว็บ — การตกลงซื้อขายทำนอกเว็บระหว่างผู้ซื้อและผู้ขายเอง',
  'นัดรับสินค้าและนัดพบเฉพาะในพื้นที่มหาวิทยาลัยตามจุดที่ระบุในประกาศเท่านั้น',
  'ห้ามลงขายสินค้าหรือบริการที่ผิดกฎหมาย ผิดระเบียบมหาวิทยาลัย หรือละเมิดลิขสิทธิ์',
  'ห้ามแอบอ้างผลงานของผู้อื่น ห้ามใช้ช่องทางติดต่อปลอม และห้ามเบี้ยวนัด',
  'ผู้ที่ฝ่าฝืนอาจได้รับคำเตือน ถูกแบนชั่วคราว 7 วัน หรือถูกแบนถาวร และประกาศอาจถูกลบโดยผู้ดูแลระบบ',
];

export const SAFETY_NOTICES: readonly string[] = [
  'momarket ไม่มีระบบชำระเงินผ่านเว็บไซต์ การชำระเงินและการส่งมอบเป็นเรื่องที่ตกลงกันเองระหว่างผู้ซื้อกับผู้ขาย',
  'ให้นัดรับในพื้นที่มหาวิทยาลัยตามจุดนัดรับที่ระบุเท่านั้น',
  'หากพบความไม่เหมาะสม สามารถกดปุ่ม “รายงานประกาศนี้” ได้ทันที',
];

export const PROXY_ORDER_WARNING =
  'บริการรับหิ้ว / พรีออเดอร์ มักต้องโอนเงินล่วงหน้าก่อนได้รับสินค้า ซึ่งมีความเสี่ยงที่จะถูกโกง ควรตรวจสอบประวัติผู้ขาย ขอดูหลักฐาน และโอนเท่าที่จำเป็น momarket ไม่รับผิดชอบความเสียหายจากการโอนเงิน';

/* ---------- อิโมจิประกอบหมวดหมู่ ---------- */

export const TYPE_EMOJI: Record<ListingType, string> = { PRODUCT: '🛍️', SERVICE: '🧑‍💻' };

export const SUBCATEGORY_EMOJI: Record<Subcategory, string> = {
  FOOD: '🍜',
  CLOTHING: '👕',
  STATIONERY: '✏️',
  COSMETICS: '💄',
  HANDMADE: '🧶',
  GENERAL: '🧺',
  PROXY_ORDER: '🛵',
  PHOTOGRAPHY: '📷',
  VIDEO_EDITING: '🎬',
  GRAPHIC_DESIGN: '🎨',
};

export const CONDITION_EMOJI: Record<Condition, string> = { NEW: '✨', USED: '♻️' };

export const REPORT_REASON_EMOJI: Record<ReportReason, string> = {
  NOT_AS_DESCRIBED: '📦',
  NO_SHOW: '⏰',
  CLAIMING_OTHERS_WORK: '🎭',
  PROHIBITED_ITEM: '🚫',
  FAKE_CONTACT: '👻',
};

/** "🍜 ของกิน" */
export const subcategoryLabel = (s: Subcategory) => `${SUBCATEGORY_EMOJI[s]} ${SUBCATEGORY_LABELS[s]}`;

export function meetupEmoji(location: string): string {
  if (location.startsWith('อาคาร')) return '🏢';
  switch (location) {
    case 'โรงอาหาร':
      return '🍱';
    case 'DPU Place':
      return '🏬';
    case 'ศูนย์กีฬา':
      return '🏋️';
    case 'สนามฟุตบอล':
      return '⚽';
    case 'ลานจอดรถ':
      return '🅿️';
    default:
      return '📍';
  }
}

/* ---------- ชื่อที่แสดง ---------- */

/** แก้ชื่อได้ทุกกี่วัน (ตั้งครั้งแรก + แก้ภายใน 1 ชั่วโมงแรกไม่นับ) */
export const DISPLAY_NAME_COOLDOWN_DAYS = 30;
export const DISPLAY_NAME_GRACE_MINUTES = 60;
/** ชื่อที่แอบอ้างเป็นผู้ดูแลระบบ — ผู้ใช้ทั่วไปตั้งไม่ได้ */
export const RESERVED_NAME_PATTERN = /admin|แอดมิน|ผู้ดูแล|momarket|มอมาร์เก็ต/i;

/** ช่วงเวลา "ใหม่" บนการ์ด (ชั่วโมง) */
export const NEW_BADGE_HOURS = 24;
