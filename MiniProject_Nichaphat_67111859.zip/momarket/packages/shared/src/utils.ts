import { ALLOWED_EMAIL_DOMAIN } from './constants';

/** ตัดช่องว่าง คืน undefined ถ้าว่าง */
export const clean = (s?: string | null): string | undefined => {
  const t = s?.trim();
  return t ? t : undefined;
};

/** ตัด @ นำหน้า (สำหรับ Instagram username) */
export const stripAt = (s?: string): string | undefined => (s ? s.replace(/^@+/, '') : s);

export function isDpuEmail(email: string): boolean {
  const e = email.trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+$/.test(e) && e.endsWith(`@${ALLOWED_EMAIL_DOMAIN}`);
}

/** แปลงเป็น URL เฉพาะ https และไม่มี username/password ฝังมา */
export function parseHttpsUrl(value: string): URL | null {
  try {
    const u = new URL(value.trim());
    if (u.protocol !== 'https:' || u.username || u.password) return null;
    return u;
  } catch {
    return null;
  }
}

export function isHttpsUrlOnHosts(value: string, hosts: readonly string[]): boolean {
  const u = parseHttpsUrl(value);
  return !!u && hosts.includes(u.hostname.toLowerCase());
}

/** ใช้ก่อนใส่ href ใน frontend */
export const isHttpsUrl = (value?: string | null): value is string =>
  !!value && parseHttpsUrl(value) !== null;

export const FACEBOOK_HOSTS = [
  'facebook.com',
  'www.facebook.com',
  'm.facebook.com',
  'web.facebook.com',
  'fb.com',
  'www.fb.com',
  'fb.me',
] as const;

export const VIDEO_HOSTS = [
  'youtube.com',
  'www.youtube.com',
  'm.youtube.com',
  'youtu.be',
  'tiktok.com',
  'www.tiktok.com',
  'vm.tiktok.com',
  'vt.tiktok.com',
  'drive.google.com',
] as const;

/** ช่องทางติดตามคำสั่งซื้อ (รับหิ้ว/พรีออเดอร์): OpenChat, LINE, IG, FB */
export const TRACKING_HOSTS = [
  'line.me',
  'lin.ee',
  'instagram.com',
  'www.instagram.com',
  ...FACEBOOK_HOSTS,
  'm.me',
] as const;

/** ดึง video id จากลิงก์ YouTube (watch / youtu.be / shorts / embed / live) */
export function youtubeVideoId(value?: string | null): string | null {
  if (!value) return null;
  const u = parseHttpsUrl(value);
  if (!u) return null;
  const host = u.hostname.toLowerCase();
  let id: string | null = null;
  if (host === 'youtu.be') {
    id = u.pathname.split('/')[1] ?? null;
  } else if (['youtube.com', 'www.youtube.com', 'm.youtube.com'].includes(host)) {
    if (u.pathname === '/watch') {
      id = u.searchParams.get('v');
    } else {
      const m = u.pathname.match(/^\/(?:shorts|embed|live)\/([^/?#]+)/);
      id = m?.[1] ?? null;
    }
  }
  return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
}

/** ภาพปกอัตโนมัติ (ใช้ได้เฉพาะ YouTube; TikTok/Drive ให้ผู้ใช้อัปโหลดภาพปกเอง) */
export function youtubeThumbnail(value?: string | null): string | null {
  const id = youtubeVideoId(value);
  return id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : null;
}

/** เลขนักศึกษา = ส่วนหน้า @ ของอีเมล เมื่อเป็นตัวเลข 8-12 หลัก (บุคลากรจะได้ null) */
export function studentIdFromEmail(email: string): string | null {
  const m = email.trim().toLowerCase().match(/^(\d{8,12})@dpu\.ac\.th$/);
  return m ? m[1]! : null;
}

/** "สมชาย ใจดี · 6512345678" */
export const sellerLabel = (name: string, studentId: string | null) => (studentId ? `${name} · ${studentId}` : name);
