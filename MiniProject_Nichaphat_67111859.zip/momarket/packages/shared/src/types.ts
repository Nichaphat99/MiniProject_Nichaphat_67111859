import type {
  Condition,
  ListingStatus,
  ListingType,
  ReportReason,
  ReportStatus,
  ServiceAreaType,
  Subcategory,
} from './constants';

export type Role = 'USER' | 'ADMIN';
export type AccountStatus = 'ACTIVE' | 'TEMP_BANNED' | 'PERMANENT_BANNED';

export interface PublicUser {
  id: string;
  /** ชื่อที่ผู้ใช้ตั้งเอง (หรือชื่อจากบัญชี DPU ถ้ายังไม่ได้ตั้ง) */
  name: string;
  /** เลขนักศึกษา (ส่วนหน้า @ ของอีเมล) — บุคลากรเป็น null */
  studentId: string | null;
  avatarUrl: string | null;
}

export interface SessionUser extends PublicUser {
  email: string;
  role: Role;
  /** true = ยังไม่ได้ตั้งชื่อ ต้องตั้งก่อนใช้งาน */
  needsProfile: boolean;
  /** วันที่แก้ชื่อได้ครั้งถัดไป (null = แก้ได้เลย) */
  nextNameChangeAt: string | null;
}

export interface WarningDTO {
  id: string;
  message: string;
  createdAt: string;
  acknowledgedAt: string | null;
}

export interface AuthMeResponse {
  user: SessionUser;
  pendingWarnings: WarningDTO[];
  /** คำเตือนที่ออกภายในช่วงที่ต้องแสดงแถบแจ้งเตือน (ดู WARNING_BANNER_DAYS) */
  recentWarningCount: number;
}

export interface AuthConfig {
  google: { clientId: string } | null;
  microsoft: { clientId: string; tenantId: string } | null;
  devLogin: boolean;
}

export interface ListingCardDTO {
  id: string;
  type: ListingType;
  subcategory: Subcategory;
  title: string;
  price: number;
  status: ListingStatus;
  meetupLocation: string;
  coverUrl: string | null;
  bumpedAt: string;
  createdAt: string;
}

export interface ListingDetailDTO extends ListingCardDTO {
  description: string;
  condition: Condition | null;
  meetupNote: string | null;
  contactLine: string | null;
  contactInstagram: string | null;
  contactFacebook: string | null;
  imageUrls: string[];
  videoUrl: string | null;
  waitDays: number | null;
  trackingUrl: string | null;
  ownWorkConfirmed: boolean;
  serviceAreaType: ServiceAreaType | null;
  serviceAreaDetail: string | null;
  updatedAt: string;
  deletedAt: string | null;
  seller: PublicUser;
  isOwner: boolean;
}

export interface MyListingDTO extends ListingCardDTO {
  /** null = ดันได้ตอนนี้ */
  nextBumpAt: string | null;
}

export interface SellerProfileDTO {
  user: PublicUser;
  joinedAt: string;
  activeCount: number;
  soldCount: number;
  items: ListingCardDTO[];
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

/* ---------- Admin ---------- */

export interface DayCount {
  /** YYYY-MM-DD (เวลาไทย) */
  day: string;
  count: number;
}

export interface AdminOverview {
  kpis: {
    totalUsers: number;
    newUsers7d: number;
    activeListings: number;
    soldListings: number;
    pendingReports: number;
    bannedUsers: number;
  };
  usersPerDay: DayCount[];
  listingsPerDay: DayCount[];
  listingsByCategory: { subcategory: Subcategory; count: number }[];
  reportsByReason: { reason: ReportReason; count: number }[];
}

export interface AdminUserDTO {
  id: string;
  name: string;
  studentId: string | null;
  email: string;
  role: Role;
  accountStatus: AccountStatus;
  bannedUntil: string | null;
  listingCount: number;
  warningCount: number;
  reportCount: number;
  createdAt: string;
  lastLoginAt: string;
}

export interface ReportSnapshot {
  type: ListingType;
  subcategory: Subcategory;
  title: string;
  description: string;
  price: number;
  imageUrls: string[];
  meetupLocation: string;
  meetupNote: string | null;
  contactLine: string | null;
  contactInstagram: string | null;
  contactFacebook: string | null;
  videoUrl: string | null;
  trackingUrl: string | null;
}

export interface AdminReportDTO {
  id: string;
  reason: ReportReason;
  detail: string | null;
  status: ReportStatus;
  createdAt: string;
  resolvedAt: string | null;
  resolutionNote: string | null;
  resolvedByName: string | null;
  reporter: { id: string; name: string; studentId: string | null; email: string };
  reportedUser: {
    id: string;
    name: string;
    studentId: string | null;
    email: string;
    role: Role;
    accountStatus: AccountStatus;
    bannedUntil: string | null;
    warningCount: number;
    reportCount: number;
  };
  listing: { id: string; title: string; deleted: boolean };
  snapshot: ReportSnapshot;
}

export interface ApiErrorBody {
  message: string;
  code?: string;
  issues?: { path: string; message: string }[];
  [key: string]: unknown;
}
