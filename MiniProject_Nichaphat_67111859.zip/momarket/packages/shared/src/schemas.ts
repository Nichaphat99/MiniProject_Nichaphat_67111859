import { z } from 'zod';
import {
  ALL_SUBCATEGORIES,
  CONDITIONS,
  LISTING_STATUSES,
  LISTING_TYPES,
  MAX_IMAGES,
  MEETUP_LOCATIONS,
  PRODUCT_SUBCATEGORIES,
  REPORT_REASONS,
  SERVICE_AREA_TYPES,
} from './constants';
import {
  FACEBOOK_HOSTS,
  TRACKING_HOSTS,
  VIDEO_HOSTS,
  isDpuEmail,
  isHttpsUrlOnHosts,
  youtubeThumbnail,
} from './utils';

/* ---------- ตัวช่วย ---------- */

const emptyToUndef = (v: unknown) => (typeof v === 'string' && v.trim() === '' ? undefined : v);

/** string ที่ไม่บังคับ: ค่าว่างถือว่าไม่กรอก */
const optionalText = (max: number, msg?: string) =>
  z.preprocess(emptyToUndef, z.string().trim().max(max, msg ?? `ยาวเกิน ${max} ตัวอักษร`).optional());

const imageUrl = z.string().regex(/^\/uploads\/[A-Za-z0-9-]+\.webp$/, 'รูปภาพไม่ถูกต้อง');

const meetupLocation = z
  .string({ required_error: 'กรุณาเลือกจุดนัดรับ' })
  .refine((v) => MEETUP_LOCATIONS.includes(v), 'กรุณาเลือกจุดนัดรับ');

/* ---------- ช่องทางติดต่อ (Smart Contact) ---------- */

const contactLine = optionalText(30).pipe(
  z
    .string()
    .regex(/^[A-Za-z0-9._-]{2,30}$/, 'Line ID ใช้ได้เฉพาะ a-z 0-9 . _ - (2-30 ตัว)')
    .optional(),
);

const contactInstagram = z.preprocess(
  (v) => {
    if (typeof v !== 'string') return v;
    const t = v.trim().replace(/^@+/, '');
    return t === '' ? undefined : t;
  },
  z
    .string()
    .regex(/^[A-Za-z0-9._]{1,30}$/, 'ชื่อ Instagram ใช้ได้เฉพาะ a-z 0-9 . _ (ไม่ต้องใส่ @)')
    .optional(),
);

const contactFacebook = z.preprocess(
  emptyToUndef,
  z
    .string()
    .trim()
    .max(300, 'ลิงก์ยาวเกินไป')
    .refine((v) => isHttpsUrlOnHosts(v, FACEBOOK_HOSTS), 'ต้องเป็นลิงก์ https ของ Facebook เท่านั้น')
    .optional(),
);

/* ---------- ฟิลด์พื้นฐานที่ทุกประกาศต้องมี ---------- */

const baseShape = {
  title: z
    .string({ required_error: 'กรุณากรอกชื่อ' })
    .trim()
    .min(2, 'ชื่อสั้นเกินไป')
    .max(100, 'ชื่อยาวเกิน 100 ตัวอักษร'),
  description: z
    .string({ required_error: 'กรุณากรอกรายละเอียด' })
    .trim()
    .min(1, 'กรุณากรอกรายละเอียด')
    .max(2000, 'รายละเอียดยาวเกิน 2,000 ตัวอักษร'),
  price: z
    .number({ required_error: 'กรุณากรอกราคา', invalid_type_error: 'กรุณากรอกราคาเป็นตัวเลข' })
    .int('ราคาต้องเป็นจำนวนเต็ม')
    .min(0, 'ราคาต้องไม่ติดลบ')
    .max(10_000_000, 'ราคาสูงเกินไป'),
  meetupLocation,
  meetupNote: optionalText(200),
  contactLine,
  contactInstagram,
  contactFacebook,
};

const ownWork = z.literal(true, {
  errorMap: () => ({ message: 'ต้องยืนยันว่าเป็นผลงานของตนเองจริง' }),
});

const images = (min: number, msg?: string) =>
  z
    .array(imageUrl)
    .min(min, msg ?? `กรุณาอัปโหลดรูปภาพอย่างน้อย ${min} รูป`)
    .max(MAX_IMAGES, `อัปโหลดได้สูงสุด ${MAX_IMAGES} รูป`);

/* ---------- ประกาศแต่ละประเภท ---------- */

const productSchema = z.object({
  ...baseShape,
  subcategory: z.enum(PRODUCT_SUBCATEGORIES, { errorMap: () => ({ message: 'กรุณาเลือกหมวดหมู่' }) }),
  condition: z.enum(CONDITIONS, { errorMap: () => ({ message: 'กรุณาเลือกสภาพสินค้า' }) }),
  images: images(1),
});

const proxyOrderSchema = z.object({
  ...baseShape,
  subcategory: z.literal('PROXY_ORDER'),
  waitDays: z
    .number({ required_error: 'กรุณากรอกระยะเวลารอสินค้า', invalid_type_error: 'กรุณากรอกเป็นตัวเลข' })
    .int('ต้องเป็นจำนวนเต็ม')
    .min(1, 'อย่างน้อย 1 วัน')
    .max(120, 'ไม่เกิน 120 วัน'),
  trackingUrl: z
    .string({ required_error: 'กรุณากรอกช่องทางติดตามคำสั่งซื้อ' })
    .trim()
    .max(300, 'ลิงก์ยาวเกินไป')
    .refine(
      (v) => isHttpsUrlOnHosts(v, TRACKING_HOSTS),
      'ต้องเป็นลิงก์ https ของ LINE OpenChat / Instagram / Facebook เท่านั้น',
    ),
  images: images(0),
});

const photographySchema = z.object({
  ...baseShape,
  subcategory: z.literal('PHOTOGRAPHY'),
  ownWorkConfirmed: ownWork,
  serviceAreaType: z.enum(SERVICE_AREA_TYPES, { errorMap: () => ({ message: 'กรุณาเลือกพื้นที่รับงาน' }) }),
  serviceAreaDetail: optionalText(200),
  images: images(1, 'กรุณาอัปโหลดตัวอย่างผลงานอย่างน้อย 1 รูป'),
});

const videoEditingSchema = z.object({
  ...baseShape,
  subcategory: z.literal('VIDEO_EDITING'),
  ownWorkConfirmed: ownWork,
  videoUrl: z
    .string({ required_error: 'กรุณาวางลิงก์วิดีโอผลงาน' })
    .trim()
    .max(500, 'ลิงก์ยาวเกินไป')
    .refine((v) => isHttpsUrlOnHosts(v, VIDEO_HOSTS), 'ต้องเป็นลิงก์ https ของ YouTube / TikTok / Google Drive เท่านั้น'),
  images: images(0).max(1, 'ภาพปกอัปโหลดได้ 1 รูป'),
});

const graphicDesignSchema = z.object({
  ...baseShape,
  subcategory: z.literal('GRAPHIC_DESIGN'),
  ownWorkConfirmed: ownWork,
  images: images(1, 'กรุณาอัปโหลดตัวอย่างผลงานอย่างน้อย 1 รูป'),
});

/**
 * ประกาศทั้งหมด แยกชนิดด้วย `subcategory`
 * (ฟอร์มฝั่ง frontend และ API ฝั่ง backend ใช้ schema ตัวเดียวกันนี้)
 */
export const listingInputSchema = z
  .discriminatedUnion('subcategory', [
    productSchema,
    proxyOrderSchema,
    photographySchema,
    videoEditingSchema,
    graphicDesignSchema,
  ])
  .superRefine((v, ctx) => {
    if (!v.contactLine && !v.contactInstagram && !v.contactFacebook) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['contact'],
        message: 'กรุณากรอกช่องทางติดต่ออย่างน้อย 1 ช่องทาง',
      });
    }
    if (v.subcategory === 'PHOTOGRAPHY' && v.serviceAreaType === 'OFF_CAMPUS' && !v.serviceAreaDetail) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['serviceAreaDetail'],
        message: 'กรุณาระบุสถานที่รับงานนอกมหาวิทยาลัย',
      });
    }
    if (v.subcategory === 'VIDEO_EDITING' && v.images.length === 0 && !youtubeThumbnail(v.videoUrl)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['images'],
        message: 'ลิงก์นี้ดึงภาพปกอัตโนมัติไม่ได้ กรุณาอัปโหลดภาพปก',
      });
    }
  });

export type ListingInput = z.infer<typeof listingInputSchema>;

/* ---------- Query / อื่น ๆ ---------- */

export const listingQuerySchema = z.object({
  type: z.enum(LISTING_TYPES),
  subcategory: z.enum(ALL_SUBCATEGORIES).optional(),
  q: z.string().trim().max(100).optional(),
  meetup: z.string().max(100).optional(),
  sort: z.enum(['newest', 'price_asc', 'price_desc']).default('newest'),
  hideSold: z
    .enum(['0', '1', 'true', 'false'])
    .optional()
    .transform((v) => v === '1' || v === 'true'),
  page: z.coerce.number().int().min(1).max(1000).default(1),
  limit: z.coerce.number().int().min(1).max(48).default(24),
});
export type ListingQuery = z.infer<typeof listingQuerySchema>;

export const statusChangeSchema = z.object({ status: z.enum(LISTING_STATUSES) });

export const reportInputSchema = z.object({
  reason: z.enum(REPORT_REASONS, { errorMap: () => ({ message: 'กรุณาเลือกเหตุผล' }) }),
  detail: optionalText(500),
});
export type ReportInput = z.infer<typeof reportInputSchema>;

/* ---------- Auth ---------- */

export const googleLoginSchema = z.object({ credential: z.string().min(20).max(5000) });
export const microsoftLoginSchema = z.object({ idToken: z.string().min(20).max(8000) });
export const devLoginSchema = z.object({
  email: z.string().trim().toLowerCase().refine(isDpuEmail, 'ต้องเป็นอีเมล @dpu.ac.th เท่านั้น'),
  name: optionalText(80),
});

/* ---------- Admin ---------- */

export const adminWarnSchema = z.object({
  message: z.string().trim().min(5, 'กรุณาระบุข้อความอย่างน้อย 5 ตัวอักษร').max(500),
  reportId: z.string().optional(),
});
export const adminBanSchema = z.object({
  reason: optionalText(300),
  reportId: z.string().optional(),
});
export const adminResolveSchema = z.object({
  status: z.enum(['RESOLVED', 'DISMISSED']),
  note: optionalText(500),
});
export const adminDeleteListingSchema = z.object({
  reportId: z.string().optional(),
});

/* ---------- โปรไฟล์ ---------- */

export const displayNameSchema = z.object({
  displayName: z.preprocess(
    (v) => (typeof v === 'string' ? v.trim().replace(/\s+/g, ' ') : v),
    z
      .string({ required_error: 'กรุณากรอกชื่อ' })
      .min(2, 'ชื่อสั้นเกินไป (อย่างน้อย 2 ตัวอักษร)')
      .max(40, 'ชื่อยาวเกิน 40 ตัวอักษร')
      .regex(/^[\p{L}\p{M}0-9 .'_-]+$/u, 'ใช้ได้เฉพาะตัวอักษร ตัวเลข และ . _ - เท่านั้น (ไม่ใช้อิโมจิหรือสัญลักษณ์พิเศษ)'),
  ),
});

/* ---------- Admin: รายชื่อผู้ใช้ ---------- */

export const adminUsersQuerySchema = z.object({
  q: z.string().trim().max(100).optional(),
  status: z.enum(['ALL', 'ACTIVE', 'BANNED', 'ADMIN']).default('ALL'),
  page: z.coerce.number().int().min(1).max(1000).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});
