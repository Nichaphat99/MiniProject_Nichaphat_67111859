# momarket (มอมาร์เก็ต)

แพลตฟอร์มตัวกลางซื้อขายสินค้าและบริการสำหรับนักศึกษาและบุคลากร **มหาวิทยาลัยธุรกิจบัณฑิตย์ (DPU)** เท่านั้น

- ไม่มีระบบชำระเงิน / ตะกร้าสินค้า / แชทในเว็บ — ผู้ซื้อกดปุ่ม Smart Contact (LINE / Instagram / Facebook) เพื่อออกไปคุยและนัดรับนอกเว็บ
- ไม่มีการอัปโหลดวิดีโอ — งานตัดต่อใช้ลิงก์ YouTube / TikTok / Google Drive (ดึงภาพปก YouTube ให้อัตโนมัติ ที่เหลือให้อัปโหลดภาพปกเอง)
- ล็อกอินได้เฉพาะอีเมล `@dpu.ac.th` (Google Workspace และ/หรือ Microsoft 365)

**Stack:** React 18 + TypeScript + Tailwind CSS v4 + Vite + Axios + Zod · Node.js + Express 5 + TypeScript + Zod + Prisma + PostgreSQL

---

## โครงสร้างโปรเจกต์ (npm workspaces)

```
momarket/
├─ packages/shared/        # Zod schemas + ค่าคงที่ (จุดนัดรับ, หมวดหมู่, เหตุผลรายงาน, ข้อความเตือน) ใช้ร่วมกันทั้งสองฝั่ง
├─ apps/api/               # Express API
│  ├─ prisma/              # schema.prisma, migrations (SQL), seed.ts
│  └─ src/                 # config, middleware, lib, routes
├─ apps/web/               # React + Vite
│  └─ src/                 # pages, components, context, lib
├─ docker-compose.yml      # PostgreSQL สำหรับพัฒนา
└─ package.json
```

ฟอร์มประกาศในหน้าเว็บและ API ใช้ `listingInputSchema` (Zod discriminated union ตาม `subcategory`) ตัวเดียวกัน
จึงตรวจเงื่อนไขเฉพาะหมวดตรงกันทั้งสองฝั่ง

---

## เริ่มใช้งาน (Development)

ต้องมี **Node.js ≥ 20.11** และ **Docker** (หรือ PostgreSQL 14+ ที่ติดตั้งเอง)

```bash
# 1) ติดตั้งแพ็กเกจ (จะรัน prisma generate ให้อัตโนมัติ)
npm install

# 2) ตั้งค่า environment ของ API
cp apps/api/.env.example apps/api/.env
#    แก้ SESSION_SECRET (openssl rand -base64 48) และ ADMIN_EMAILS ตามต้องการ

# 3) เปิดฐานข้อมูล + สร้างตาราง + seed
npm run db:up
npm run db:migrate
npm run db:seed          # สร้างบัญชีแอดมินจาก ADMIN_EMAILS
npm run db:seed:demo     # (ทางเลือก) เพิ่มผู้ขายและประกาศตัวอย่าง

# 4) รัน API (http://localhost:4000) + เว็บ (http://localhost:5173)
npm run dev
```

เปิด <http://localhost:5173> — ถ้า `DEV_LOGIN=true` (ค่าเริ่มต้นใน `.env.example`) จะมีฟอร์ม **ล็อกอินจำลอง** ด้วยอีเมล `@dpu.ac.th`
ใด ๆ ได้เลยโดยไม่ต้องตั้งค่า OAuth (ใช้ `momarket.admin@dpu.ac.th` เพื่อเข้าเมนูแอดมิน)

> `DEV_LOGIN` ถูกบังคับปิดเสมอเมื่อ `NODE_ENV=production`

> **ใช้ pgAdmin:** มีสคริปต์ SQL พร้อมรันในโฟลเดอร์ [`db/`](db/README.md) (สร้างฐานข้อมูล, ตาราง, ข้อมูลเริ่มต้น) และ `docker compose up -d` จะเปิด pgAdmin ที่ <http://localhost:5050> ให้ด้วย

> **ถ้า `prisma migrate dev` แจ้ง drift:** ไฟล์ `migration.sql` ถูกเขียนมือให้ตรงกับ `schema.prisma`
> หากพบความต่าง ให้ใช้ `npm run prisma:push -w @momarket/api` แทนในช่วงพัฒนา หรือสร้าง migration ใหม่ด้วย `prisma migrate dev`

---

## ตัวแปร environment (`apps/api/.env`)

| ตัวแปร | ความหมาย |
|---|---|
| `DATABASE_URL` | connection string ของ PostgreSQL |
| `SESSION_SECRET` | คีย์เซ็น cookie เซสชัน (≥ 32 ตัวอักษร) |
| `SESSION_DAYS` | อายุเซสชัน (วัน) ค่าเริ่มต้น 7 |
| `WEB_ORIGIN` | URL ที่ผู้ใช้เปิดเว็บ (ใช้ตรวจ Origin / CORS) |
| `TRUST_PROXY` | `1` ถ้าอยู่หลัง reverse proxy |
| `ADMIN_EMAILS` | อีเมลแอดมิน (คั่นด้วย `,`) — ถูกตั้งเป็น `ADMIN` ในฐานข้อมูลตอน seed และตอนล็อกอิน |
| `GOOGLE_CLIENT_ID` | เปิดปุ่ม Google ถ้าตั้งค่า |
| `MS_CLIENT_ID`, `MS_TENANT_ID` | เปิดปุ่ม Microsoft ถ้าตั้งครบทั้งสองค่า |
| `DEV_LOGIN` | ล็อกอินจำลอง (เฉพาะ non-production) |
| `UPLOAD_DIR` | โฟลเดอร์เก็บรูปที่อัปโหลด |

### ตั้งค่า Google (Google Workspace ของ DPU)
1. Google Cloud Console → APIs & Services → Credentials → **OAuth client ID** ชนิด *Web application*
2. เพิ่ม **Authorized JavaScript origins**: `http://localhost:5173` และโดเมนจริงของคุณ
3. นำ Client ID ไปใส่ `GOOGLE_CLIENT_ID`

ฝั่งเซิร์ฟเวอร์ตรวจ ID token ด้วย `google-auth-library` และบังคับ `email_verified = true`, อีเมลลงท้าย `@dpu.ac.th`
**และ** `hd = dpu.ac.th` (hosted domain ของ Workspace) — ถ้า DPU ใช้โดเมนเสริม (alias) ที่ `hd` ไม่ตรง ต้องปรับเงื่อนไขใน `apps/api/src/lib/providers.ts`

### ตั้งค่า Microsoft 365 (Entra ID)
1. Entra admin center → App registrations → New registration
2. Platform: **Single-page application (SPA)** → Redirect URI: `http://localhost:5173` และโดเมนจริง
3. ใส่ *Application (client) ID* ที่ `MS_CLIENT_ID` และ *Directory (tenant) ID* ของ DPU ที่ `MS_TENANT_ID`

ฝั่งเซิร์ฟเวอร์ตรวจลายเซ็น ID token ด้วย JWKS ของ tenant และผูก `issuer` กับ tenant ของ DPU เท่านั้น แล้วตรวจอีเมลลงท้าย `@dpu.ac.th`

---

## Deploy (production)

```bash
npm install
npm run build              # build เว็บเป็น apps/web/dist
npm run db:migrate         # สร้าง/อัปเดตตาราง (prisma migrate deploy)
npm run start              # Express เสิร์ฟทั้ง /api และเว็บที่ build แล้วในพอร์ตเดียว
```

- ตั้ง `NODE_ENV=production`, `WEB_ORIGIN=https://โดเมนของคุณ`, `TRUST_PROXY=1` (ถ้าอยู่หลัง proxy) และ **ใช้ HTTPS** (cookie เซสชันตั้ง `Secure` ใน production)
- **รูปอัปโหลดเก็บบนดิสก์** ที่ `UPLOAD_DIR` — ต้องเมานต์ volume ถาวร ไม่เช่นนั้นรูปจะหายเมื่อ deploy ใหม่
  (ถ้าต้องการย้ายไป S3 / Cloudflare R2 ให้แก้เฉพาะ `apps/api/src/lib/images.ts`)
- API รันด้วย `tsx` ทั้ง dev และ production เพราะ `@momarket/shared` เป็นซอร์ส TypeScript

---

## ฐานข้อมูล

| ตาราง | หน้าที่ |
|---|---|
| `User` | ผู้ใช้ — `role` (USER/ADMIN), `bannedUntil` (แบนชั่วคราว หมดอายุเอง), `isPermanentlyBanned` (แบนถาวร) **ไม่ลบแถวจริง** เพื่อให้อีเมลที่ถูกแบนถาวรสมัครใหม่ไม่ได้ |
| `Listing` | ประกาศทั้งสินค้าและบริการในตารางเดียว + คอลัมน์ nullable เฉพาะหมวด · `bumpedAt` ใช้เรียง feed · `deletedAt` = soft delete |
| `Report` | รายงาน — `snapshot` (JSONB) เก็บสำเนาเนื้อหา/คอนแทค ณ ตอนถูกรายงาน · unique `(listingId, reporterId)` |
| `Warning` | คำเตือน — `acknowledgedAt = null` คือยังไม่กดรับทราบ (แสดง Blocking Modal) |
| `ModerationLog` | บันทึกการกระทำของแอดมิน |

สถานะ `BANNED` ในสเปกถูกทำเป็น **สถานะบัญชีที่คำนวณจาก** `bannedUntil` / `isPermanentlyBanned` (ไม่ใช่ role) เพราะมีทั้งแบน 7 วันและแบนถาวร

---

## API (ทุกเส้นทางต้องล็อกอิน ยกเว้น `/api/auth/*`)

| Method | Path | หมายเหตุ |
|---|---|---|
| GET | `/api/auth/config` | ปุ่มล็อกอินที่เปิดใช้ |
| POST | `/api/auth/google` · `/microsoft` · `/dev-login` · `/logout` | |
| GET | `/api/auth/me` | ผู้ใช้ + คำเตือนที่ยังไม่รับทราบ |
| GET | `/api/listings?type=&subcategory=&q=&meetup=&sort=&hideSold=&page=&limit=` | feed |
| GET | `/api/listings/mine` | ประกาศของฉัน |
| POST / PUT / DELETE | `/api/listings` · `/:id` | สร้าง / แก้ไข / ลบ (soft) |
| PATCH | `/api/listings/:id/status` | ขายแล้ว ↔ กำลังขาย |
| POST | `/api/listings/:id/bump` | ดันประกาศ (cooldown 24 ชม. ตรวจแบบ atomic) |
| POST | `/api/listings/:id/reports` | รายงาน (1 คน/1 ประกาศ, รายงานของตัวเองไม่ได้) |
| POST | `/api/uploads` | multipart `files` (≤5 ไฟล์, ≤5MB) → แปลงเป็น WebP, หมุนตาม EXIF, ตัด metadata |
| GET / POST | `/api/warnings` · `/api/warnings/acknowledge` | ประวัติ / กดรับทราบ |
| GET | `/api/admin/overview` · `/api/admin/users` · `/api/admin/reports` | เฉพาะ ADMIN (ภาพรวม/กราฟ, รายชื่อผู้ใช้, รายงาน) |
| GET | `/api/users/:id` | โปรไฟล์ผู้ขาย (สาธารณะสำหรับผู้ล็อกอิน) |
| PATCH | `/api/auth/profile` | ตั้ง/เปลี่ยนชื่อที่แสดง (แก้ได้ทุก 30 วัน) |
| POST | `/api/admin/reports/:id/resolve` · `/admin/listings/:id/delete` | |
| POST | `/api/admin/users/:id/warn` · `/ban-temp` · `/ban-permanent` · `/unban` | |

## ความปลอดภัยที่ทำไว้

- ตรวจโดเมน `@dpu.ac.th` ที่เซิร์ฟเวอร์จาก ID token ที่ verify แล้วเท่านั้น
- เซสชันเป็น JWT ใน cookie `httpOnly` + `SameSite=Lax` (+ `Secure` ใน production) และตรวจ header `Origin` ของคำขอที่เปลี่ยนข้อมูล
- **ตรวจสถานะแบนจากฐานข้อมูลทุกคำขอ** — ผู้ที่ถูกแบนใช้โทเค็นเดิมต่อไม่ได้ และประกาศของผู้ถูกแบนจะถูกซ่อนจาก feed
- Rate limit (global / login / สร้างประกาศ / อัปโหลด / รายงาน), `helmet` + CSP
- ลิงก์ติดต่อ Facebook / วิดีโอ / ช่องทางติดตามรับหิ้ว ผ่าน whitelist โดเมนเท่านั้น (https) ส่วน LINE ID / IG จำกัดตัวอักษรและใช้ `encodeURIComponent` ตอนประกอบลิงก์
- อัปโหลดรูป: ตรวจชนิดไฟล์จริงด้วย `sharp` ไม่ใช่แค่นามสกุล ตั้งชื่อไฟล์เป็น UUID

## ข้อจำกัดที่รู้อยู่ / ต่อยอดได้

- รูปที่อัปโหลดแล้วแต่ไม่ได้บันทึกประกาศ (orphan) ยังไม่มีงานล้างอัตโนมัติ
- ยังไม่มีการลบบัญชี/ข้อมูลส่วนตัวด้วยตนเอง (PDPA) และยังไม่มีหน้าจัดการผู้ใช้แยก (จัดการผ่านตารางรายงาน)
- ยังไม่มีชุดทดสอบอัตโนมัติ (มี Zod schema ที่ทดสอบได้ง่ายใน `packages/shared`)
- feed ใช้ offset pagination + ปุ่ม “โหลดเพิ่ม” (พอสำหรับระดับมหาวิทยาลัย; หากข้อมูลโตมากค่อยย้ายเป็น cursor)


## อัปเดตรอบล่าสุด (v2)

- 🏠 หน้าแรก (Landing) แนะนำเว็บ + กฎกติกา → ตลาดย้ายไป `/market` มีเมนูหมวดหมู่ที่แถบนำทาง
- 🌌 ธีมมืดเต็มรูปแบบ พาเลต #0B0720 #25134D #6A2FC8 #9D71E8 #D1B8FF #F2E9FF ตัวอักษรคอนทราสต์สูง กรอบเรืองแสง
- 🪪 ตั้งชื่อที่แสดงตอนล็อกอินครั้งแรก (บังคับ) — ประกาศ/โปรไฟล์แสดง **ชื่อ + รหัสนักศึกษา** (ส่วนหน้า @ ของอีเมล)
- 🛡️ แอดมินลงประกาศไม่ได้ (ทั้งฝั่งหน้าเว็บและ API ตอบ 403 `ADMIN_CANNOT_SELL`)
- 📊 แดชบอร์ดแอดมิน: เมนูซ้าย · ตัวเลขสำคัญด้านบน · กราฟด้านล่าง · หน้ารายชื่อผู้ใช้ (ค้นหา/กรอง/เตือน/แบน)
- ✨ ปุ่มแชร์ลิงก์ 🔗 · ป้าย 🆕/🔥 + hover เรืองแสง · Hero ไล่สี + อีโมจิลอย · หน้าโปรไฟล์ผู้ขาย `/sellers/:id`

**อัปเกรดฐานข้อมูลเดิม:** รัน `db/04_display_name.sql` ใน pgAdmin (หรือ `prisma migrate deploy`) เพื่อเพิ่มคอลัมน์ `displayName`
