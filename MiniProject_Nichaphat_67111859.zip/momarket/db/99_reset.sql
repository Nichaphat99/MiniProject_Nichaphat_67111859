-- ⚠️ ลบตารางและ enum ทั้งหมดของ momarket (ข้อมูลหายหมด) ใช้เมื่อต้องการเริ่มใหม่เท่านั้น
DROP TABLE IF EXISTS "ModerationLog", "Warning", "Report", "Listing", "User" CASCADE;
DROP TYPE IF EXISTS "ReportStatus", "ReportReason", "ServiceAreaType", "ListingStatus", "Condition", "Subcategory", "ListingType", "Role";
