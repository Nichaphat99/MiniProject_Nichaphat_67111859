-- รันไฟล์นี้ก่อน โดยเชื่อมต่อฐานข้อมูล "postgres" (ฐานข้อมูลเริ่มต้นของเซิร์ฟเวอร์)
-- pgAdmin: คลิกขวา Databases > Create > Database... หรือเปิด Query Tool ที่ฐานข้อมูล postgres แล้วรันบรรทัดล่างนี้
-- (ถ้าใช้ docker-compose ของโปรเจกต์ ฐานข้อมูล momarket ถูกสร้างให้แล้ว ข้ามไฟล์นี้ได้)
CREATE DATABASE momarket WITH ENCODING 'UTF8' TEMPLATE template0;
