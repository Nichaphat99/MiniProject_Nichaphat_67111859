# ตั้งค่าฐานข้อมูลด้วย pgAdmin

1. **เชื่อมต่อเซิร์ฟเวอร์** — pgAdmin > Register > Server  
   (ถ้าใช้ `docker compose up -d` ของโปรเจกต์: host `localhost`, port `5432`, user `momarket`, password `momarket`)
   หรือเปิด pgAdmin ที่ <http://localhost:5050> (อีเมล `admin@momarket.local` / รหัส `admin`) แล้ว Register Server ด้วย host `postgres`
2. **สร้างฐานข้อมูล** — รัน `01_create_database.sql` (ข้ามได้ถ้าใช้ docker-compose เพราะสร้างให้แล้ว)
3. **สร้างตาราง** — คลิกขวาฐานข้อมูล `momarket` > Query Tool > Open File > `02_schema.sql` > Execute (F5)
4. **ใส่ข้อมูลเริ่มต้น** — รัน `03_seed.sql` (แอดมิน + ข้อมูลตัวอย่าง)
5. ตรวจผล: `SELECT count(*) FROM "Listing";` ควรได้ 8

## ใช้ร่วมกับ Prisma
สร้างตารางด้วย SQL แล้ว **ไม่ต้องรัน** `npm run db:migrate` ถ้าต้องการให้ Prisma รู้ว่าตารางมีแล้ว ให้รัน:

```bash
cd apps/api && npx prisma migrate resolve --applied 20261119000000_init
```
แล้วตั้ง `DATABASE_URL` ใน `apps/api/.env` ให้ชี้ฐานข้อมูลเดียวกัน (`?schema=public`) จากนั้น `npm run dev` ได้เลย

## 04_display_name.sql (อัปเกรดรอบ v2)

รันหลัง 02/03 (หรือบนฐานข้อมูลเดิม) — เพิ่มคอลัมน์ `displayName`, `displayNameChangedAt`, ตั้งชื่อแอดมิน และซ่อนประกาศที่แอดมินเคยลงไว้ รันซ้ำได้ปลอดภัย
