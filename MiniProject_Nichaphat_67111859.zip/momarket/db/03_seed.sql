-- momarket: ข้อมูลเริ่มต้น (รันหลัง 02_schema.sql)

-- 1) บัญชีแอดมิน — แก้อีเมลได้ตามต้องการ (ต้องลงท้าย @dpu.ac.th และตรงกับ ADMIN_EMAILS ใน apps/api/.env)
INSERT INTO "User" ("id", "email", "name", "role", "createdAt", "lastLoginAt")
VALUES (gen_random_uuid()::text, 'momarket.admin@dpu.ac.th', 'ผู้ดูแลระบบ momarket', 'ADMIN', now(), now())
ON CONFLICT ("email") DO UPDATE SET "role" = 'ADMIN';

-- 2) (ทางเลือก) ผู้ขายและประกาศตัวอย่าง — ลบส่วนนี้ทิ้งได้ถ้าไม่ต้องการ
INSERT INTO "User" ("id", "email", "name", "createdAt", "lastLoginAt")
VALUES (gen_random_uuid()::text, 'demo.seller@dpu.ac.th', 'น้องมอ (ตัวอย่าง)', now(), now())
ON CONFLICT ("email") DO NOTHING;

INSERT INTO "Listing"
  ("id","userId","type","subcategory","title","description","price","condition","status","meetupLocation",
   "contactLine","imageUrls","waitDays","trackingUrl","ownWorkConfirmed","serviceAreaType","videoUrl","updatedAt")
SELECT gen_random_uuid()::text, u."id", v.type::"ListingType", v.sub::"Subcategory", v.title, v.descr, v.price,
       v.cond::"Condition", v.status::"ListingStatus", v.meetup, 'momarket.demo', ARRAY[]::text[],
       v.wait, v.track, v.own, v.area::"ServiceAreaType", v.video, now()
FROM "User" u,
(VALUES
  ('PRODUCT','FOOD','คุกกี้เนยสด โฮมเมด (กล่อง 6 ชิ้น)','อบสดใหม่ทุกวัน ไม่ใส่วัตถุกันเสีย',59,'NEW','ACTIVE','โรงอาหาร',NULL::int,NULL,false,NULL,NULL),
  ('PRODUCT','STATIONERY','เครื่องคิดเลข Casio fx-991EX','ใช้งานน้อย สภาพดี แถมเคส',450,'USED','ACTIVE','อาคาร 4',NULL,NULL,false,NULL,NULL),
  ('PRODUCT','CLOTHING','เสื้อช็อป DPU ไซส์ M','ใส่ไม่กี่ครั้ง ซักสะอาด',150,'USED','ACTIVE','อาคาร 1',NULL,NULL,false,NULL,NULL),
  ('PRODUCT','HANDMADE','พวงกุญแจถักไหมพรม','ทำมือ เลือกสีได้',35,'NEW','SOLD','โรงอาหาร',NULL,NULL,false,NULL,NULL),
  ('SERVICE','PROXY_ORDER','รับหิ้วขนมญี่ปุ่นจาก Don Don Donki','รอบหิ้วทุกเดือน ค่าหิ้วชิ้นละ 20 บาท',20,NULL,'ACTIVE','ลานจอดรถ',7,'https://line.me/ti/g2/demo',false,NULL,NULL),
  ('SERVICE','PHOTOGRAPHY','ถ่ายภาพรับปริญญา / พอร์ตโฟลิโอ','ช่างภาพนักศึกษา อุปกรณ์ครบ ส่งงานใน 3 วัน',800,NULL,'ACTIVE','DPU Place',NULL,NULL,true,'ON_CAMPUS',NULL),
  ('SERVICE','VIDEO_EDITING','ตัดต่อวิดีโอรายงาน / คลิปสั้น','ตัดต่อ ใส่ซับ เสียงดนตรี',300,NULL,'ACTIVE','อาคาร 22',NULL,NULL,true,NULL,'https://www.youtube.com/watch?v=dQw4w9WgXcQ'),
  ('SERVICE','GRAPHIC_DESIGN','ออกแบบโปสเตอร์ / โลโก้ / พรีเซนต์','แก้ไขได้ 2 รอบ',250,NULL,'ACTIVE','อาคารเกตุพิทักษ์',NULL,NULL,true,NULL,NULL)
) AS v(type, sub, title, descr, price, cond, status, meetup, wait, track, own, area, video)
WHERE u."email" = 'demo.seller@dpu.ac.th'
  AND NOT EXISTS (SELECT 1 FROM "Listing" l WHERE l."userId" = u."id");
