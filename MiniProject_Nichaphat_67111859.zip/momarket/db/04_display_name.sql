-- momarket (อัปเดตครั้งที่ 2): เพิ่มชื่อที่ผู้ใช้ตั้งเอง
-- รันหลัง 02_schema.sql (และ 03_seed.sql ถ้ามี) — รันซ้ำได้ ไม่เสียหาย
-- pgAdmin: คลิกขวาฐานข้อมูล momarket > Query Tool > เปิดไฟล์นี้ > Execute (F5)

ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "displayName" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "displayNameChangedAt" TIMESTAMP(3);

-- แอดมินไม่ต้องถูกบังคับตั้งชื่อ
UPDATE "User" SET "displayName" = 'ผู้ดูแลระบบ' WHERE "role" = 'ADMIN' AND "displayName" IS NULL;

-- (ทางเลือก) ผู้ขายตัวอย่าง
UPDATE "User" SET "displayName" = 'น้องมอ ตัวอย่าง' WHERE "email" = 'demo.seller@dpu.ac.th' AND "displayName" IS NULL;

-- (ทางเลือก) ถ้ามีประกาศที่เจ้าของเป็นแอดมิน ให้ซ่อนออก (แอดมินลงประกาศไม่ได้แล้ว)
UPDATE "Listing" SET "deletedAt" = now()
WHERE "deletedAt" IS NULL AND "userId" IN (SELECT "id" FROM "User" WHERE "role" = 'ADMIN');
