import axios, { AxiosError } from 'axios';
import type { ApiErrorBody } from '@momarket/shared';

export const api = axios.create({ baseURL: '/api', withCredentials: true });

export interface ParsedApiError {
  status: number | null;
  message: string;
  code?: string;
  issues: { path: string; message: string }[];
  data: ApiErrorBody | null;
}

export function parseApiError(e: unknown): ParsedApiError {
  if (axios.isAxiosError(e)) {
    const err = e as AxiosError<ApiErrorBody>;
    const data = err.response?.data ?? null;
    if (data && typeof data.message === 'string') {
      return { status: err.response?.status ?? null, message: data.message, code: data.code, issues: data.issues ?? [], data };
    }
    if (!err.response) {
      return { status: null, message: 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ กรุณาตรวจสอบอินเทอร์เน็ตแล้วลองใหม่', issues: [], data: null };
    }
    return { status: err.response.status, message: 'เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง', issues: [], data: null };
  }
  return { status: null, message: e instanceof Error ? e.message : 'เกิดข้อผิดพลาด', issues: [], data: null };
}

export const errMsg = (e: unknown) => parseApiError(e).message;

/* ---------- แจ้ง AuthProvider เมื่อเซสชันหมดอายุ / ถูกแบนระหว่างใช้งาน ---------- */

type AuthLostHandler = (info: { banned: boolean; message: string }) => void;
let authLost: AuthLostHandler | null = null;
export const setAuthLostHandler = (h: AuthLostHandler | null) => {
  authLost = h;
};

api.interceptors.response.use(
  (r) => r,
  (error) => {
    const url: string = error?.config?.url ?? '';
    const status: number | undefined = error?.response?.status;
    const code: string | undefined = error?.response?.data?.code;
    // ตอนล็อกอิน (/auth/*) ให้หน้า Login จัดการ error เอง
    if (!url.startsWith('/auth/') || url === '/auth/me') {
      if (code === 'BANNED') authLost?.({ banned: true, message: error.response.data.message });
      else if (status === 401) authLost?.({ banned: false, message: '' });
    }
    return Promise.reject(error);
  },
);
