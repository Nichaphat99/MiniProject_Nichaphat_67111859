import { PublicClientApplication } from '@azure/msal-browser';

/* ---------- Google Identity Services ---------- */

interface GoogleIdApi {
  initialize: (cfg: { client_id: string; callback: (r: { credential: string }) => void; hd?: string }) => void;
  renderButton: (el: HTMLElement, opts: Record<string, unknown>) => void;
}
declare global {
  interface Window {
    google?: { accounts: { id: GoogleIdApi } };
  }
}

let gsiPromise: Promise<void> | null = null;
export function loadGoogleScript(): Promise<void> {
  if (window.google?.accounts?.id) return Promise.resolve();
  gsiPromise ??= new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.defer = true;
    s.onload = () => resolve();
    s.onerror = () => {
      gsiPromise = null;
      reject(new Error('โหลดระบบเข้าสู่ระบบของ Google ไม่สำเร็จ'));
    };
    document.head.appendChild(s);
  });
  return gsiPromise;
}

/* ---------- Microsoft (MSAL) ---------- */

let msal: PublicClientApplication | null = null;

export async function microsoftLoginPopup(clientId: string, tenantId: string): Promise<string> {
  if (!msal) {
    msal = new PublicClientApplication({
      auth: {
        clientId,
        authority: `https://login.microsoftonline.com/${tenantId}`,
        redirectUri: window.location.origin,
      },
      cache: { cacheLocation: 'sessionStorage' },
    });
    await msal.initialize();
  }
  const result = await msal.loginPopup({ scopes: ['openid', 'profile', 'email'], prompt: 'select_account' });
  if (!result.idToken) throw new Error('ไม่ได้รับโทเค็นจาก Microsoft');
  return result.idToken;
}
