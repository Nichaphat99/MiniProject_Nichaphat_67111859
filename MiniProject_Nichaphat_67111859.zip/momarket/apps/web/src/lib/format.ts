import { NEW_BADGE_HOURS } from '@momarket/shared';

export const formatPrice = (n: number) => (n === 0 ? 'ฟรี / ตามตกลง' : `฿${n.toLocaleString('th-TH')}`);

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'เมื่อสักครู่';
  if (min < 60) return `${min} นาทีที่แล้ว`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} ชั่วโมงที่แล้ว`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `${day} วันที่แล้ว`;
  return new Date(iso).toLocaleDateString('th-TH', { dateStyle: 'medium' });
}

export const formatDateTime = (iso: string) =>
  new Date(iso).toLocaleString('th-TH', { timeZone: 'Asia/Bangkok', dateStyle: 'medium', timeStyle: 'short' }) + ' น.';

export const initialsOf = (name: string) => (name.trim()[0] ?? '?').toUpperCase();

/** { a: 'x', b: '' } → { a: 'x' } (ตัดค่าว่างก่อนยิง query) */
export function compactParams<T extends Record<string, string | undefined>>(o: T) {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(o)) if (v) out[k] = v;
  return out;
}

const HOUR = 3600 * 1000;
/** ลงประกาศภายใน 24 ชม. (ใช้แสดงป้าย 🆕 ใหม่) */
export const isNewListing = (createdAt: string) => Date.now() - new Date(createdAt).getTime() < NEW_BADGE_HOURS * HOUR;
/** เพิ่งถูกดันภายใน 24 ชม. (และไม่ใช่ประกาศใหม่) */
export const isRecentlyBumped = (bumpedAt: string, createdAt: string) =>
  Date.now() - new Date(bumpedAt).getTime() < NEW_BADGE_HOURS * HOUR &&
  new Date(bumpedAt).getTime() - new Date(createdAt).getTime() > HOUR;

/** วันที่แบบสั้น "12 ธ.ค." จาก YYYY-MM-DD */
export function shortDay(day: string): string {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(Date.UTC(y!, m! - 1, d!)).toLocaleDateString('th-TH', { timeZone: 'UTC', day: 'numeric', month: 'short' });
}
