import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AuthMeResponse, SessionUser, WarningDTO } from '@momarket/shared';
import { api, parseApiError, setAuthLostHandler } from '../lib/api';

interface AuthContextValue {
  user: SessionUser | null;
  pendingWarnings: WarningDTO[];
  recentWarningCount: number;
  loading: boolean;
  /** ข้อความแจ้งบนหน้า Login เช่น ถูกแบน */
  notice: string | null;
  applyMe: (me: AuthMeResponse) => void;
  setNotice: (n: string | null) => void;
  logout: () => Promise<void>;
  acknowledgeWarnings: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [pendingWarnings, setPending] = useState<WarningDTO[]>([]);
  const [recentWarningCount, setRecent] = useState(0);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<string | null>(null);

  const applyMe = useCallback((me: AuthMeResponse) => {
    setUser(me.user);
    setPending(me.pendingWarnings);
    setRecent(me.recentWarningCount);
    setNotice(null);
  }, []);

  const clear = useCallback(() => {
    setUser(null);
    setPending([]);
    setRecent(0);
  }, []);

  useEffect(() => {
    setAuthLostHandler(({ banned, message }) => {
      clear();
      if (banned) setNotice(message);
    });
    return () => setAuthLostHandler(null);
  }, [clear]);

  useEffect(() => {
    let cancelled = false;
    api
      .get<AuthMeResponse>('/auth/me')
      .then((r) => !cancelled && applyMe(r.data))
      .catch((e) => {
        if (cancelled) return;
        const pe = parseApiError(e);
        if (pe.code === 'BANNED') setNotice(pe.message);
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [applyMe]);

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } finally {
      clear();
    }
  }, [clear]);

  const acknowledgeWarnings = useCallback(async () => {
    await api.post('/warnings/acknowledge');
    setPending([]);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ user, pendingWarnings, recentWarningCount, loading, notice, applyMe, setNotice, logout, acknowledgeWarnings }),
    [user, pendingWarnings, recentWarningCount, loading, notice, applyMe, logout, acknowledgeWarnings],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth ต้องใช้ภายใน AuthProvider');
  return ctx;
}
