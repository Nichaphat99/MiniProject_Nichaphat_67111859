import { Link } from 'react-router-dom';
import { SUBCATEGORY_EMOJI, SUBCATEGORY_LABELS, meetupEmoji, type ListingCardDTO } from '@momarket/shared';
import { formatPrice, isNewListing, isRecentlyBumped, timeAgo } from '../lib/format';
import { ImagePlaceholder, StatusBadge } from './ui';

export default function ListingCard({ item }: { item: ListingCardDTO }) {
  const sold = item.status === 'SOLD';
  const isNew = !sold && isNewListing(item.createdAt);
  const bumped = !sold && !isNew && isRecentlyBumped(item.bumpedAt, item.createdAt);

  return (
    <Link to={`/listings/${item.id}`} className="card card-glow group flex flex-col overflow-hidden">
      <div className="relative aspect-[4/3] overflow-hidden bg-lilac-400/10">
        {item.coverUrl ? (
          <img
            src={item.coverUrl}
            alt={item.title}
            loading="lazy"
            className={`h-full w-full object-cover transition duration-500 group-hover:scale-110 ${sold ? 'opacity-50 grayscale' : ''}`}
          />
        ) : (
          <ImagePlaceholder label={item.title} />
        )}
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-ink-950/70 to-transparent" aria-hidden />
        <StatusBadge status={item.status} className="absolute left-2 top-2" />
        {isNew && (
          <span className="chip absolute right-2 top-2 animate-pulse-glow bg-lilac-600 font-semibold text-white">🆕 ใหม่</span>
        )}
        {bumped && <span className="chip absolute right-2 top-2 bg-amber-400 font-semibold text-ink-950">🔥 เพิ่งดัน</span>}
      </div>
      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <p className="text-[11px] font-medium text-lilac-300">
          {SUBCATEGORY_EMOJI[item.subcategory]} {SUBCATEGORY_LABELS[item.subcategory]}
        </p>
        <h3 className="line-clamp-2 min-h-[2.6em] text-[15px] font-semibold leading-snug text-lilac-50">{item.title}</h3>
        <p className={`font-display text-xl font-bold ${sold ? 'text-lilac-200/70 line-through' : 'text-glow text-lilac-100'}`}>
          {formatPrice(item.price)}
        </p>
        <div className="mt-auto flex items-center justify-between gap-2 pt-1">
          <span className="chip max-w-[68%] truncate bg-lilac-400/15 text-lilac-50">
            {meetupEmoji(item.meetupLocation)} {item.meetupLocation}
          </span>
          <span className="text-[11px] text-lilac-200/70">🕒 {timeAgo(item.bumpedAt)}</span>
        </div>
      </div>
    </Link>
  );
}
