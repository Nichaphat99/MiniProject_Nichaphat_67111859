import { useToast } from '../context/ToastContext';

/** แชร์ลิงก์ประกาศ — มือถือใช้เมนูแชร์ของเครื่อง (เลือก LINE ได้เลย) เดสก์ท็อปคัดลอกลิงก์ */
export default function ShareButton({ id, title, className = '' }: { id: string; title: string; className?: string }) {
  const toast = useToast();

  const share = async () => {
    const url = `${window.location.origin}/listings/${id}`;
    try {
      if (typeof navigator.share === 'function') {
        await navigator.share({ title: `${title} | momarket`, text: `ดูประกาศนี้ใน momarket 🛍️ ${title}`, url });
        return;
      }
      await navigator.clipboard.writeText(url);
      toast.success('คัดลอกลิงก์แล้ว 🔗 ไปแปะในกลุ่ม LINE ได้เลย');
    } catch (e) {
      if (e instanceof DOMException && e.name === 'AbortError') return; // ผู้ใช้ปิดหน้าต่างแชร์เอง
      window.prompt('คัดลอกลิงก์นี้', url);
    }
  };

  return (
    <button type="button" onClick={share} className={`btn-secondary ${className}`}>
      🔗 แชร์ประกาศ
    </button>
  );
}
