import { useId, useRef, useState, type MouseEvent as ReactMouseEvent, type ReactNode } from 'react';
import type { DayCount } from '@momarket/shared';
import { shortDay } from '../lib/format';

const W = 640;
const H = 230;
const PAD = { l: 34, r: 14, t: 16, b: 28 };

function niceMax(v: number): number {
  if (v <= 4) return 4;
  const pow = 10 ** Math.floor(Math.log10(v));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * pow >= v) return m * pow;
  return v;
}

/** กราฟพื้นที่ (area) จำนวนต่อวัน — SVG ล้วน ไม่ต้องใช้ไลบรารี */
export function AreaChart({ data, color = '#9D71E8', unit = '' }: { data: DayCount[]; color?: string; unit?: string }) {
  const gid = useId().replace(/:/g, '');
  const ref = useRef<SVGSVGElement>(null);
  const [hover, setHover] = useState<number | null>(null);
  const n = data.length;
  const maxY = niceMax(Math.max(0, ...data.map((d) => d.count)));
  const x = (i: number) => PAD.l + (n <= 1 ? 0 : (i * (W - PAD.l - PAD.r)) / (n - 1));
  const y = (v: number) => PAD.t + (1 - v / maxY) * (H - PAD.t - PAD.b);

  const line = data.map((d, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(d.count).toFixed(1)}`).join(' ');
  const area = `${line} L${x(n - 1).toFixed(1)},${y(0)} L${x(0).toFixed(1)},${y(0)} Z`;
  const ticks = [0, maxY / 2, maxY];
  const labelIdx = [0, Math.floor(n * 0.25), Math.floor(n * 0.5), Math.floor(n * 0.75), n - 1].filter((v, i, a) => a.indexOf(v) === i);

  const onMove = (e: ReactMouseEvent<SVGSVGElement>) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect || n === 0) return;
    const px = ((e.clientX - rect.left) / rect.width) * W;
    const i = Math.round(((px - PAD.l) / (W - PAD.l - PAD.r)) * (n - 1));
    setHover(Math.min(n - 1, Math.max(0, i)));
  };

  const h = hover !== null ? data[hover] : null;
  const tipX = hover !== null ? Math.min(Math.max(x(hover), 70), W - 70) : 0;

  return (
    <svg
      ref={ref}
      viewBox={`0 0 ${W} ${H}`}
      className="h-auto w-full"
      role="img"
      aria-label="กราฟจำนวนต่อวัน 30 วันล่าสุด"
      onMouseMove={onMove}
      onMouseLeave={() => setHover(null)}
    >
      <defs>
        <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.55" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
        <filter id={`${gid}g`} x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {ticks.map((t) => (
        <g key={t}>
          <line x1={PAD.l} x2={W - PAD.r} y1={y(t)} y2={y(t)} stroke="#9D71E8" strokeOpacity={t === 0 ? 0.5 : 0.18} strokeDasharray={t === 0 ? undefined : '4 5'} />
          <text x={PAD.l - 8} y={y(t) + 4} textAnchor="end" fontSize="11" fill="#D1B8FF">
            {Number.isInteger(t) ? t : t.toFixed(1)}
          </text>
        </g>
      ))}
      {labelIdx.map((i) => (
        <text key={i} x={x(i)} y={H - 8} textAnchor={i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'} fontSize="11" fill="#D1B8FF">
          {shortDay(data[i]!.day)}
        </text>
      ))}

      {n > 0 && (
        <>
          <path d={area} fill={`url(#${gid})`} />
          <path d={line} fill="none" stroke={color} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" filter={`url(#${gid}g)`} />
        </>
      )}

      {h && hover !== null && (
        <g pointerEvents="none">
          <line x1={x(hover)} x2={x(hover)} y1={PAD.t} y2={H - PAD.b} stroke="#F2E9FF" strokeOpacity="0.4" />
          <circle cx={x(hover)} cy={y(h.count)} r="5" fill="#F2E9FF" stroke={color} strokeWidth="2.5" />
          <g transform={`translate(${tipX},${Math.max(y(h.count) - 46, 4)})`}>
            <rect x="-58" width="116" height="38" rx="9" fill="#0B0720" stroke="#9D71E8" strokeOpacity="0.8" />
            <text y="15" textAnchor="middle" fontSize="11" fill="#D1B8FF">
              {shortDay(h.day)}
            </text>
            <text y="31" textAnchor="middle" fontSize="13" fontWeight="600" fill="#F2E9FF">
              {h.count.toLocaleString('th-TH')} {unit}
            </text>
          </g>
        </g>
      )}
    </svg>
  );
}

/** แท่งแนวนอน เรียงจากมากไปน้อย */
export function BarList({ rows, color = '#9D71E8' }: { rows: { key: string; label: ReactNode; value: number }[]; color?: string }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  if (rows.length === 0) return <p className="py-6 text-center text-sm text-lilac-200">ยังไม่มีข้อมูล</p>;
  return (
    <ul className="space-y-2.5">
      {rows.map((r) => (
        <li key={r.key}>
          <div className="mb-1 flex items-center justify-between gap-2 text-sm">
            <span className="truncate text-lilac-50">{r.label}</span>
            <span className="font-display font-semibold text-lilac-50">{r.value.toLocaleString('th-TH')}</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-lilac-400/15">
            <div
              className="h-full rounded-full"
              style={{ width: `${(r.value / max) * 100}%`, background: `linear-gradient(90deg, #6A2FC8, ${color})`, boxShadow: `0 0 12px ${color}` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

/** โดนัทสัดส่วน */
export function Donut({ segments, center }: { segments: { label: string; value: number; color: string }[]; center?: ReactNode }) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  const R = 62;
  const C = 2 * Math.PI * R;
  let offset = 0;
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <svg viewBox="0 0 160 160" className="h-44 w-44 -rotate-90" role="img" aria-label="สัดส่วนประกาศ">
          <circle cx="80" cy="80" r={R} fill="none" stroke="#9D71E8" strokeOpacity="0.15" strokeWidth="18" />
          {total > 0 &&
            segments.map((s) => {
              const len = (s.value / total) * C;
              const el = (
                <circle
                  key={s.label}
                  cx="80"
                  cy="80"
                  r={R}
                  fill="none"
                  stroke={s.color}
                  strokeWidth="18"
                  strokeDasharray={`${Math.max(len - 3, 0)} ${C - Math.max(len - 3, 0)}`}
                  strokeDashoffset={-offset}
                  strokeLinecap="round"
                  style={{ filter: `drop-shadow(0 0 6px ${s.color})` }}
                />
              );
              offset += len;
              return el;
            })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">{center}</div>
      </div>
      <ul className="flex flex-wrap justify-center gap-x-5 gap-y-1.5 text-sm">
        {segments.map((s) => (
          <li key={s.label} className="flex items-center gap-2 text-lilac-50">
            <span className="h-3 w-3 rounded-full" style={{ background: s.color, boxShadow: `0 0 8px ${s.color}` }} />
            {s.label} <b className="font-display">{s.value.toLocaleString('th-TH')}</b>
            {total > 0 && <span className="text-lilac-200">({Math.round((s.value / total) * 100)}%)</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}
