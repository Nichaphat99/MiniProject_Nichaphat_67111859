import { useState, type FormEvent } from 'react';
import type { AuthMeResponse } from '@momarket/shared';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { api, parseApiError } from '../lib/api';
import { formatDateTime } from '../lib/format';
import { FieldError, Modal, UserLabel } from './ui';

/** ตั้งชื่อที่แสดง: mode=setup บังคับตั้งครั้งแรกหลังล็อกอิน (ปิดไม่ได้), mode=edit แก้ไขจากหน้าโปรไฟล์ */
export default function NameModal({ mode, onClose }: { mode: 'setup' | 'edit'; onClose?: () => void }) {
  const { user, applyMe } = useAuth();
  const toast = useToast();
  const [name, setName] = useState(user?.needsProfile ? (user.name.match(/^\d+$/) ? '' : user.name) : (user?.name ?? ''));
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  if (!user) return null;

  const locked = mode === 'edit' && !!user.nextNameChangeAt;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const r = await api.patch<AuthMeResponse>('/auth/profile', { displayName: name });
      applyMe(r.data);
      toast.success(mode === 'setup' ? 'ตั้งชื่อเรียบร้อย ยินดีต้อนรับสู่ momarket 🎉' : 'เปลี่ยนชื่อเรียบร้อย ✨');
      onClose?.();
    } catch (err) {
      setError(parseApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      title={mode === 'setup' ? '👋 ตั้งชื่อของคุณก่อนเริ่มใช้งาน' : '✏️ เปลี่ยนชื่อที่แสดง'}
      dismissible={mode === 'edit'}
      onClose={onClose}
    >
      <form onSubmit={submit} noValidate>
        {mode === 'setup' && (
          <p className="mb-3 text-sm text-lilac-100">
            ชื่อนี้จะแสดงคู่กับรหัสนักศึกษาในประกาศและโปรไฟล์ของคุณ เพื่อให้ผู้ซื้อมั่นใจว่าเป็นชาว DPU ตัวจริง
          </p>
        )}

        <label className="label" htmlFor="display-name">
          ชื่อที่แสดง (ชื่อเล่นหรือชื่อจริงก็ได้)
        </label>
        <input
          id="display-name"
          className={`input ${error ? 'input-error' : ''}`}
          value={name}
          maxLength={40}
          autoFocus
          disabled={locked}
          onChange={(e) => setName(e.target.value)}
          placeholder="เช่น สมชาย ใจดี"
        />
        <FieldError message={error} />

        <div className="mt-3 rounded-xl border border-lilac-400/30 bg-lilac-400/10 p-3 text-sm">
          <p className="mb-1 text-xs text-lilac-200">👀 ตัวอย่างที่คนอื่นจะเห็น</p>
          <UserLabel name={name.trim() || 'ชื่อของคุณ'} studentId={user.studentId} />
        </div>

        <p className="mt-2 text-xs text-lilac-200/80">
          🔒 ผู้ใช้ DPU ที่ล็อกอินทุกคนจะเห็นชื่อและรหัสนักศึกษานี้ · ใช้ได้เฉพาะตัวอักษร ตัวเลข และ . _ - · แก้ได้ทุก 30 วัน
        </p>
        {locked && user.nextNameChangeAt && (
          <p className="mt-2 rounded-lg bg-amber-400/15 px-3 py-2 text-xs text-amber-100">
            ⏳ เปลี่ยนชื่อได้อีกครั้งหลัง {formatDateTime(user.nextNameChangeAt)}
          </p>
        )}

        <div className="mt-4 flex justify-end gap-2">
          {mode === 'edit' && (
            <button type="button" className="btn-ghost" onClick={onClose}>
              ยกเลิก
            </button>
          )}
          <button type="submit" className="btn-primary" disabled={busy || locked}>
            {busy ? 'กำลังบันทึก…' : mode === 'setup' ? '🚀 เริ่มใช้งาน' : 'บันทึกชื่อ'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
