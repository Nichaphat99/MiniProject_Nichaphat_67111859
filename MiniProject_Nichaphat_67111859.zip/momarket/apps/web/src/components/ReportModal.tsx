import { useState } from 'react';
import { REPORT_REASONS, REPORT_REASON_EMOJI, REPORT_REASON_LABELS, type ReportReason } from '@momarket/shared';
import { useToast } from '../context/ToastContext';
import { api, errMsg } from '../lib/api';
import { FieldError, Modal } from './ui';

export default function ReportModal({ listingId, onClose }: { listingId: string; onClose: () => void }) {
  const toast = useToast();
  const [reason, setReason] = useState<ReportReason | null>(null);
  const [detail, setDetail] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!reason) {
      setError('กรุณาเลือกเหตุผล');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await api.post(`/listings/${listingId}/reports`, { reason, detail });
      toast.success('ส่งรายงานเรียบร้อย ผู้ดูแลระบบจะตรวจสอบโดยเร็ว');
      onClose();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="🚩 รายงานประกาศนี้" onClose={onClose}>
      <fieldset className="space-y-2">
        <legend className="mb-2 text-sm text-lilac-100">เลือกเหตุผลที่ต้องการรายงาน</legend>
        {REPORT_REASONS.map((r) => (
          <label
            key={r}
            className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-2.5 text-sm transition ${
              reason === r ? 'border-lilac-300 bg-lilac-400/20 shadow-glow' : 'border-lilac-400/30 hover:bg-lilac-400/10'
            }`}
          >
            <input
              type="radio"
              name="reason"
              value={r}
              checked={reason === r}
              onChange={() => setReason(r)}
              className="accent-lilac-500"
            />
            {REPORT_REASON_EMOJI[r]} {REPORT_REASON_LABELS[r]}
          </label>
        ))}
      </fieldset>
      <div className="mt-3">
        <label className="label" htmlFor="report-detail">
          รายละเอียดเพิ่มเติม (ไม่บังคับ)
        </label>
        <textarea
          id="report-detail"
          className="input min-h-20"
          maxLength={500}
          value={detail}
          onChange={(e) => setDetail(e.target.value)}
          placeholder="เล่าเหตุการณ์สั้น ๆ เพื่อช่วยผู้ดูแลตรวจสอบ"
        />
      </div>
      <FieldError message={error} />
      <div className="mt-4 flex justify-end gap-2">
        <button type="button" className="btn-ghost" onClick={onClose}>
          ยกเลิก
        </button>
        <button type="button" className="btn-danger" onClick={submit} disabled={busy}>
          {busy ? 'กำลังส่ง…' : 'ส่งรายงาน'}
        </button>
      </div>
    </Modal>
  );
}
