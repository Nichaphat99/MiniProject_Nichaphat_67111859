import { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LISTING_TYPE_LABELS,
  PRODUCT_SUBCATEGORIES,
  SERVICE_SUBCATEGORIES,
  SUBCATEGORY_EMOJI,
  SUBCATEGORY_LABELS,
  TYPE_EMOJI,
  type ListingType,
  type Subcategory,
} from '@momarket/shared';

const COLUMNS: { type: ListingType; subs: readonly Subcategory[] }[] = [
  { type: 'PRODUCT', subs: PRODUCT_SUBCATEGORIES },
  { type: 'SERVICE', subs: SERVICE_SUBCATEGORIES },
];

/** เมนู "ตลาด ▾" — เลือกประเภทและหมวดย่อยได้จากแถบบนทุกหน้า */
export default function MarketMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { pathname } = useLocation();
  const active = pathname.startsWith('/market');

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const linkCls = 'block rounded-lg px-2.5 py-1.5 text-sm text-lilac-100 transition hover:bg-lilac-400/20 hover:text-white';

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
          active || open ? 'bg-lilac-400/25 text-white shadow-[0_0_14px_rgb(157_113_232/0.45)]' : 'text-lilac-100 hover:bg-lilac-400/15'
        }`}
      >
        🛍️ ตลาด <span className={`inline-block text-xs transition ${open ? 'rotate-180' : ''}`}>▾</span>
      </button>

      {open && (
        <div className="absolute left-1/2 top-full z-40 mt-2 w-[min(92vw,540px)] -translate-x-1/2 rounded-2xl border border-lilac-400/50 bg-ink-900 p-4 shadow-glow-lg sm:left-0 sm:translate-x-0">
          <div className="grid gap-4 sm:grid-cols-2">
            {COLUMNS.map(({ type, subs }) => (
              <div key={type}>
                <Link
                  to={type === 'SERVICE' ? '/market?type=SERVICE' : '/market'}
                  className="mb-1.5 block rounded-lg bg-lilac-400/15 px-2.5 py-2 font-display text-sm font-semibold text-lilac-50 hover:bg-lilac-400/25"
                >
                  {TYPE_EMOJI[type]} {LISTING_TYPE_LABELS[type]} <span className="text-lilac-300">· ดูทั้งหมด →</span>
                </Link>
                <ul>
                  {subs.map((s) => (
                    <li key={s}>
                      <Link to={`/market?type=${type}&sub=${s}`} className={linkCls}>
                        {SUBCATEGORY_EMOJI[s]} {SUBCATEGORY_LABELS[s]}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
