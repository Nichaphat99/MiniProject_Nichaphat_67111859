import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { errMsg } from '../lib/api';
import { formatDateTime } from '../lib/format';
import MarketMenu from './MarketMenu';
import NameModal from './NameModal';
import { Avatar, Modal } from './ui';

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-lilac-600 font-display text-base font-bold text-white shadow-[0_0_18px_rgb(157_113_232/0.8)] ring-2 ring-lilac-300/70">
        mo
      </span>
      <span className={`font-display text-xl font-bold tracking-tight ${light ? 'text-white' : 'text-lilac-50'}`}>momarket</span>
    </span>
  );
}

function WarningModal() {
  const { pendingWarnings, acknowledgeWarnings } = useAuth();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (pendingWarnings.length === 0) return null;

  const ack = async () => {
    setBusy(true);
    try {
      await acknowledgeWarnings();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="⚠️ คุณได้รับคำเตือนจากผู้ดูแลระบบ" dismissible={false}>
      <p className="mb-3 text-sm text-lilac-100">กรุณาอ่านและกดรับทราบก่อนใช้งานต่อ หากฝ่าฝืนซ้ำอาจถูกแบนชั่วคราวหรือถาวร</p>
      <ul className="mb-4 space-y-2">
        {pendingWarnings.map((w) => (
          <li key={w.id} className="rounded-xl border border-amber-400/50 bg-amber-400/15 p-3 text-sm">
            <p className="whitespace-pre-line font-medium text-amber-100">{w.message}</p>
            <p className="mt-1 text-xs text-amber-200">🕒 {formatDateTime(w.createdAt)}</p>
          </li>
        ))}
      </ul>
      <button type="button" className="btn-primary w-full" onClick={ack} disabled={busy}>
        {busy ? 'กำลังบันทึก…' : '✅ รับทราบ'}
      </button>
    </Modal>
  );
}

function WarningBanner() {
  const { recentWarningCount, pendingWarnings } = useAuth();
  if (recentWarningCount === 0 || pendingWarnings.length > 0) return null;
  return (
    <div className="border-b border-amber-400/40 bg-amber-400/15 px-4 py-2 text-center text-sm text-amber-100">
      ⚠️ คุณมีคำเตือน {recentWarningCount} รายการในช่วง 30 วันที่ผ่านมา —{' '}
      <Link to="/me?tab=warnings" className="font-semibold underline">
        ดูประวัติคำเตือน
      </Link>
    </div>
  );
}

const navClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-lg px-3 py-1.5 text-sm font-medium transition ${
    isActive ? 'bg-lilac-400/25 text-white shadow-[0_0_14px_rgb(157_113_232/0.45)]' : 'text-lilac-100 hover:bg-lilac-400/15'
  }`;

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [confirmLogout, setConfirmLogout] = useState(false);
  if (!user) return null;
  const isAdmin = user.role === 'ADMIN';

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-lilac-400/30 bg-ink-950/85 shadow-[0_8px_30px_-12px_rgb(106_47_200/0.6)] backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-2 px-4 py-2.5">
          <Link to="/" aria-label="momarket หน้าแรก">
            <Logo />
          </Link>
          <nav className="flex flex-wrap items-center gap-1" aria-label="เมนูหลัก">
            <NavLink to="/" end className={navClass}>
              🏠 หน้าแรก
            </NavLink>
            <MarketMenu />
            <NavLink to="/me" className={navClass}>
              👤 โปรไฟล์
            </NavLink>
            {isAdmin && (
              <NavLink to="/admin" className={navClass}>
                🛡️ แอดมิน
              </NavLink>
            )}
            {!isAdmin && (
              <Link to="/listings/new" className="btn-primary btn-sm ml-1">
                ➕ ลงประกาศ
              </Link>
            )}
            <button
              type="button"
              onClick={() => setConfirmLogout(true)}
              className="ml-1 rounded-full ring-2 ring-lilac-400/40 transition hover:ring-lilac-300 hover:shadow-[0_0_14px_rgb(157_113_232/0.7)]"
              aria-label="ออกจากระบบ"
              title={`${user.name} — ออกจากระบบ`}
            >
              <Avatar name={user.name} url={user.avatarUrl} size={34} />
            </button>
          </nav>
        </div>
      </header>

      <WarningBanner />

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6">
        <Outlet />
      </main>

      <footer className="border-t border-lilac-400/25 bg-ink-950/80 py-6 text-center text-xs text-lilac-200">
        <p className="font-display text-sm font-semibold text-lilac-50">💜 momarket — ตลาดของชาว DPU</p>
        <p className="mt-1">ไม่มีระบบชำระเงินในเว็บ · นัดรับในมหาวิทยาลัยเท่านั้น · พบสิ่งไม่เหมาะสมกด 🚩 รายงานได้ทุกประกาศ</p>
      </footer>

      {user.needsProfile ? <NameModal mode="setup" /> : <WarningModal />}

      {confirmLogout && (
        <Modal title="👋 ออกจากระบบ?" onClose={() => setConfirmLogout(false)} size="sm">
          <p className="mb-4 text-sm text-lilac-100">
            ออกจากบัญชี <b className="text-lilac-50">{user.email}</b>
          </p>
          <div className="flex justify-end gap-2">
            <button type="button" className="btn-ghost" onClick={() => setConfirmLogout(false)}>
              ยกเลิก
            </button>
            <button
              type="button"
              className="btn-primary"
              onClick={async () => {
                await logout();
                navigate('/login', { replace: true });
              }}
            >
              ออกจากระบบ
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
