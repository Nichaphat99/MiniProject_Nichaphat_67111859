import { useEffect, type ReactNode } from 'react';
import { LISTING_STATUS_LABELS, type ListingStatus } from '@momarket/shared';
import { initialsOf } from '../lib/format';

export function Spinner({ full = false }: { full?: boolean }) {
  return (
    <div className={`flex items-center justify-center ${full ? 'min-h-screen' : 'py-16'}`} role="status" aria-label="กำลังโหลด">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-lilac-400/40 border-t-lilac-300" />
    </div>
  );
}

export function EmptyState({ title, hint, action, emoji = '🛍️' }: { title: string; hint?: string; action?: ReactNode; emoji?: string }) {
  return (
    <div className="card flex flex-col items-center gap-2 px-6 py-14 text-center">
      <div className="animate-float text-5xl drop-shadow-[0_0_16px_rgb(157,113,232,0.8)]" aria-hidden>
        {emoji}
      </div>
      <p className="font-display text-lg font-semibold text-lilac-50">{title}</p>
      {hint && <p className="max-w-sm text-sm text-lilac-200">{hint}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-2xl border border-rose-400/50 bg-rose-500/15 px-4 py-3 text-sm text-rose-200" role="alert">
      {message}
      {onRetry && (
        <button type="button" className="ml-3 font-semibold underline" onClick={onRetry}>
          ลองใหม่
        </button>
      )}
    </div>
  );
}

export function StatusBadge({ status, className = '' }: { status: ListingStatus; className?: string }) {
  const sold = status === 'SOLD';
  return (
    <span
      className={`chip shadow-sm ${sold ? 'bg-ink-950/85 text-white' : 'bg-emerald-500 text-white'} ${className}`}
    >
      {sold ? '✅' : '🟢'} {LISTING_STATUS_LABELS[status]}
    </span>
  );
}

export function Avatar({ name, url, size = 40 }: { name: string; url: string | null; size?: number }) {
  if (url) {
    return (
      <img
        src={url}
        alt=""
        width={size}
        height={size}
        referrerPolicy="no-referrer"
        className="rounded-full object-cover"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <span
      className="flex items-center justify-center rounded-full bg-lilac-600 font-display font-semibold text-white"
      style={{ width: size, height: size, fontSize: size * 0.42 }}
      aria-hidden
    >
      {initialsOf(name)}
    </span>
  );
}

export function ImagePlaceholder({ label, className = '' }: { label?: string; className?: string }) {
  return (
    <div
      className={`flex h-full w-full items-center justify-center bg-gradient-to-br from-lilac-600/50 via-ink-900 to-lilac-400/30 font-display text-3xl font-bold text-lilac-400 ${className}`}
      aria-hidden
    >
      {label ? initialsOf(label) : 'mo'}
    </div>
  );
}

interface ModalProps {
  title?: string;
  children: ReactNode;
  onClose?: () => void;
  /** false = Blocking Modal (ปิดด้วย ESC / คลิกพื้นหลังไม่ได้) */
  dismissible?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function Modal({ title, children, onClose, dismissible = true, size = 'md' }: ModalProps) {
  useEffect(() => {
    if (!dismissible || !onClose) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dismissible, onClose]);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const width = size === 'sm' ? 'max-w-sm' : size === 'lg' ? 'max-w-2xl' : 'max-w-md';
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink-950/75 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onMouseDown={(e) => {
        if (dismissible && onClose && e.target === e.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-lilac-300/50 bg-ink-900 p-5 shadow-[0_0_36px_rgb(157_113_232/0.5)] sm:rounded-3xl sm:p-6 ${width}`}
      >
        {title && (
          <div className="mb-3 flex items-start justify-between gap-3">
            <h2 className="text-xl font-semibold text-lilac-50">{title}</h2>
            {dismissible && onClose && (
              <button type="button" onClick={onClose} className="btn-ghost btn-sm -mr-2 -mt-1" aria-label="ปิด">
                ✕
              </button>
            )}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

export function FieldError({ message }: { message?: string }) {
  return message ? (
    <p className="mt-1 text-xs font-medium text-rose-300" role="alert">
      {message}
    </p>
  ) : null;
}

/** ชื่อ + เลขนักศึกษา เช่น "สมชาย ใจดี 🎓 6512345678" */
export function UserLabel({ name, studentId, className = '' }: { name: string; studentId: string | null; className?: string }) {
  return (
    <span className={`inline-flex flex-wrap items-center gap-x-1.5 gap-y-0.5 ${className}`}>
      <span className="font-semibold">{name}</span>
      {studentId && <span className="chip bg-lilac-400/15 font-mono text-lilac-200">🎓 {studentId}</span>}
    </span>
  );
}

export function CardSkeleton() {
  return (
    <div className="card overflow-hidden" aria-hidden>
      <div className="skeleton aspect-[4/3]" />
      <div className="space-y-2.5 p-3">
        <div className="skeleton h-3 w-1/3 rounded" />
        <div className="skeleton h-4 w-5/6 rounded" />
        <div className="skeleton h-5 w-1/3 rounded" />
        <div className="skeleton h-5 w-1/2 rounded-full" />
      </div>
    </div>
  );
}

export function SkeletonGrid({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4" role="status" aria-label="กำลังโหลด">
      {Array.from({ length: count }, (_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}
