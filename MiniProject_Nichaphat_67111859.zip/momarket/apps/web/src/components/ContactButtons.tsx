import { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { isHttpsUrl } from '@momarket/shared';
import { Modal } from './ui';

interface Props {
  line?: string | null;
  instagram?: string | null;
  facebook?: string | null;
}

export const lineUrl = (id: string) => `https://line.me/ti/p/~${encodeURIComponent(id)}`;
export const instagramUrl = (u: string) => `https://instagram.com/${encodeURIComponent(u)}`;

/** Smart Contact: Line → เปิด Modal QR Code, Instagram / Facebook → เปิดหน้าโปรไฟล์ในแท็บใหม่ */
export default function ContactButtons({ line, instagram, facebook }: Props) {
  const [qr, setQr] = useState(false);
  const fbOk = isHttpsUrl(facebook);

  if (!line && !instagram && !fbOk) {
    return <p className="text-sm text-lilac-200">ผู้ขายไม่ได้ระบุช่องทางติดต่อ</p>;
  }

  return (
    <>
      <div className="flex flex-wrap gap-2">
        {line && (
          <button
            type="button"
            onClick={() => setQr(true)}
            className="btn bg-[#06C755] text-white shadow-sm hover:brightness-95"
          >
            💬 ติดต่อทาง LINE
          </button>
        )}
        {instagram && (
          <a
            href={instagramUrl(instagram)}
            target="_blank"
            rel="noopener noreferrer"
            className="btn bg-gradient-to-r from-fuchsia-600 via-rose-500 to-amber-500 text-white shadow-sm hover:brightness-95"
          >
            📸 Instagram @{instagram}
          </a>
        )}
        {fbOk && (
          <a
            href={facebook}
            target="_blank"
            rel="noopener noreferrer"
            className="btn bg-[#1877F2] text-white shadow-sm hover:brightness-95"
          >
            👤 Facebook
          </a>
        )}
      </div>

      {qr && line && (
        <Modal title="💬 ติดต่อผู้ขายทาง LINE" onClose={() => setQr(false)} size="sm">
          <div className="flex flex-col items-center gap-3 text-center">
            <div className="rounded-2xl border border-lilac-400/30 bg-ink-900 p-3">
              <QRCodeSVG value={lineUrl(line)} size={208} marginSize={1} />
            </div>
            <p className="text-sm text-lilac-100">
              สแกน QR Code ด้วย LINE หรือกดปุ่มด้านล่าง
              <br />
              LINE ID: <b className="break-all">{line}</b>
            </p>
            <a href={lineUrl(line)} target="_blank" rel="noopener noreferrer" className="btn w-full bg-[#06C755] text-white">
              เปิด LINE
            </a>
            <p className="text-xs text-lilac-200/70">อย่าลืม: นัดรับในมหาวิทยาลัยเท่านั้น</p>
          </div>
        </Modal>
      )}
    </>
  );
}
