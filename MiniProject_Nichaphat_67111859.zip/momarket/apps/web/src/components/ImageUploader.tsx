import { useRef, useState } from 'react';
import { ALLOWED_IMAGE_MIME, MAX_IMAGE_BYTES } from '@momarket/shared';
import { useToast } from '../context/ToastContext';
import { api, errMsg } from '../lib/api';

interface Props {
  value: string[];
  onChange: (urls: string[]) => void;
  max: number;
  invalid?: boolean;
}

/** อัปโหลดรูป (ไฟล์) ไปที่ /api/uploads แล้วเก็บเป็นรายการ URL — รูปแรกคือภาพปก */
export default function ImageUploader({ value, onChange, max, invalid }: Props) {
  const toast = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const remaining = max - value.length;

  const handleFiles = async (list: FileList | null) => {
    if (!list || list.length === 0) return;
    const files = Array.from(list);
    if (files.length > remaining) {
      toast.error(`เพิ่มได้อีก ${remaining} รูป (สูงสุด ${max} รูป)`);
      return;
    }
    for (const f of files) {
      if (!(ALLOWED_IMAGE_MIME as readonly string[]).includes(f.type)) {
        toast.error(`“${f.name}” ไม่ใช่ไฟล์ JPG, PNG หรือ WebP`);
        return;
      }
      if (f.size > MAX_IMAGE_BYTES) {
        toast.error(`“${f.name}” ใหญ่เกิน ${MAX_IMAGE_BYTES / 1024 / 1024}MB`);
        return;
      }
    }
    const fd = new FormData();
    files.forEach((f) => fd.append('files', f));
    setBusy(true);
    try {
      const { data } = await api.post<{ urls: string[] }>('/uploads', fd);
      onChange([...value, ...data.urls]);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const remove = (i: number) => onChange(value.filter((_, idx) => idx !== i));
  const makeCover = (i: number) => onChange([value[i]!, ...value.filter((_, idx) => idx !== i)]);

  return (
    <div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
        {value.map((url, i) => (
          <div key={url} className="group relative aspect-square overflow-hidden rounded-xl border border-lilac-400/30 bg-white/10">
            <img src={url} alt={`รูปที่ ${i + 1}`} className="h-full w-full object-cover" />
            {i === 0 && (
              <span className="absolute left-1 top-1 rounded-md bg-lilac-700 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                ภาพปก
              </span>
            )}
            <div className="absolute inset-x-0 bottom-0 flex justify-between gap-1 bg-gradient-to-t from-black/70 to-transparent p-1 pt-5 text-[11px] text-white">
              {i > 0 ? (
                <button type="button" onClick={() => makeCover(i)} className="rounded px-1 hover:bg-white/20">
                  ตั้งเป็นปก
                </button>
              ) : (
                <span />
              )}
              <button
                type="button"
                onClick={() => remove(i)}
                className="rounded px-1 hover:bg-rose-500"
                aria-label={`ลบรูปที่ ${i + 1}`}
              >
                ลบ
              </button>
            </div>
          </div>
        ))}
        {remaining > 0 && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={busy}
            className={`flex aspect-square cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed text-xs font-medium transition disabled:opacity-60 ${
              invalid
                ? 'border-rose-400 text-rose-300'
                : 'border-lilac-400/50 text-lilac-200 hover:border-lilac-400 hover:bg-lilac-400/10'
            }`}
          >
            <span className="text-2xl leading-none">{busy ? '⏳' : '＋'}</span>
            {busy ? 'กำลังอัปโหลด' : 'เพิ่มรูป'}
          </button>
        )}
      </div>
      <input
        ref={inputRef}
        type="file"
        accept={ALLOWED_IMAGE_MIME.join(',')}
        multiple={max > 1}
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      <p className="mt-1.5 text-xs text-lilac-200">
        JPG / PNG / WebP ไม่เกิน {MAX_IMAGE_BYTES / 1024 / 1024}MB ต่อรูป · {value.length}/{max} รูป
      </p>
    </div>
  );
}
