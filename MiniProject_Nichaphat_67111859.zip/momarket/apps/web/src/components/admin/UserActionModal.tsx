import { useState } from 'react';
import { TEMP_BAN_DAYS, type AdminUserDTO } from '@momarket/shared';
import { useToast } from '../../context/ToastContext';
import { api, errMsg } from '../../lib/api';
import { FieldError, Modal, UserLabel } from '../ui';

export type UserAction = 'warn' | 'ban-temp' | 'ban-permanent' | 'unban';

const META: Record<UserAction, { title: string; button: string; danger: boolean; text: false | 'required' | 'optional'; hint: string }> = {
  warn: { title: '⚠️ ส่งคำเตือน (Warning)', button: 'ส่งคำเตือน', danger: false, text: 'required', hint: 'ผู้ใช้จะเห็นหน้าต่างบังคับกดรับทราบเมื่อเข้าเว็บครั้งถัดไป และมีประวัติในหน้าโปรไฟล์' },
  'ban-temp': { title: `⏳ แบนชั่วคราว ${TEMP_BAN_DAYS} วัน`, button: `แบน ${TEMP_BAN_DAYS} วัน`, danger: true, text: 'optional', hint: 'ผู้ใช้จะล็อกอินไม่ได้ และประกาศทั้งหมดถูกซ่อนจนครบกำหนด' },
  'ban-permanent': { title: '⛔ แบนถาวร (บล็อกอีเมล DPU)', button: 'แบนถาวร', danger: true, text: 'optional', hint: 'อีเมลนี้จะล็อกอินไม่ได้อีก ใช้เมื่อฝ่าฝืนร้ายแรงเท่านั้น' },
  unban: { title: '↩️ ปลดแบน', button: 'ปลดแบน', danger: false, text: false, hint: 'ผู้ใช้จะกลับมาล็อกอินและใช้งานได้ตามปกติ' },
};

export default function UserActionModal({
  action,
  user,
  onClose,
  onDone,
}: {
  action: UserAction;
  user: AdminUserDTO;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const meta = META[action];
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (meta.text === 'required' && text.trim().length < 5) {
      setError('กรุณาระบุข้อความอย่างน้อย 5 ตัวอักษร');
      return;
    }
    setBusy(true);
    setError('');
    try {
      if (action === 'warn') await api.post(`/admin/users/${user.id}/warn`, { message: text });
      else if (action === 'ban-temp') await api.post(`/admin/users/${user.id}/ban-temp`, { reason: text });
      else if (action === 'ban-permanent') await api.post(`/admin/users/${user.id}/ban-permanent`, { reason: text });
      else await api.post(`/admin/users/${user.id}/unban`);
      toast.success('ดำเนินการเรียบร้อย ✅');
      onDone();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={meta.title} onClose={onClose}>
      <p className="text-sm text-lilac-100">
        ผู้ใช้: <UserLabel name={user.name} studentId={user.studentId} />
      </p>
      <p className="mt-0.5 break-all text-xs text-lilac-200">{user.email}</p>
      <p className="mt-2 text-xs text-lilac-200">{meta.hint}</p>
      {meta.text && (
        <div className="mt-3">
          <label className="label" htmlFor="user-action-text">
            {action === 'warn' ? 'ข้อความคำเตือน' : 'เหตุผล (ไม่บังคับ)'}
          </label>
          <textarea id="user-action-text" className="input min-h-24" maxLength={500} value={text} onChange={(e) => setText(e.target.value)} />
        </div>
      )}
      <FieldError message={error} />
      <div className="mt-4 flex justify-end gap-2">
        <button type="button" className="btn-ghost" onClick={onClose}>
          ยกเลิก
        </button>
        <button type="button" className={meta.danger ? 'btn-danger' : 'btn-primary'} onClick={submit} disabled={busy}>
          {busy ? 'กำลังดำเนินการ…' : meta.button}
        </button>
      </div>
    </Modal>
  );
}
