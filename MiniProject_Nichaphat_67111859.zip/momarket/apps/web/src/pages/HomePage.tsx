import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import {
  COMMUNITY_RULES,
  PRODUCT_SUBCATEGORIES,
  SAFETY_NOTICES,
  SERVICE_SUBCATEGORIES,
  SUBCATEGORY_LABELS,
  type Subcategory,
  type ListingCardDTO,
  type ListingType,
  type Paginated,
} from '@momarket/shared';
import ListingCard from '../components/ListingCard';
import { SkeletonGrid } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

const FEATURES = [
  { t: 'ซื้อ-ขายสินค้า', d: 'ของกิน เสื้อผ้า อุปกรณ์การเรียน เครื่องสำอาง งานแฮนด์เมด และของใช้ทั่วไป จากเพื่อนในมหาลัย' },
  { t: 'จ้างงาน & บริการ', d: 'ถ่ายภาพ ตัดต่อวิดีโอ ออกแบบกราฟิก และบริการรับหิ้ว/พรีออเดอร์ โดยฝีมือชาว DPU' },
  { t: 'ติดต่อง่าย กดแล้วคุยเลย', d: 'ปุ่ม LINE (มี QR Code), Instagram, Facebook เด้งไปคุยกับผู้ขายได้ทันที' },
  { t: 'ปลอดภัยเพราะเป็นชาว DPU', d: 'ล็อกอินด้วยอีเมล @dpu.ac.th เท่านั้น มีปุ่มรายงาน และนัดรับในมหาลัยเสมอ' },
];

const STEPS = [
  { t: 'ล็อกอินด้วยอีเมล DPU', d: 'ใช้บัญชี Google หรือ Microsoft ของมหาลัย แล้วตั้งชื่อที่จะแสดง' },
  { t: 'เลือกดู หรือลงประกาศ', d: 'ค้นหา กรองตามหมวด จุดนัดรับ และราคา หรือลงประกาศของคุณเองได้ฟรี' },
  { t: 'กดติดต่อ แล้วนัดรับ', d: 'คุยกันนอกเว็บ ตกลงกันเอง แล้วนัดรับตามจุดต่างๆ ในมหาวิทยาลัย' },
];

function CategoryTile({
  type,
  sub,
  imageUrl,
}: {
  type: ListingType;
  sub: (typeof PRODUCT_SUBCATEGORIES)[number] | (typeof SERVICE_SUBCATEGORIES)[number];
  imageUrl?: string;
}) {
  return (
    <Link
      to={`/market?type=${type}&sub=${sub}`}
      className="group relative block h-56 shrink-0 snap-start overflow-hidden rounded-2xl border border-lilac-400/30 bg-gradient-to-br from-lilac-700 via-ink-900 to-lilac-500 shadow-[0_12px_32px_-16px_rgb(106_47_200/0.8)] transition duration-300 hover:-translate-y-1 hover:border-lilac-400 hover:shadow-glow"
    >
      {imageUrl ? (
        <img
          src={imageUrl}
          alt=""
          className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      ) : (
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,rgb(157_113_232/0.75),transparent_42%),linear-gradient(135deg,#5624a3,#25134d_70%,#9d71e8)]" />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0720]/95 via-[#0B0720]/45 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 p-5">
        <span className="block text-base font-bold leading-snug text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] sm:text-lg">
          {SUBCATEGORY_LABELS[sub]}
        </span>
      </div>
    </Link>
  );
}

function CategoryCarousel({
  children,
  label,
}: {
  children: ReactNode;
  label: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (direction: number) => {
    ref.current?.scrollBy({ left: direction * 280, behavior: 'smooth' });
  };
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => scroll(-1)}
        className="absolute left-2 top-1/2 z-10 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-lilac-400/60 bg-ink-950/90 text-2xl text-white shadow-glow transition hover:bg-lilac-600 md:flex"
        aria-label={`เลื่อน${label}ซ้าย`}
      >
        ‹
      </button>
      <div
        ref={ref}
        className="flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-smooth pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {children}
      </div>
      <button
        type="button"
        onClick={() => scroll(1)}
        className="absolute right-2 top-1/2 z-10 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-lilac-400/60 bg-ink-950/90 text-2xl text-white shadow-glow transition hover:bg-lilac-600 md:flex"
        aria-label={`เลื่อน${label}ขวา`}
      >
        ›
      </button>
    </div>
  );
}

function SectionTitle({ emoji, title, hint }: { emoji?: string; title: string; hint?: string }) {
  return (
    <div className="mb-4">
      <h2 className="text-2xl font-bold text-lilac-50">
        {emoji ? <span className="mr-2">{emoji}</span> : null}
        {title}
      </h2>
      {hint && <p className="mt-1 text-sm text-lilac-200">{hint}</p>}
    </div>
  );
}

export default function HomePage() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'ADMIN';
  const [latest, setLatest] = useState<ListingCardDTO[] | null>(null);
  const [categoryImages, setCategoryImages] = useState<Partial<Record<Subcategory, string>>>({});
  const [heroImageUrl, setHeroImageUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all(
      (['PRODUCT', 'SERVICE'] as const).map((type) =>
        api.get<Paginated<ListingCardDTO>>('/listings', { params: { type, limit: 4, hideSold: '1' } }).then((r) => r.data.items),
      ),
    )
      .then(([a, b]) => {
        if (cancelled) return;
        setLatest([...a, ...b].sort((x, y) => +new Date(y.bumpedAt) - +new Date(x.bumpedAt)).slice(0, 8));
      })
      .catch(() => !cancelled && setLatest([]));
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    api
      .get<Record<string, string>>('/category-images')
      .then((r) => {
        if (!cancelled) setCategoryImages(r.data);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    api
      .get<{ imageUrl: string | null }>('/category-images/hero-banner')
      .then((r) => {
        if (!cancelled) setHeroImageUrl(r.data.imageUrl);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="space-y-14">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl border border-[#9D71E8]/50 bg-gradient-to-br from-ink-900 via-ink-950 to-lilac-700/40 px-6 py-14 text-center shadow-[0_0_30px_rgba(106,47,200,0.3)] sm:px-12 sm:py-20">
        {heroImageUrl && (
          <img
            src={heroImageUrl}
            alt=""
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(11,7,32,0.72),rgba(11,7,32,0.82)_72%,rgba(11,7,32,0.9))]" aria-hidden />
        <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-lilac-600/40 blur-3xl" aria-hidden />
        <div className="pointer-events-none absolute -bottom-28 -right-20 h-80 w-80 rounded-full bg-lilac-400/25 blur-3xl" aria-hidden />
        <div className="relative mx-auto max-w-2xl">
          <span className="chip border border-lilac-400/60 bg-lilac-400/15 px-3.5 py-1 text-sm text-lilac-50">
            สำหรับชาวมหาวิทยาลัยธุรกิจบัณฑิตย์ (DPU) เท่านั้น
          </span>
          <h1 className="text-gradient mt-5 text-5xl font-bold leading-tight drop-shadow-[0_0_20px_rgba(157,113,232,0.85)] sm:text-7xl">momarket</h1>
          <p className="text-glow mt-1 font-display text-2xl font-semibold text-lilac-100 drop-shadow-[0_0_18px_rgba(157,113,232,0.8)] sm:text-3xl">มอมาร์เก็ต</p>
          <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-lilac-100 drop-shadow-[0_2px_8px_rgba(11,7,32,0.95)] sm:text-lg">
            ตลาดนัดออนไลน์ของชาว DPU — <b className="text-white">ซื้อ ขาย จ้างงาน รับหิ้ว</b> ได้ในที่เดียว
            กดติดต่อผู้ขายแล้วนัดรับกันในมหาลัยได้เลย ไม่มีค่าธรรมเนียม ไม่ต้องโอนผ่านเว็บ
          </p>
          {user && (
            <p className="mt-3 text-sm text-lilac-200">
              สวัสดี <b className="text-lilac-50">{user.name}</b>
            </p>
          )}
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Link to="/market" className="btn-primary px-6 py-3 text-base">
              เข้าตลาดเลย
            </Link>
            {isAdmin ? (
              <Link to="/admin" className="btn-secondary px-6 py-3 text-base">
                ไปหน้าแอดมิน
              </Link>
            ) : (
              <Link to="/listings/new" className="btn-secondary px-6 py-3 text-base">
                ลงประกาศของคุณ
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* ทำอะไรได้บ้าง */}
      <section>
        <SectionTitle title="momarket ทำอะไรได้บ้าง" hint="พื้นที่กลางสำหรับพ่อค้าแม่ค้าและฟรีแลนซ์ตัวน้อยของ DPU" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div key={f.t} className="card card-glow p-5">
              <h3 className="text-lg font-semibold text-lilac-50">{f.t}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-lilac-100">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* หมวดหมู่ */}
      <section>
        <SectionTitle title="เลือกดูตามหมวดหมู่" />
        <h3 className="mb-3 text-base font-semibold text-lilac-200">ซื้อขายสินค้า</h3>
        <div className="mb-5">
          <CategoryCarousel label="หมวดซื้อขายสินค้า">
            {PRODUCT_SUBCATEGORIES.map((s) => (
              <div key={s} className="w-[72%] shrink-0 sm:w-[38%] md:w-[29%] lg:w-[21%]">
                <CategoryTile type="PRODUCT" sub={s} imageUrl={categoryImages[s]} />
              </div>
            ))}
          </CategoryCarousel>
        </div>
        <h3 className="mb-3 text-base font-semibold text-lilac-200">บริการและรับจ้าง</h3>
        <CategoryCarousel label="หมวดบริการและรับจ้าง">
          {SERVICE_SUBCATEGORIES.map((s) => (
            <div key={s} className="w-[72%] shrink-0 sm:w-[48%] md:w-[38%] lg:w-[27%]">
              <CategoryTile type="SERVICE" sub={s} imageUrl={categoryImages[s]} />
            </div>
          ))}
        </CategoryCarousel>
      </section>

      {/* ประกาศล่าสุด */}
      <section>
        <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
          <SectionTitle title="ประกาศล่าสุด" hint="เพิ่งลงหรือเพิ่งดันขึ้นมาใหม่" />
          <Link to="/market" className="btn-secondary btn-sm mb-4">
            ดูทั้งหมด
          </Link>
        </div>
        {latest === null ? (
          <SkeletonGrid count={4} />
        ) : latest.length === 0 ? (
          <div className="card p-8 text-center text-lilac-100">ยังไม่มีประกาศ — มาเป็นคนแรกที่ลงประกาศกัน</div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
            {latest.map((it) => (
              <ListingCard key={it.id} item={it} />
            ))}
          </div>
        )}
      </section>

      {/* ขั้นตอน */}
      <section>
        <SectionTitle title="เริ่มใช้งานง่ายๆ ใน 3 ขั้นตอน" />
        <ol className="grid gap-4 md:grid-cols-3">
          {STEPS.map((s, i) => (
            <li key={s.t} className="card relative p-6 pt-8">
              <span className="absolute -top-3 left-5 flex h-8 w-8 items-center justify-center rounded-full bg-lilac-600 font-display text-sm font-bold text-white shadow-[0_0_16px_rgb(157_113_232/0.9)]">
                {i + 1}
              </span>
              <h3 className="text-lg font-semibold leading-snug">{s.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-lilac-100">{s.d}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* กฎระเบียบ */}
      <section className="grid gap-5 lg:grid-cols-[1.3fr_1fr]">
        <div className="card p-6">
          <SectionTitle title="กฎกติกาของชาว momarket" />
          <ol className="space-y-3">
            {COMMUNITY_RULES.map((r, i) => (
              <li key={r} className="flex gap-3 text-sm leading-relaxed text-lilac-50">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-lilac-400/25 text-xs font-bold text-lilac-50">
                  {i + 1}
                </span>
                <span className="font-normal text-lilac-50">{r}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="rounded-2xl border-2 border-amber-400/60 bg-amber-400/10 p-6 shadow-[0_0_28px_-8px_rgb(251_191_36/0.5)]">
          <SectionTitle title="ข้อควรระวังก่อนซื้อ" />
          <ul className="space-y-3 text-sm leading-relaxed text-amber-100">
            {SAFETY_NOTICES.map((n) => (
              <li key={n} className="flex gap-3">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-300" aria-hidden />
                <span className="font-medium text-amber-100">{n}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* CTA ท้ายหน้า */}
      <section className="card border-lilac-400/50 bg-gradient-to-r from-lilac-700/40 via-ink-900 to-lilac-600/30 p-8 text-center shadow-glow">
        <h2 className="text-2xl font-bold">พร้อมแล้วหรือยัง? ไปเดินตลาดกัน!</h2>
        <div className="mt-5 flex flex-wrap justify-center gap-3">
          <Link to="/market" className="btn-primary px-6 py-3 text-base">
            เข้าตลาด
          </Link>
          {!isAdmin && (
            <Link to="/listings/new" className="btn-secondary px-6 py-3 text-base">
              ลงประกาศ
            </Link>
          )}
        </div>
      </section>
    </div>
  );
}
