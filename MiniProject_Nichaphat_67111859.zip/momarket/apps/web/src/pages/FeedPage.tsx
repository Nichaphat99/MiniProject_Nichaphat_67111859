import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  LISTING_TYPES,
  LISTING_TYPE_LABELS,
  MEETUP_LOCATIONS,
  PRODUCT_SUBCATEGORIES,
  SERVICE_SUBCATEGORIES,
  SUBCATEGORY_EMOJI,
  SUBCATEGORY_LABELS,
  type ListingCardDTO,
  type ListingType,
  type Paginated,
} from '@momarket/shared';
import ListingCard from '../components/ListingCard';
import { EmptyState, ErrorBox, SkeletonGrid } from '../components/ui';
import { api, errMsg } from '../lib/api';

const PAGE_SIZE = 24;

const SORTS = [
  { value: 'newest', label: '🆕 ล่าสุด' },
  { value: 'price_asc', label: '💸 ราคา: ต่ำ → สูง' },
  { value: 'price_desc', label: '💎 ราคา: สูง → ต่ำ' },
] as const;

export default function FeedPage() {
  const [sp, setSp] = useSearchParams();
  const type: ListingType = sp.get('type') === 'SERVICE' ? 'SERVICE' : 'PRODUCT';
  const sub = sp.get('sub') ?? '';
  const q = sp.get('q') ?? '';
  const meetup = sp.get('meetup') ?? '';
  const sort = (SORTS.find((s) => s.value === sp.get('sort'))?.value ?? 'newest') as (typeof SORTS)[number]['value'];
  const hideSold = sp.get('hide') === '1';

  const [search, setSearch] = useState(q);
  const [items, setItems] = useState<ListingCardDTO[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState('');
  const reqId = useRef(0);

  const update = useCallback(
    (patch: Record<string, string | null>, resetSub = false) => {
      setSp(
        (prev) => {
          const next = new URLSearchParams(prev);
          if (resetSub) next.delete('sub');
          for (const [k, v] of Object.entries(patch)) {
            if (v) next.set(k, v);
            else next.delete(k);
          }
          return next;
        },
        { replace: true },
      );
    },
    [setSp],
  );

  // debounce ช่องค้นหา
  useEffect(() => {
    if (search === q) return;
    const t = setTimeout(() => update({ q: search.trim() || null }), 350);
    return () => clearTimeout(t);
  }, [search, q, update]);

  const baseParams = useCallback(
    (p: number) => ({
      type,
      ...(sub ? { subcategory: sub } : {}),
      ...(q ? { q } : {}),
      ...(meetup ? { meetup } : {}),
      sort,
      ...(hideSold ? { hideSold: '1' } : {}),
      page: p,
      limit: PAGE_SIZE,
    }),
    [type, sub, q, meetup, sort, hideSold],
  );

  const load = useCallback(() => {
    const id = ++reqId.current;
    setLoading(true);
    setError('');
    api
      .get<Paginated<ListingCardDTO>>('/listings', { params: baseParams(1) })
      .then((r) => {
        if (id !== reqId.current) return;
        setItems(r.data.items);
        setTotal(r.data.total);
        setPage(1);
      })
      .catch((e) => id === reqId.current && setError(errMsg(e)))
      .finally(() => id === reqId.current && setLoading(false));
  }, [baseParams]);

  useEffect(load, [load]);

  const loadMore = async () => {
    const id = reqId.current;
    setLoadingMore(true);
    try {
      const r = await api.get<Paginated<ListingCardDTO>>('/listings', { params: baseParams(page + 1) });
      if (id !== reqId.current) return;
      setItems((prev) => {
        const seen = new Set(prev.map((i) => i.id));
        return [...prev, ...r.data.items.filter((i) => !seen.has(i.id))];
      });
      setPage((p) => p + 1);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoadingMore(false);
    }
  };

  const subs = type === 'PRODUCT' ? PRODUCT_SUBCATEGORIES : SERVICE_SUBCATEGORIES;
  const hasFilters = !!(sub || q || meetup || hideSold);

  return (
    <div className="space-y-5">
      {/* แท็บหลัก */}
      <div className="grid grid-cols-2 gap-1.5 rounded-2xl bg-ink-900/80 p-1.5 ring-1 ring-lilac-400/30" role="tablist" aria-label="ประเภทประกาศ">
        {LISTING_TYPES.map((t) => (
          <button
            key={t}
            type="button"
            role="tab"
            aria-selected={type === t}
            onClick={() => {
              update({ type: t === 'SERVICE' ? 'SERVICE' : null }, true);
            }}
            className={`cursor-pointer rounded-xl px-4 py-3 font-display text-base font-semibold transition ${
              type === t ? 'bg-lilac-600 text-white shadow-[0_0_18px_rgb(157_113_232/0.7)] ring-1 ring-lilac-300/60' : 'text-lilac-100 hover:bg-lilac-400/15'
            }`}
          >
            {t === 'PRODUCT' ? '🛍️ ' : '🧑‍💻 '}
            {LISTING_TYPE_LABELS[t]}
          </button>
        ))}
      </div>

      {/* ค้นหา + ตัวกรอง */}
      <div className="card space-y-3 p-4">
        <div className="grid gap-3 md:grid-cols-[1fr_200px_190px]">
          <div className="relative">
            <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-lilac-200/70" aria-hidden>
              🔍
            </span>
            <input
              type="search"
              className="input pl-10"
              placeholder={type === 'PRODUCT' ? 'ค้นหาชื่อสินค้า…' : 'ค้นหาชื่อบริการ…'}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="ค้นหา"
            />
          </div>
          <select
            className="input"
            value={meetup}
            onChange={(e) => update({ meetup: e.target.value || null })}
            aria-label="จุดนัดรับ"
          >
            <option value="">📍 ทุกจุดนัดรับ</option>
            {MEETUP_LOCATIONS.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
          <select
            className="input"
            value={sort}
            onChange={(e) => update({ sort: e.target.value === 'newest' ? null : e.target.value })}
            aria-label="เรียงลำดับ"
          >
            {SORTS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="หมวดหมู่ย่อย">
            <button
              type="button"
              onClick={() => update({ sub: null })}
              className={`chip cursor-pointer px-3 py-1 text-[13px] transition ${
                !sub ? 'bg-lilac-600 text-white shadow-[0_0_12px_rgb(106_47_200/0.9)]' : 'bg-lilac-400/15 text-lilac-50 hover:bg-lilac-400/25'
              }`}
            >
              ✨ ทั้งหมด
            </button>
            {subs.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => update({ sub: s })}
                aria-pressed={sub === s}
                className={`chip cursor-pointer px-3 py-1 text-[13px] transition ${
                  sub === s ? 'bg-lilac-600 text-white shadow-[0_0_12px_rgb(106_47_200/0.9)]' : 'bg-lilac-400/15 text-lilac-50 hover:bg-lilac-400/25'
                }`}
              >
                {SUBCATEGORY_EMOJI[s]} {SUBCATEGORY_LABELS[s]}
              </button>
            ))}
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-sm text-lilac-50">
            <button
              type="button"
              role="switch"
              aria-checked={hideSold}
              onClick={() => update({ hide: hideSold ? null : '1' })}
              className={`relative h-6 w-11 shrink-0 cursor-pointer rounded-full transition ${hideSold ? 'bg-lilac-600' : 'bg-lilac-200/30'}`}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-ink-900 shadow transition-all ${hideSold ? 'left-[22px]' : 'left-0.5'}`}
              />
            </button>
            🙈 ซ่อนที่ขายแล้ว
          </label>
        </div>
      </div>

      {/* ผลลัพธ์ */}
      {error && <ErrorBox message={error} onRetry={load} />}

      {loading ? (
        <SkeletonGrid />
      ) : items.length === 0 && !error ? (
        <EmptyState
          emoji={hasFilters ? '🔎' : '🌱'}
          title={hasFilters ? 'ไม่พบประกาศที่ตรงกับตัวกรอง' : 'ยังไม่มีประกาศในหมวดนี้'}
          hint={hasFilters ? 'ลองเปลี่ยนคำค้นหา หรือล้างตัวกรอง' : 'มาเป็นคนแรกที่ลงประกาศกัน!'}
          action={
            hasFilters ? (
              <button
                type="button"
                className="btn-secondary"
                onClick={() => {
                  setSearch('');
                  setSp(type === 'SERVICE' ? { type: 'SERVICE' } : {}, { replace: true });
                }}
              >
                🧹 ล้างตัวกรอง
              </button>
            ) : (
              <Link to="/listings/new" className="btn-primary">
                ➕ ลงประกาศ
              </Link>
            )
          }
        />
      ) : (
        <>
          <p className="text-sm text-lilac-200">📦 พบ {total.toLocaleString('th-TH')} ประกาศ</p>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
            {items.map((it) => (
              <ListingCard key={it.id} item={it} />
            ))}
          </div>
          {items.length < total && (
            <div className="flex justify-center pt-2">
              <button type="button" className="btn-secondary" onClick={loadMore} disabled={loadingMore}>
                {loadingMore ? 'กำลังโหลด…' : 'โหลดเพิ่ม'}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
