import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  CONDITIONS,
  CONDITION_EMOJI,
  CONDITION_LABELS,
  LISTING_TYPES,
  LISTING_TYPE_LABELS,
  MAX_IMAGES,
  MEETUP_LOCATIONS,
  PRODUCT_SUBCATEGORIES,
  PROXY_ORDER_WARNING,
  SERVICE_AREA_LABELS,
  SERVICE_AREA_TYPES,
  SERVICE_SUBCATEGORIES,
  SUBCATEGORY_EMOJI,
  SUBCATEGORY_LABELS,
  listingInputSchema,
  typeOfSubcategory,
  youtubeThumbnail,
  type Condition,
  type ListingDetailDTO,
  type ListingType,
  type ServiceAreaType,
  type Subcategory,
} from '@momarket/shared';
import ImageUploader from '../components/ImageUploader';
import { ErrorBox, FieldError, Spinner } from '../components/ui';
import { useToast } from '../context/ToastContext';
import { api, parseApiError } from '../lib/api';

interface FormState {
  type: ListingType;
  subcategory: Subcategory | '';
  title: string;
  description: string;
  price: string;
  condition: Condition | '';
  meetupLocation: string;
  meetupNote: string;
  contactLine: string;
  contactInstagram: string;
  contactFacebook: string;
  images: string[];
  waitDays: string;
  trackingUrl: string;
  ownWorkConfirmed: boolean;
  serviceAreaType: ServiceAreaType | '';
  serviceAreaDetail: string;
  videoUrl: string;
}

const EMPTY: FormState = {
  type: 'PRODUCT',
  subcategory: '',
  title: '',
  description: '',
  price: '',
  condition: '',
  meetupLocation: '',
  meetupNote: '',
  contactLine: '',
  contactInstagram: '',
  contactFacebook: '',
  images: [],
  waitDays: '',
  trackingUrl: '',
  ownWorkConfirmed: false,
  serviceAreaType: '',
  serviceAreaDetail: '',
  videoUrl: '',
};

const numOrUndef = (s: string) => (s.trim() === '' ? undefined : Number(s));

function buildPayload(f: FormState) {
  return {
    subcategory: f.subcategory || undefined,
    title: f.title,
    description: f.description,
    price: numOrUndef(f.price),
    condition: f.condition || undefined,
    meetupLocation: f.meetupLocation || undefined,
    meetupNote: f.meetupNote,
    contactLine: f.contactLine,
    contactInstagram: f.contactInstagram,
    contactFacebook: f.contactFacebook,
    images: f.images,
    waitDays: numOrUndef(f.waitDays),
    trackingUrl: f.trackingUrl,
    ownWorkConfirmed: f.ownWorkConfirmed,
    serviceAreaType: f.serviceAreaType || undefined,
    serviceAreaDetail: f.serviceAreaDetail,
    videoUrl: f.videoUrl,
  };
}

function fromDetail(d: ListingDetailDTO): FormState {
  return {
    type: d.type,
    subcategory: d.subcategory,
    title: d.title,
    description: d.description,
    price: String(d.price),
    condition: d.condition ?? '',
    meetupLocation: d.meetupLocation,
    meetupNote: d.meetupNote ?? '',
    contactLine: d.contactLine ?? '',
    contactInstagram: d.contactInstagram ?? '',
    contactFacebook: d.contactFacebook ?? '',
    images: d.imageUrls,
    waitDays: d.waitDays != null ? String(d.waitDays) : '',
    trackingUrl: d.trackingUrl ?? '',
    ownWorkConfirmed: d.ownWorkConfirmed,
    serviceAreaType: d.serviceAreaType ?? '',
    serviceAreaDetail: d.serviceAreaDetail ?? '',
    videoUrl: d.videoUrl ?? '',
  };
}

function Field({ label, error, hint, required, children }: { label: string; error?: string; hint?: string; required?: boolean; children: ReactNode }) {
  return (
    <div>
      <label className="label">
        {label} {required && <span className="text-rose-400">*</span>}
      </label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-lilac-200">{hint}</p>}
      <FieldError message={error} />
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="card space-y-4 p-5">
      <h2 className="text-lg font-semibold text-lilac-50">{title}</h2>
      {children}
    </section>
  );
}

export default function ListingFormPage() {
  const { id } = useParams();
  const editing = !!id;
  const navigate = useNavigate();
  const toast = useToast();

  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(editing);
  const [loadError, setLoadError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    api
      .get<ListingDetailDTO>(`/listings/${id}`)
      .then((r) => {
        if (cancelled) return;
        if (!r.data.isOwner || r.data.deletedAt) setLoadError('คุณไม่มีสิทธิ์แก้ไขประกาศนี้');
        else setForm(fromDetail(r.data));
      })
      .catch((e) => !cancelled && setLoadError(parseApiError(e).message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [id]);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => {
      if (!e[key as string]) return e;
      const { [key as string]: _drop, ...rest } = e;
      return rest;
    });
  };

  const chooseType = (t: ListingType) => setForm((f) => (f.type === t ? f : { ...f, type: t, subcategory: '', condition: '' }));

  const chooseSub = (s: Subcategory) => {
    setForm((f) => ({
      ...f,
      subcategory: s,
      type: typeOfSubcategory(s),
      images: s === 'VIDEO_EDITING' ? f.images.slice(0, 1) : f.images,
    }));
    setErrors((e) => {
      const { subcategory: _drop, ...rest } = e;
      return rest;
    });
  };

  const scrollToError = () =>
    requestAnimationFrame(() => document.querySelector('[role="alert"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (!form.subcategory) {
      setErrors({ subcategory: 'กรุณาเลือกหมวดหมู่' });
      scrollToError();
      return;
    }
    const parsed = listingInputSchema.safeParse(buildPayload(form));
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = String(issue.path[0] ?? 'form');
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      scrollToError();
      return;
    }

    setErrors({});
    setSaving(true);
    try {
      const res = editing
        ? await api.put<{ id: string }>(`/listings/${id}`, parsed.data)
        : await api.post<{ id: string }>('/listings', parsed.data);
      toast.success(editing ? 'บันทึกการแก้ไขแล้ว' : 'ลงประกาศเรียบร้อย');
      navigate(`/listings/${res.data.id}`);
    } catch (err) {
      const pe = parseApiError(err);
      if (pe.issues.length > 0) {
        const next: Record<string, string> = {};
        for (const i of pe.issues) {
          const key = i.path.split('.')[0] || 'form';
          if (!next[key]) next[key] = i.message;
        }
        setErrors(next);
      }
      setFormError(pe.message);
      scrollToError();
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Spinner />;
  if (loadError)
    return (
      <div className="space-y-4">
        <ErrorBox message={loadError} />
        <Link to="/me" className="btn-secondary">
          ← กลับโปรไฟล์
        </Link>
      </div>
    );

  const sub = form.subcategory;
  const isProduct = sub !== '' && (PRODUCT_SUBCATEGORIES as readonly string[]).includes(sub);
  const isService = sub !== '' && !isProduct;
  const subOptions = form.type === 'PRODUCT' ? PRODUCT_SUBCATEGORIES : SERVICE_SUBCATEGORIES;
  const maxImages = sub === 'VIDEO_EDITING' ? 1 : MAX_IMAGES;
  const ytCover = sub === 'VIDEO_EDITING' ? youtubeThumbnail(form.videoUrl) : null;

  const imagesLabel =
    sub === 'VIDEO_EDITING'
      ? 'ภาพปกวิดีโอ'
      : isProduct
        ? 'รูปสินค้า (1-5 รูป)'
        : sub === 'PROXY_ORDER'
          ? 'รูปประกอบ (ไม่บังคับ)'
          : 'รูปตัวอย่างผลงาน (1-5 รูป)';
  const imagesRequired = sub !== 'PROXY_ORDER' && sub !== 'VIDEO_EDITING';

  return (
    <form onSubmit={submit} className="mx-auto max-w-2xl space-y-5" noValidate>
      <div>
        <h1 className="text-2xl font-bold text-lilac-50">{editing ? '✏️ แก้ไขประกาศ' : '➕ ลงประกาศใหม่'}</h1>
        <p className="text-sm text-lilac-200">ฟอร์มจะปรับช่องกรอกตามหมวดหมู่ที่เลือกโดยอัตโนมัติ</p>
      </div>

      {formError && <ErrorBox message={formError} />}

      <Section title="🗂️ 1. เลือกประเภทและหมวดหมู่">
        {editing ? (
          <p className="text-sm">
            <span className="chip bg-lilac-400/20 text-lilac-50">{LISTING_TYPE_LABELS[form.type]}</span>{' '}
            <span className="chip bg-lilac-600 text-white">{sub && SUBCATEGORY_LABELS[sub]}</span>
            <span className="ml-2 text-xs text-lilac-200">(เปลี่ยนหมวดหมู่ไม่ได้ — หากต้องการเปลี่ยนให้ลบแล้วลงใหม่)</span>
          </p>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-2">
              {LISTING_TYPES.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => chooseType(t)}
                  aria-pressed={form.type === t}
                  className={`cursor-pointer rounded-xl border-2 px-3 py-3 text-sm font-semibold transition ${
                    form.type === t ? 'border-lilac-300 bg-lilac-400/15 text-white shadow-glow' : 'border-lilac-400/30 text-lilac-100 hover:border-lilac-400/50'
                  }`}
                >
                  {t === 'PRODUCT' ? '🛍️ ' : '🧑‍💻 '}
                  {LISTING_TYPE_LABELS[t]}
                </button>
              ))}
            </div>
            <Field label="หมวดหมู่ย่อย" required error={errors.subcategory}>
              <div className="flex flex-wrap gap-2">
                {subOptions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => chooseSub(s)}
                    aria-pressed={sub === s}
                    className={`chip cursor-pointer px-3.5 py-1.5 text-sm transition ${
                      sub === s ? 'bg-lilac-600 text-white shadow-[0_0_12px_rgb(106_47_200/0.9)]' : 'bg-lilac-400/15 text-lilac-50 hover:bg-lilac-400/25'
                    }`}
                  >
                    {SUBCATEGORY_EMOJI[s]} {SUBCATEGORY_LABELS[s]}
                  </button>
                ))}
              </div>
            </Field>
          </>
        )}
      </Section>

      {sub && (
        <>
          <Section title="📝 2. รายละเอียด">
            <Field label={isProduct ? 'ชื่อสินค้า' : 'ชื่อบริการ'} required error={errors.title}>
              <input
                className={`input ${errors.title ? 'input-error' : ''}`}
                value={form.title}
                maxLength={100}
                onChange={(e) => set('title', e.target.value)}
              />
            </Field>

            <Field label={isProduct ? 'ราคา (บาท)' : 'ราคา (บาท — ราคาเริ่มต้น)'} required error={errors.price} hint="ใส่ 0 หากฟรีหรือตามตกลง">
              <input
                className={`input ${errors.price ? 'input-error' : ''}`}
                inputMode="numeric"
                value={form.price}
                onChange={(e) => set('price', e.target.value.replace(/[^\d]/g, ''))}
              />
            </Field>

            {isProduct && (
              <Field label="สภาพสินค้า" required error={errors.condition}>
                <div className="flex gap-2">
                  {CONDITIONS.map((c) => (
                    <label
                      key={c}
                      className={`flex flex-1 cursor-pointer items-center justify-center rounded-xl border-2 py-2.5 text-sm font-medium transition ${
                        form.condition === c ? 'border-lilac-400 bg-lilac-400/10 text-lilac-50' : 'border-lilac-400/30 hover:border-lilac-400/50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="condition"
                        className="sr-only"
                        checked={form.condition === c}
                        onChange={() => set('condition', c)}
                      />
                      {CONDITION_LABELS[c]}
                    </label>
                  ))}
                </div>
              </Field>
            )}

            <Field label="รายละเอียด" required error={errors.description}>
              <textarea
                className={`input min-h-32 ${errors.description ? 'input-error' : ''}`}
                value={form.description}
                maxLength={2000}
                onChange={(e) => set('description', e.target.value)}
              />
            </Field>

            {/* ฟิลด์เฉพาะหมวด */}
            {sub === 'PROXY_ORDER' && (
              <>
                <div className="rounded-xl border-2 border-rose-400/50 bg-rose-500/15 p-3 text-sm text-rose-200">
                  <p className="font-semibold">🚨 ผู้ซื้อจะเห็นคำเตือนนี้ในประกาศของคุณ (แก้ไขไม่ได้)</p>
                  <p className="mt-1 leading-relaxed">{PROXY_ORDER_WARNING}</p>
                </div>
                <Field label="ระยะเวลารอสินค้า (จำนวนวัน)" required error={errors.waitDays}>
                  <input
                    className={`input ${errors.waitDays ? 'input-error' : ''}`}
                    inputMode="numeric"
                    value={form.waitDays}
                    onChange={(e) => set('waitDays', e.target.value.replace(/[^\d]/g, ''))}
                  />
                </Field>
                <Field
                  label="ช่องทางติดตามคำสั่งซื้อนอกเว็บ"
                  required
                  error={errors.trackingUrl}
                  hint="ลิงก์ LINE OpenChat / Instagram / Facebook เช่น https://line.me/ti/g2/…"
                >
                  <input
                    className={`input ${errors.trackingUrl ? 'input-error' : ''}`}
                    type="url"
                    value={form.trackingUrl}
                    onChange={(e) => set('trackingUrl', e.target.value)}
                    placeholder="https://"
                  />
                </Field>
              </>
            )}

            {sub === 'PHOTOGRAPHY' && (
              <Field label="พื้นที่รับงาน" required error={errors.serviceAreaType ?? errors.serviceAreaDetail}>
                <div className="space-y-2">
                  <div className="grid gap-2 sm:grid-cols-2">
                    {SERVICE_AREA_TYPES.map((a) => (
                      <label
                        key={a}
                        className={`flex cursor-pointer items-center justify-center rounded-xl border-2 py-2.5 text-center text-sm font-medium transition ${
                          form.serviceAreaType === a ? 'border-lilac-400 bg-lilac-400/10 text-lilac-50' : 'border-lilac-400/30 hover:border-lilac-400/50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="area"
                          className="sr-only"
                          checked={form.serviceAreaType === a}
                          onChange={() => set('serviceAreaType', a)}
                        />
                        {SERVICE_AREA_LABELS[a]}
                      </label>
                    ))}
                  </div>
                  {form.serviceAreaType && (
                    <input
                      className={`input ${errors.serviceAreaDetail ? 'input-error' : ''}`}
                      value={form.serviceAreaDetail}
                      maxLength={200}
                      onChange={(e) => set('serviceAreaDetail', e.target.value)}
                      placeholder={form.serviceAreaType === 'OFF_CAMPUS' ? 'ระบุสถานที่นอกมหาวิทยาลัย *' : 'รายละเอียดเพิ่มเติม (ไม่บังคับ)'}
                    />
                  )}
                </div>
              </Field>
            )}

            {sub === 'VIDEO_EDITING' && (
              <Field
                label="ลิงก์วิดีโอผลงาน"
                required
                error={errors.videoUrl}
                hint="วางลิงก์ YouTube / TikTok / Google Drive (ไม่มีการอัปโหลดวิดีโอเข้าเว็บ)"
              >
                <input
                  className={`input ${errors.videoUrl ? 'input-error' : ''}`}
                  type="url"
                  value={form.videoUrl}
                  onChange={(e) => set('videoUrl', e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=…"
                />
              </Field>
            )}

            {isService && sub !== 'PROXY_ORDER' && (
              <div>
                <label
                  className={`flex cursor-pointer items-start gap-3 rounded-xl border-2 p-3 text-sm transition ${
                    errors.ownWorkConfirmed ? 'border-rose-400 bg-rose-500/15' : form.ownWorkConfirmed ? 'border-emerald-400 bg-emerald-400/15' : 'border-lilac-400/30'
                  }`}
                >
                  <input
                    type="checkbox"
                    className="mt-0.5 h-4 w-4 accent-lilac-500"
                    checked={form.ownWorkConfirmed}
                    onChange={(e) => set('ownWorkConfirmed', e.target.checked)}
                  />
                  <span>
                    <b>ยืนยันว่าเป็นผลงานของตนเองจริง</b> <span className="text-rose-400">*</span>
                    <span className="block text-xs text-lilac-200">การแอบอ้างผลงานผู้อื่นอาจถูกแบนถาวร</span>
                  </span>
                </label>
                <FieldError message={errors.ownWorkConfirmed} />
              </div>
            )}
          </Section>

          <Section title="🖼️ 3. รูปภาพ">
            <Field label={imagesLabel} required={imagesRequired} error={errors.images}>
              <ImageUploader value={form.images} onChange={(u) => set('images', u)} max={maxImages} invalid={!!errors.images} />
            </Field>
            {sub === 'VIDEO_EDITING' && ytCover && form.images.length === 0 && (
              <div className="flex items-center gap-3 rounded-xl bg-lilac-400/10 p-2.5 text-xs text-lilac-100">
                <img src={ytCover} alt="" className="h-14 w-24 rounded-lg object-cover" />
                ดึงภาพปกจาก YouTube ให้อัตโนมัติ (หรืออัปโหลดภาพปกเองเพื่อใช้แทนได้)
              </div>
            )}
          </Section>

          <Section title="📍 4. จุดนัดรับ">
            <Field label="สถานที่ใน DPU" required error={errors.meetupLocation}>
              <select
                className={`input ${errors.meetupLocation ? 'input-error' : ''}`}
                value={form.meetupLocation}
                onChange={(e) => set('meetupLocation', e.target.value)}
              >
                <option value="">— เลือกจุดนัดรับ —</option>
                {MEETUP_LOCATIONS.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="รายละเอียดจุดนัดพบเพิ่มเติม" error={errors.meetupNote} hint="เช่น หน้าเซเว่น ชั้น 1 / ใต้ตึก ใกล้ลิฟต์">
              <input
                className="input"
                value={form.meetupNote}
                maxLength={200}
                onChange={(e) => set('meetupNote', e.target.value)}
              />
            </Field>
          </Section>

          <Section title="💬 5. ช่องทางติดต่อ (กรอกอย่างน้อย 1 ช่องทาง)">
            <Field label="Line ID" error={errors.contactLine}>
              <input
                className={`input ${errors.contactLine ? 'input-error' : ''}`}
                value={form.contactLine}
                maxLength={30}
                onChange={(e) => set('contactLine', e.target.value)}
                placeholder="เช่น momarket.demo"
              />
            </Field>
            <Field label="Instagram Username" error={errors.contactInstagram} hint="ใส่แค่ชื่อ ไม่ต้องมี @">
              <input
                className={`input ${errors.contactInstagram ? 'input-error' : ''}`}
                value={form.contactInstagram}
                maxLength={31}
                onChange={(e) => set('contactInstagram', e.target.value)}
                onBlur={() => set('contactInstagram', form.contactInstagram.trim().replace(/^@+/, ''))}
                placeholder="เช่น momarket"
              />
            </Field>
            <Field label="Facebook (ลิงก์โปรไฟล์/เพจ)" error={errors.contactFacebook}>
              <input
                className={`input ${errors.contactFacebook ? 'input-error' : ''}`}
                type="url"
                value={form.contactFacebook}
                onChange={(e) => set('contactFacebook', e.target.value)}
                placeholder="https://www.facebook.com/…"
              />
            </Field>
            <FieldError message={errors.contact} />
          </Section>

          <div className="flex items-center justify-end gap-2 pb-6">
            <Link to={editing ? `/listings/${id}` : '/market'} className="btn-ghost">
              ยกเลิก
            </Link>
            <button type="submit" className="btn-primary px-6" disabled={saving}>
              {saving ? 'กำลังบันทึก…' : editing ? 'บันทึกการแก้ไข' : 'ลงประกาศ'}
            </button>
          </div>
        </>
      )}
    </form>
  );
}
