import { useEffect, useState, type ReactNode } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  CONDITION_EMOJI,
  CONDITION_LABELS,
  PROXY_ORDER_WARNING,
  SAFETY_NOTICES,
  SERVICE_AREA_LABELS,
  SUBCATEGORY_EMOJI,
  SUBCATEGORY_LABELS,
  isHttpsUrl,
  type ListingDetailDTO,
} from '@momarket/shared';
import ContactButtons from '../components/ContactButtons';
import ReportModal from '../components/ReportModal';
import ShareButton from '../components/ShareButton';
import { Avatar, ErrorBox, ImagePlaceholder, Spinner, StatusBadge, UserLabel } from '../components/ui';
import { parseApiError } from '../lib/api';
import { api } from '../lib/api';
import { formatDateTime, formatPrice, timeAgo } from '../lib/format';

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex gap-3 border-b border-lilac-400/15 py-2.5 text-sm last:border-0">
      <dt className="w-32 shrink-0 text-lilac-200">{label}</dt>
      <dd className="min-w-0 flex-1 break-words font-medium text-lilac-50">{children}</dd>
    </div>
  );
}

export default function ListingDetailPage() {
  const { id } = useParams();
  const [item, setItem] = useState<ListingDetailDTO | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState(0);
  const [reporting, setReporting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    setActive(0);
    api
      .get<ListingDetailDTO>(`/listings/${id}`)
      .then((r) => !cancelled && setItem(r.data))
      .catch((e) => !cancelled && setError(parseApiError(e).message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (loading) return <Spinner />;
  if (error || !item)
    return (
      <div className="space-y-4">
        <ErrorBox message={error || 'ไม่พบประกาศ'} />
        <Link to="/market" className="btn-secondary">
          ← กลับไปตลาด
        </Link>
      </div>
    );

  const photos = item.imageUrls.length > 0 ? item.imageUrls : item.coverUrl ? [item.coverUrl] : [];
  const sold = item.status === 'SOLD';
  const isService = item.type === 'SERVICE';
  const videoOk = isHttpsUrl(item.videoUrl);
  const trackingOk = isHttpsUrl(item.trackingUrl);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link to={isService ? '/market?type=SERVICE' : '/market'} className="text-sm font-medium text-lilac-200 hover:text-white hover:underline">
          ← กลับไปตลาด
        </Link>
        <ShareButton id={item.id} title={item.title} className="btn-sm" />
      </div>

      {item.deletedAt && (
        <div className="rounded-2xl border border-rose-400/50 bg-rose-500/15 px-4 py-3 text-sm text-rose-200" role="alert">
          🗑️ ประกาศนี้ถูกลบเมื่อ {formatDateTime(item.deletedAt)} (แสดงให้เฉพาะผู้ดูแลระบบ)
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        {/* รูปภาพ / วิดีโอ */}
        <div className="space-y-3">
          <div className="card relative aspect-[4/3] overflow-hidden bg-lilac-400/10">
            {photos[active] ? (
              <img
                src={photos[active]}
                alt={item.title}
                className={`h-full w-full object-contain bg-white/5 ${sold ? 'opacity-70 grayscale' : ''}`}
              />
            ) : (
              <ImagePlaceholder label={item.title} />
            )}
            <StatusBadge status={item.status} className="absolute left-3 top-3 px-3 py-1 text-sm" />
            {item.subcategory === 'VIDEO_EDITING' && videoOk && (
              <a
                href={item.videoUrl!}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute inset-0 flex items-center justify-center bg-black/25 transition hover:bg-black/40"
                aria-label="เปิดดูวิดีโอผลงาน"
              >
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-ink-950/85 text-2xl text-lilac-200 shadow-lg">
                  ▶
                </span>
              </a>
            )}
          </div>

          {photos.length > 1 && (
            <div className="grid grid-cols-5 gap-2">
              {photos.map((p, i) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setActive(i)}
                  aria-label={`ดูรูปที่ ${i + 1}`}
                  className={`aspect-square cursor-pointer overflow-hidden rounded-xl border-2 transition ${
                    i === active ? 'border-lilac-400' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={p} alt="" className="h-full w-full object-cover" loading="lazy" />
                </button>
              ))}
            </div>
          )}

          {item.subcategory === 'VIDEO_EDITING' && videoOk && (
            <a
              href={item.videoUrl!}
              target="_blank"
              rel="noopener noreferrer"
              className="card flex items-center justify-between gap-3 px-4 py-3 text-sm hover:border-lilac-400/50"
            >
              <span className="min-w-0">
                <span className="block font-semibold text-lilac-50">🎬 ดูวิดีโอผลงาน</span>
                <span className="block truncate text-xs text-lilac-200">{new URL(item.videoUrl!).hostname}</span>
              </span>
              <span className="text-lilac-300">เปิดลิงก์ ↗</span>
            </a>
          )}
        </div>

        {/* ข้อมูล */}
        <div className="space-y-4">
          <div className="card space-y-3 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip bg-lilac-400/20 text-lilac-50">{SUBCATEGORY_EMOJI[item.subcategory]} {SUBCATEGORY_LABELS[item.subcategory]}</span>
              {item.condition && (
                <span className="chip bg-amber-400/25 text-amber-100">{CONDITION_EMOJI[item.condition]} {CONDITION_LABELS[item.condition]}</span>
              )}
              {item.ownWorkConfirmed && (
                <span className="chip bg-emerald-400/20 text-emerald-200">✓ ยืนยันว่าเป็นผลงานของตนเอง</span>
              )}
            </div>
            <h1 className="text-2xl font-bold leading-snug text-lilac-50">{item.title}</h1>
            <p className={`font-display text-3xl font-bold ${sold ? 'text-lilac-200/70 line-through' : 'text-lilac-200'}`}>
              {formatPrice(item.price)}
              {isService && item.price > 0 && <span className="ml-1 text-sm font-medium text-lilac-200">(เริ่มต้น)</span>}
            </p>
            <p className="whitespace-pre-line text-[15px] leading-relaxed text-lilac-50">{item.description}</p>

            <dl className="pt-1">
              <Row label="📍 จุดนัดรับ">
                {item.meetupLocation}
                {item.meetupNote && <span className="mt-0.5 block font-normal text-lilac-100">{item.meetupNote}</span>}
              </Row>
              {item.subcategory === 'PROXY_ORDER' && item.waitDays != null && (
                <Row label="⏳ ระยะเวลารอสินค้า">ประมาณ {item.waitDays} วัน</Row>
              )}
              {item.subcategory === 'PROXY_ORDER' && trackingOk && (
                <Row label="📦 ติดตามคำสั่งซื้อ">
                  <a href={item.trackingUrl!} target="_blank" rel="noopener noreferrer" className="break-all text-lilac-200 underline">
                    {item.trackingUrl}
                  </a>
                </Row>
              )}
              {item.subcategory === 'PHOTOGRAPHY' && item.serviceAreaType && (
                <Row label="🗺️ พื้นที่รับงาน">
                  {SERVICE_AREA_LABELS[item.serviceAreaType]}
                  {item.serviceAreaDetail && <span className="block font-normal text-lilac-100">{item.serviceAreaDetail}</span>}
                </Row>
              )}
              <Row label="🕒 ลงประกาศ">{timeAgo(item.bumpedAt)}</Row>
            </dl>

            <Link
              to={`/sellers/${item.seller.id}`}
              className="flex items-center gap-3 rounded-xl border border-lilac-400/30 bg-lilac-400/10 px-3 py-2.5 transition hover:border-lilac-300 hover:shadow-glow"
            >
              <Avatar name={item.seller.name} url={item.seller.avatarUrl} size={40} />
              <div className="min-w-0 flex-1 text-sm">
                <p className="text-xs text-lilac-200">🧑‍🎓 ผู้ขาย</p>
                <UserLabel name={item.seller.name} studentId={item.seller.studentId} className="text-lilac-50" />
              </div>
              <span className="text-xs text-lilac-300">ดูโปรไฟล์ →</span>
            </Link>
          </div>

          {/* คำเตือนเฉพาะรับหิ้ว/พรีออเดอร์ (ผู้ขายแก้ไขไม่ได้) */}
          {item.subcategory === 'PROXY_ORDER' && (
            <div className="rounded-2xl border-2 border-rose-400/50 bg-rose-500/15 p-4 text-sm text-rose-200" role="note">
              <p className="mb-1 font-display text-base font-bold">🚨 ระวังความเสี่ยงการโอนเงินล่วงหน้า</p>
              <p className="leading-relaxed">{PROXY_ORDER_WARNING}</p>
            </div>
          )}

          {/* ติดต่อผู้ขาย */}
          <div className="card space-y-3 p-5">
            <h2 className="text-base font-semibold text-lilac-50">💬 ติดต่อผู้ขาย</h2>
            {item.isOwner ? (
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm text-lilac-200">นี่คือประกาศของคุณ</p>
                <Link to={`/listings/${item.id}/edit`} className="btn-secondary btn-sm">
                  ✏️ แก้ไขประกาศ
                </Link>
              </div>
            ) : (
              <ContactButtons line={item.contactLine} instagram={item.contactInstagram} facebook={item.contactFacebook} />
            )}
          </div>

          {/* ป้ายคำเตือนมาตรฐาน (แสดงทุกโพสต์) */}
          <div className="rounded-2xl border border-amber-400/50 bg-amber-400/15 p-4 text-sm text-amber-100" role="note">
            <p className="mb-1.5 font-display text-base font-bold">⚠️ ข้อควรระวังก่อนซื้อ</p>
            <ul className="list-disc space-y-1 pl-5 leading-relaxed">
              {SAFETY_NOTICES.map((n) => (
                <li key={n}>{n}</li>
              ))}
            </ul>
          </div>

          {!item.isOwner && !item.deletedAt && (
            <button type="button" className="btn-secondary w-full text-rose-200" onClick={() => setReporting(true)}>
              🚩 รายงานประกาศนี้
            </button>
          )}
          {item.isOwner && (
            <p className="text-center text-xs text-lilac-200/70">🗓️ ลงเมื่อ {formatDateTime(item.createdAt)}</p>
          )}
        </div>
      </div>

      {reporting && <ReportModal listingId={item.id} onClose={() => setReporting(false)} />}
    </div>
  );
}
