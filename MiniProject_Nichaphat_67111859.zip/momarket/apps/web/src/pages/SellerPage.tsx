import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import type { SellerProfileDTO } from '@momarket/shared';
import ListingCard from '../components/ListingCard';
import { Avatar, EmptyState, ErrorBox, SkeletonGrid, UserLabel } from '../components/ui';
import { api, errMsg } from '../lib/api';

export default function SellerPage() {
  const { id } = useParams();
  const [data, setData] = useState<SellerProfileDTO | null>(null);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'ACTIVE' | 'SOLD'>('ACTIVE');

  useEffect(() => {
    let cancelled = false;
    setData(null);
    setError('');
    api
      .get<SellerProfileDTO>(`/users/${id}`)
      .then((r) => !cancelled && setData(r.data))
      .catch((e) => !cancelled && setError(errMsg(e)));
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (error)
    return (
      <div className="space-y-4">
        <ErrorBox message={error} />
        <Link to="/market" className="btn-secondary">
          ← กลับตลาด
        </Link>
      </div>
    );
  if (!data) return <SkeletonGrid count={4} />;

  const shown = data.items.filter((i) => i.status === tab);

  return (
    <div className="space-y-5">
      <Link to="/market" className="text-sm font-medium text-lilac-300 hover:text-lilac-50">
        ← กลับไปตลาด
      </Link>

      <section className="card relative flex flex-wrap items-center gap-5 overflow-hidden p-6 shadow-glow">
        <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-lilac-600/40 blur-3xl" aria-hidden />
        <div className="rounded-full ring-4 ring-lilac-400/50 shadow-[0_0_24px_rgb(157_113_232/0.6)]">
          <Avatar name={data.user.name} url={data.user.avatarUrl} size={76} />
        </div>
        <div className="relative min-w-0 flex-1">
          <p className="text-xs text-lilac-200">🏪 ร้านของ</p>
          <h1 className="text-2xl font-bold">
            <UserLabel name={data.user.name} studentId={data.user.studentId} />
          </h1>
          <p className="mt-1 text-sm text-lilac-200">
            📅 เป็นสมาชิกตั้งแต่ {new Date(data.joinedAt).toLocaleDateString('th-TH', { dateStyle: 'long' })}
          </p>
        </div>
        <div className="relative flex gap-3 text-center">
          <div className="rounded-xl bg-lilac-400/15 px-4 py-2">
            <p className="font-display text-2xl font-bold text-glow">{data.activeCount}</p>
            <p className="text-xs text-lilac-200">🟢 กำลังขาย</p>
          </div>
          <div className="rounded-xl bg-lilac-400/15 px-4 py-2">
            <p className="font-display text-2xl font-bold text-glow">{data.soldCount}</p>
            <p className="text-xs text-lilac-200">✅ ขายแล้ว</p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-1.5 rounded-2xl bg-ink-900/80 p-1.5" role="tablist">
        {(['ACTIVE', 'SOLD'] as const).map((t) => (
          <button
            key={t}
            type="button"
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`cursor-pointer rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              tab === t ? 'bg-lilac-600 text-white shadow-[0_0_18px_rgb(106_47_200/0.8)]' : 'text-lilac-200 hover:bg-lilac-400/15'
            }`}
          >
            {t === 'ACTIVE' ? '🟢 กำลังวางขายอยู่' : '✅ ขายแล้ว'}
          </button>
        ))}
      </div>

      {shown.length === 0 ? (
        <EmptyState emoji={tab === 'ACTIVE' ? '🌙' : '📭'} title={tab === 'ACTIVE' ? 'ตอนนี้ไม่มีประกาศที่กำลังขาย' : 'ยังไม่มีรายการที่ขายแล้ว'} />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
          {shown.map((it) => (
            <ListingCard key={it.id} item={it} />
          ))}
        </div>
      )}
    </div>
  );
}
