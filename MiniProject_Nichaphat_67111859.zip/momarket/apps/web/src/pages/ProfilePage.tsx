import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  LISTING_TYPE_LABELS,
  SUBCATEGORY_EMOJI,
  SUBCATEGORY_LABELS,
  type MyListingDTO,
  type WarningDTO,
} from '@momarket/shared';
import NameModal from '../components/NameModal';
import { Avatar, EmptyState, ErrorBox, ImagePlaceholder, Modal, SkeletonGrid, Spinner, StatusBadge, UserLabel } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { api, errMsg, parseApiError } from '../lib/api';
import { formatDateTime, formatPrice, timeAgo } from '../lib/format';

type Tab = 'active' | 'sold' | 'warnings';

function ListingRow({
  item,
  onChange,
  onDelete,
}: {
  item: MyListingDTO;
  onChange: (l: MyListingDTO) => void;
  onDelete: (l: MyListingDTO) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const sold = item.status === 'SOLD';
  const canBump = !sold && (!item.nextBumpAt || new Date(item.nextBumpAt) <= new Date());

  const toggleStatus = async () => {
    setBusy(true);
    try {
      const r = await api.patch<MyListingDTO>(`/listings/${item.id}/status`, { status: sold ? 'ACTIVE' : 'SOLD' });
      onChange(r.data);
      toast.success(sold ? 'เปลี่ยนเป็น “กำลังขายอยู่” แล้ว' : 'ทำเครื่องหมาย “ขายแล้ว” แล้ว');
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const bump = async () => {
    setBusy(true);
    try {
      const r = await api.post<MyListingDTO>(`/listings/${item.id}/bump`);
      onChange(r.data);
      toast.success('ดันประกาศแล้ว ประกาศของคุณขึ้นไปอยู่บนสุด');
    } catch (e) {
      const pe = parseApiError(e);
      if (pe.code === 'BUMP_COOLDOWN' && typeof pe.data?.nextBumpAt === 'string') {
        onChange({ ...item, nextBumpAt: pe.data.nextBumpAt });
      }
      toast.error(pe.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <li className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center">
      <Link to={`/listings/${item.id}`} className="flex min-w-0 flex-1 items-center gap-3">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-lilac-400/10">
          {item.coverUrl ? (
            <img src={item.coverUrl} alt="" className={`h-full w-full object-cover ${sold ? 'opacity-60 grayscale' : ''}`} />
          ) : (
            <ImagePlaceholder label={item.title} className="text-xl" />
          )}
        </div>
        <div className="min-w-0">
          <div className="mb-0.5 flex flex-wrap items-center gap-1.5">
            <StatusBadge status={item.status} />
            <span className="chip bg-lilac-400/10 text-lilac-50">
              {SUBCATEGORY_EMOJI[item.subcategory]} {LISTING_TYPE_LABELS[item.type]} · {SUBCATEGORY_LABELS[item.subcategory]}
            </span>
          </div>
          <p className="truncate font-semibold text-lilac-50">{item.title}</p>
          <p className="text-sm text-lilac-200">
            <span className="font-semibold text-lilac-200">{formatPrice(item.price)}</span> · 📍 {item.meetupLocation} · 🚀 ดันล่าสุด{' '}
            {timeAgo(item.bumpedAt)}
          </p>
        </div>
      </Link>

      <div className="flex flex-wrap gap-1.5 sm:justify-end">
        <button type="button" className="btn-secondary btn-sm" onClick={toggleStatus} disabled={busy}>
          {sold ? '↩️ กลับมาขายอีกครั้ง' : '✅ เปลี่ยนเป็นขายแล้ว'}
        </button>
        <Link to={`/listings/${item.id}/edit`} className="btn-secondary btn-sm">
          ✏️ แก้ไข
        </Link>
        <button
          type="button"
          className="btn-secondary btn-sm"
          onClick={bump}
          disabled={busy || !canBump}
          title={
            sold
              ? 'ประกาศที่ขายแล้วดันไม่ได้'
              : !canBump && item.nextBumpAt
                ? `ดันได้อีกครั้ง ${formatDateTime(item.nextBumpAt)}`
                : 'ดันประกาศขึ้นบนสุด (วันละ 1 ครั้ง)'
          }
        >
          🚀 ดันประกาศ
        </button>
        <button type="button" className="btn-sm btn text-rose-200 hover:bg-rose-500/15" onClick={() => onDelete(item)} disabled={busy}>
          🗑️ ลบ
        </button>
      </div>
      {!canBump && !sold && item.nextBumpAt && (
        <p className="text-xs text-lilac-200 sm:hidden">ดันได้อีกครั้ง {formatDateTime(item.nextBumpAt)}</p>
      )}
    </li>
  );
}

export default function ProfilePage() {
  const { user } = useAuth();
  const toast = useToast();
  const [sp, setSp] = useSearchParams();
  const rawTab: Tab = sp.get('tab') === 'sold' ? 'sold' : sp.get('tab') === 'warnings' ? 'warnings' : 'active';

  const [items, setItems] = useState<MyListingDTO[] | null>(null);
  const [warnings, setWarnings] = useState<WarningDTO[] | null>(null);
  const [error, setError] = useState('');
  const [deleting, setDeleting] = useState<MyListingDTO | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [editingName, setEditingName] = useState(false);

  const load = useCallback(() => {
    setError('');
    api
      .get<{ items: MyListingDTO[] }>('/listings/mine')
      .then((r) => setItems(r.data.items))
      .catch((e) => setError(errMsg(e)));
    api
      .get<{ items: WarningDTO[] }>('/warnings')
      .then((r) => setWarnings(r.data.items))
      .catch((e) => setError(errMsg(e)));
  }, []);

  useEffect(load, [load]);

  if (!user) return null;
  const isAdmin = user.role === 'ADMIN';
  const tab: Tab = isAdmin ? 'warnings' : rawTab;

  const replace = (l: MyListingDTO) => setItems((prev) => prev?.map((x) => (x.id === l.id ? l : x)) ?? prev);

  const confirmDelete = async () => {
    if (!deleting) return;
    setDeleteBusy(true);
    try {
      await api.delete(`/listings/${deleting.id}`);
      setItems((prev) => prev?.filter((x) => x.id !== deleting.id) ?? prev);
      toast.success('ลบประกาศแล้ว');
      setDeleting(null);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setDeleteBusy(false);
    }
  };

  const active = items?.filter((i) => i.status === 'ACTIVE') ?? [];
  const sold = items?.filter((i) => i.status === 'SOLD') ?? [];
  const shown = tab === 'active' ? active : sold;

  const tabs: { key: Tab; label: string; count?: number }[] = [
    { key: 'active', label: '🟢 กำลังวางขายอยู่', count: items ? active.length : undefined },
    { key: 'sold', label: '✅ ขายแล้ว', count: items ? sold.length : undefined },
    { key: 'warnings', label: '⚠️ ประวัติคำเตือน', count: warnings?.length },
  ];

  return (
    <div className="space-y-5">
      <section className="card flex flex-wrap items-center gap-4 p-5">
        <Avatar name={user.name} url={user.avatarUrl} size={72} />
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold text-lilac-50">
            <UserLabel name={user.name} studentId={user.studentId} />
          </h1>
          <p className="truncate text-sm text-lilac-200">📧 {user.email}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            {isAdmin && <span className="chip bg-amber-400/25 text-amber-100">🛡️ ผู้ดูแลระบบ</span>}
            <button type="button" className="btn-secondary btn-sm" onClick={() => setEditingName(true)}>
              ✏️ เปลี่ยนชื่อที่แสดง
            </button>
            {!isAdmin && (
              <Link to={`/sellers/${user.id}`} className="btn-secondary btn-sm">
                👀 ดูหน้าโปรไฟล์ของฉัน
              </Link>
            )}
          </div>
        </div>
        {isAdmin ? (
          <Link to="/admin" className="btn-primary">
            📊 ไปแดชบอร์ดแอดมิน
          </Link>
        ) : (
          <Link to="/listings/new" className="btn-primary">
            ➕ ลงประกาศใหม่
          </Link>
        )}
      </section>

      {isAdmin && (
        <div className="card border-amber-400/50 p-4 text-sm text-amber-100">
          🛡️ บัญชีผู้ดูแลระบบใช้ตรวจสอบรายงานและจัดการผู้ใช้เท่านั้น — ลงประกาศซื้อขายไม่ได้
        </div>
      )}

      <div className="flex gap-1 overflow-x-auto rounded-2xl bg-ink-900/80 p-1.5 ring-1 ring-lilac-400/30" role="tablist">
        {(isAdmin ? tabs.filter((t) => t.key === 'warnings') : tabs).map((t) => (
          <button
            key={t.key}
            type="button"
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => setSp(t.key === 'active' ? {} : { tab: t.key }, { replace: true })}
            className={`shrink-0 cursor-pointer whitespace-nowrap rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              tab === t.key ? 'bg-lilac-600 text-white shadow-[0_0_14px_rgb(157_113_232/0.7)]' : 'text-lilac-100 hover:bg-lilac-400/15'
            }`}
          >
            {t.label}
            {t.count !== undefined && <span className="ml-1.5 text-xs opacity-70">({t.count})</span>}
          </button>
        ))}
      </div>

      {error && <ErrorBox message={error} onRetry={load} />}

      {tab === 'warnings' ? (
        warnings === null ? (
          <Spinner />
        ) : warnings.length === 0 ? (
          <EmptyState emoji="😇" title="ยังไม่มีคำเตือน" hint="ขอบคุณที่ปฏิบัติตามกฎกติกาของ momarket 💜" />
        ) : (
          <ul className="space-y-2">
            {warnings.map((w) => (
              <li key={w.id} className="card border-amber-400/50 bg-amber-400/10 p-4">
                <p className="whitespace-pre-line text-sm font-medium text-amber-100">{w.message}</p>
                <p className="mt-1.5 text-xs text-amber-200">
                  🕒 ออกเมื่อ {formatDateTime(w.createdAt)} ·{' '}
                  {w.acknowledgedAt ? `✅ รับทราบเมื่อ ${formatDateTime(w.acknowledgedAt)}` : 'ยังไม่ได้กดรับทราบ'}
                </p>
              </li>
            ))}
          </ul>
        )
      ) : items === null ? (
        <SkeletonGrid count={4} />
      ) : shown.length === 0 ? (
        <EmptyState
          emoji={tab === 'active' ? '📭' : '🏷️'}
          title={tab === 'active' ? 'ยังไม่มีประกาศที่กำลังขาย' : 'ยังไม่มีรายการที่ขายแล้ว'}
          action={
            tab === 'active' ? (
              <Link to="/listings/new" className="btn-primary">
                ➕ ลงประกาศ
              </Link>
            ) : undefined
          }
        />
      ) : (
        <ul className="space-y-3">
          {shown.map((it) => (
            <ListingRow key={it.id} item={it} onChange={replace} onDelete={setDeleting} />
          ))}
        </ul>
      )}

      {editingName && <NameModal mode="edit" onClose={() => setEditingName(false)} />}

      {deleting && (
        <Modal title="ลบประกาศนี้?" onClose={() => setDeleting(null)} size="sm">
          <p className="mb-4 text-sm text-lilac-100">
            “<b>{deleting.title}</b>” จะถูกลบออกจากตลาดและกู้คืนไม่ได้
          </p>
          <div className="flex justify-end gap-2">
            <button type="button" className="btn-ghost" onClick={() => setDeleting(null)}>
              ยกเลิก
            </button>
            <button type="button" className="btn-danger" onClick={confirmDelete} disabled={deleteBusy}>
              {deleteBusy ? 'กำลังลบ…' : 'ลบประกาศ'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
