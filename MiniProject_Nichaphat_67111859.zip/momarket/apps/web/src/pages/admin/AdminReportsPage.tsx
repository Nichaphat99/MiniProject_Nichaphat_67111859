import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  REPORT_REASON_EMOJI,
  REPORT_REASON_LABELS,
  REPORT_STATUS_LABELS,
  SUBCATEGORY_LABELS,
  TEMP_BAN_DAYS,
  isHttpsUrl,
  type AdminReportDTO,
  type Paginated,
  type ReportStatus,
} from '@momarket/shared';
import { instagramUrl, lineUrl } from '../../components/ContactButtons';
import { EmptyState, ErrorBox, FieldError, Modal, Spinner, UserLabel } from '../../components/ui';
import { useToast } from '../../context/ToastContext';
import { api, errMsg } from '../../lib/api';
import { formatDateTime } from '../../lib/format';

type Filter = ReportStatus | 'ALL';
type ActionKind = 'delete' | 'warn' | 'ban-temp' | 'ban-permanent' | 'dismiss';

const FILTERS: { key: Filter; label: string }[] = [
  { key: 'PENDING', label: 'รอตรวจสอบ' },
  { key: 'RESOLVED', label: 'ดำเนินการแล้ว' },
  { key: 'DISMISSED', label: 'ไม่พบความผิด' },
  { key: 'ALL', label: 'ทั้งหมด' },
];

const ACTION_META: Record<ActionKind, { title: string; button: string; danger: boolean; needsText: false | 'required' | 'optional'; hint: string }> = {
  delete: {
    title: 'ลบโพสต์ต้นทาง',
    button: 'ลบโพสต์',
    danger: true,
    needsText: false,
    hint: 'โพสต์จะถูกซ่อนจากตลาด (เก็บสำเนาไว้เป็นหลักฐาน) และรายงานที่ค้างของโพสต์นี้จะถูกปิดทั้งหมด',
  },
  warn: {
    title: 'ส่งคำเตือน (Warning)',
    button: 'ส่งคำเตือน',
    danger: false,
    needsText: 'required',
    hint: 'ผู้ใช้จะเห็นหน้าต่างบังคับกดรับทราบเมื่อเข้าเว็บครั้งถัดไป และมีประวัติในหน้าโปรไฟล์',
  },
  'ban-temp': {
    title: `แบนชั่วคราว ${TEMP_BAN_DAYS} วัน`,
    button: `แบน ${TEMP_BAN_DAYS} วัน`,
    danger: true,
    needsText: 'optional',
    hint: 'ผู้ใช้จะล็อกอินไม่ได้ และประกาศทั้งหมดถูกซ่อนจนครบกำหนด',
  },
  'ban-permanent': {
    title: 'แบนถาวร (บล็อกอีเมล DPU)',
    button: 'แบนถาวร',
    danger: true,
    needsText: 'optional',
    hint: 'อีเมลนี้จะล็อกอิน/สมัครใหม่ไม่ได้อีก ใช้เมื่อฝ่าฝืนร้ายแรงเท่านั้น',
  },
  dismiss: {
    title: 'ปิดรายงาน: ไม่พบความผิด',
    button: 'ปิดรายงาน',
    danger: false,
    needsText: 'optional',
    hint: 'ไม่ดำเนินการกับผู้ถูกรายงาน',
  },
};

function AccountBadge({ r }: { r: AdminReportDTO['reportedUser'] }) {
  if (r.accountStatus === 'PERMANENT_BANNED') return <span className="chip bg-rose-600 text-white">แบนถาวร</span>;
  if (r.accountStatus === 'TEMP_BANNED')
    return <span className="chip bg-orange-500 text-white">แบนถึง {r.bannedUntil && formatDateTime(r.bannedUntil)}</span>;
  return <span className="chip bg-emerald-400/20 text-emerald-200">ปกติ</span>;
}

function ActionModal({
  kind,
  report,
  onClose,
  onDone,
}: {
  kind: ActionKind;
  report: AdminReportDTO;
  onClose: () => void;
  onDone: () => void;
}) {
  const toast = useToast();
  const meta = ACTION_META[kind];
  const [text, setText] = useState(kind === 'warn' ? `ประกาศ “${report.snapshot.title}” ถูกรายงานว่า${REPORT_REASON_LABELS[report.reason]} กรุณาปฏิบัติตามกฎกติกาของ momarket` : '');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (meta.needsText === 'required' && text.trim().length < 5) {
      setError('กรุณาระบุข้อความอย่างน้อย 5 ตัวอักษร');
      return;
    }
    setBusy(true);
    setError('');
    const uid = report.reportedUser.id;
    const reportId = report.id;
    try {
      if (kind === 'delete') await api.post(`/admin/listings/${report.listing.id}/delete`, { reportId });
      else if (kind === 'warn') await api.post(`/admin/users/${uid}/warn`, { message: text, reportId });
      else if (kind === 'ban-temp') await api.post(`/admin/users/${uid}/ban-temp`, { reason: text, reportId });
      else if (kind === 'ban-permanent') await api.post(`/admin/users/${uid}/ban-permanent`, { reason: text, reportId });
      else await api.post(`/admin/reports/${reportId}/resolve`, { status: 'DISMISSED', note: text });
      toast.success('ดำเนินการเรียบร้อย');
      onDone();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={meta.title} onClose={onClose}>
      <p className="text-sm text-lilac-100">
        {kind === 'delete' ? (
          <>
            โพสต์: <b>{report.listing.title}</b>
          </>
        ) : kind === 'dismiss' ? (
          <>
            รายงานโพสต์: <b>{report.listing.title}</b>
          </>
        ) : (
          <>
            ผู้ใช้: <UserLabel name={report.reportedUser.name} studentId={report.reportedUser.studentId} /> ({report.reportedUser.email})
          </>
        )}
      </p>
      <p className="mt-1 text-xs text-lilac-200">{meta.hint}</p>

      {meta.needsText && (
        <div className="mt-3">
          <label className="label" htmlFor="admin-text">
            {kind === 'warn' ? 'ข้อความคำเตือน' : kind === 'dismiss' ? 'หมายเหตุ (ไม่บังคับ)' : 'เหตุผล (ไม่บังคับ)'}
          </label>
          <textarea id="admin-text" className="input min-h-24" maxLength={500} value={text} onChange={(e) => setText(e.target.value)} />
        </div>
      )}
      <FieldError message={error} />

      <div className="mt-4 flex justify-end gap-2">
        <button type="button" className="btn-ghost" onClick={onClose}>
          ยกเลิก
        </button>
        <button type="button" className={meta.danger ? 'btn-danger' : 'btn-primary'} onClick={submit} disabled={busy}>
          {busy ? 'กำลังดำเนินการ…' : meta.button}
        </button>
      </div>
    </Modal>
  );
}

function ContactCell({ s }: { s: AdminReportDTO['snapshot'] }) {
  const none = !s.contactLine && !s.contactInstagram && !s.contactFacebook;
  return (
    <ul className="space-y-1 text-xs">
      {s.contactLine && (
        <li>
          LINE:{' '}
          <a href={lineUrl(s.contactLine)} target="_blank" rel="noopener noreferrer" className="font-medium text-lilac-200 underline">
            {s.contactLine}
          </a>
        </li>
      )}
      {s.contactInstagram && (
        <li>
          IG:{' '}
          <a href={instagramUrl(s.contactInstagram)} target="_blank" rel="noopener noreferrer" className="font-medium text-lilac-200 underline">
            @{s.contactInstagram}
          </a>
        </li>
      )}
      {s.contactFacebook && (
        <li>
          FB:{' '}
          {isHttpsUrl(s.contactFacebook) ? (
            <a href={s.contactFacebook} target="_blank" rel="noopener noreferrer" className="break-all font-medium text-lilac-200 underline">
              เปิดโปรไฟล์ ↗
            </a>
          ) : (
            <span className="break-all">{s.contactFacebook}</span>
          )}
        </li>
      )}
      {none && <li className="text-lilac-200/70">—</li>}
    </ul>
  );
}

export default function AdminReportsPage() {
  const toast = useToast();
  const [filter, setFilter] = useState<Filter>('PENDING');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Paginated<AdminReportDTO> | null>(null);
  const [error, setError] = useState('');
  const [action, setAction] = useState<{ kind: ActionKind; report: AdminReportDTO } | null>(null);

  const load = useCallback(() => {
    setError('');
    api
      .get<Paginated<AdminReportDTO>>('/admin/reports', { params: { status: filter, page, limit: 20 } })
      .then((r) => setData(r.data))
      .catch((e) => setError(errMsg(e)));
  }, [filter, page]);

  useEffect(() => {
    setData(null);
    load();
  }, [load]);

  const unban = async (r: AdminReportDTO) => {
    try {
      await api.post(`/admin/users/${r.reportedUser.id}/unban`);
      toast.success('ปลดแบนแล้ว');
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">🚩 รายงานที่ได้รับ</h1>
        <p className="text-sm text-lilac-200">ตรวจสอบเหตุผล ดูโพสต์ต้นทาง ตรวจคอนแทค แล้วเลือกดำเนินการ</p>
      </div>

      <div className="flex gap-1 overflow-x-auto rounded-2xl bg-ink-900/80 p-1.5" role="tablist">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            type="button"
            role="tab"
            aria-selected={filter === f.key}
            onClick={() => {
              setFilter(f.key);
              setPage(1);
            }}
            className={`shrink-0 cursor-pointer whitespace-nowrap rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              filter === f.key ? 'bg-ink-900 text-lilac-50 shadow-sm' : 'text-lilac-200/70 hover:text-lilac-50'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error && <ErrorBox message={error} onRetry={load} />}

      {!data ? (
        <Spinner />
      ) : data.items.length === 0 ? (
        <EmptyState title="ไม่มีรายงานในหมวดนี้" hint="เยี่ยมมาก! ตอนนี้ไม่มีเรื่องรอตรวจสอบ 🎉" />
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[1080px] text-left text-sm">
            <thead className="border-b border-lilac-400/25 bg-lilac-400/10 text-xs uppercase tracking-wide text-lilac-50">
              <tr>
                <th className="px-4 py-3">เหตุผล / เวลา</th>
                <th className="px-4 py-3">ผู้รายงาน</th>
                <th className="px-4 py-3">ผู้ถูกรายงาน</th>
                <th className="px-4 py-3">โพสต์ต้นทาง</th>
                <th className="px-4 py-3">คอนแทค (ณ ตอนถูกรายงาน)</th>
                <th className="px-4 py-3">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-lilac-400/15 align-top">
              {data.items.map((r) => {
                const pending = r.status === 'PENDING';
                const targetIsAdmin = r.reportedUser.role === 'ADMIN';
                return (
                  <tr key={r.id} className={pending ? '' : 'bg-white/5'}>
                    <td className="max-w-[220px] px-4 py-3">
                      <span className="chip bg-rose-400/20 text-rose-200">{REPORT_REASON_EMOJI[r.reason]} {REPORT_REASON_LABELS[r.reason]}</span>
                      {r.detail && <p className="mt-1.5 whitespace-pre-line break-words text-xs text-lilac-100">“{r.detail}”</p>}
                      <p className="mt-1.5 text-xs text-lilac-200/70">{formatDateTime(r.createdAt)}</p>
                      <p className="mt-1 text-xs font-medium text-lilac-200">
                        {REPORT_STATUS_LABELS[r.status]}
                        {!pending && r.resolvedByName && ` · โดย ${r.resolvedByName}`}
                      </p>
                      {r.resolutionNote && <p className="text-xs text-lilac-200/70">{r.resolutionNote}</p>}
                    </td>
                    <td className="px-4 py-3">
                      <UserLabel name={r.reporter.name} studentId={r.reporter.studentId} className="text-lilac-50" />
                      <p className="break-all text-xs text-lilac-200">{r.reporter.email}</p>
                    </td>
                    <td className="px-4 py-3">
                      <UserLabel name={r.reportedUser.name} studentId={r.reportedUser.studentId} className="text-lilac-50" />
                      <p className="break-all text-xs text-lilac-200">{r.reportedUser.email}</p>
                      <div className="mt-1.5">
                        <AccountBadge r={r.reportedUser} />
                      </div>
                      <p className="mt-1 text-xs text-lilac-200">
                        ถูกเตือน {r.reportedUser.warningCount} ครั้ง · ถูกรายงาน {r.reportedUser.reportCount} ครั้ง
                      </p>
                    </td>
                    <td className="max-w-[220px] px-4 py-3">
                      <Link to={`/listings/${r.listing.id}`} className="font-medium text-lilac-200 underline" target="_blank">
                        {r.snapshot.title} ↗
                      </Link>
                      <p className="mt-1 text-xs text-lilac-200">{SUBCATEGORY_LABELS[r.snapshot.subcategory]}</p>
                      {r.listing.deleted && <span className="chip mt-1 bg-white/15 text-lilac-50">ถูกลบแล้ว</span>}
                    </td>
                    <td className="px-4 py-3">
                      <ContactCell s={r.snapshot} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex min-w-[150px] flex-col gap-1.5">
                        {!r.listing.deleted && (
                          <button type="button" className="btn-secondary btn-sm justify-start text-rose-200" onClick={() => setAction({ kind: 'delete', report: r })}>
                            🗑️ ลบโพสต์
                          </button>
                        )}
                        {!targetIsAdmin && (
                          <>
                            <button type="button" className="btn-secondary btn-sm justify-start" onClick={() => setAction({ kind: 'warn', report: r })}>
                              ⚠️ ส่งคำเตือน
                            </button>
                            <button type="button" className="btn-secondary btn-sm justify-start" onClick={() => setAction({ kind: 'ban-temp', report: r })}>
                              ⏳ แบน {TEMP_BAN_DAYS} วัน
                            </button>
                            <button type="button" className="btn-secondary btn-sm justify-start text-rose-200" onClick={() => setAction({ kind: 'ban-permanent', report: r })}>
                              ⛔ แบนถาวร
                            </button>
                            {r.reportedUser.accountStatus !== 'ACTIVE' && (
                              <button type="button" className="btn-ghost btn-sm justify-start" onClick={() => unban(r)}>
                                ↩️ ปลดแบน
                              </button>
                            )}
                          </>
                        )}
                        {pending && (
                          <button type="button" className="btn-ghost btn-sm justify-start" onClick={() => setAction({ kind: 'dismiss', report: r })}>
                            ✔️ ไม่พบความผิด
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {data && totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 text-sm">
          <button type="button" className="btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            ← ก่อนหน้า
          </button>
          <span className="text-lilac-200">
            หน้า {page} / {totalPages}
          </span>
          <button type="button" className="btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
            ถัดไป →
          </button>
        </div>
      )}

      {action && (
        <ActionModal
          kind={action.kind}
          report={action.report}
          onClose={() => setAction(null)}
          onDone={() => {
            setAction(null);
            load();
          }}
        />
      )}
    </div>
  );
}
