import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import {
  REPORT_REASON_EMOJI,
  REPORT_REASON_LABELS,
  SUBCATEGORY_EMOJI,
  SUBCATEGORY_LABELS,
  typeOfSubcategory,
  type AdminOverview,
} from '@momarket/shared';
import { AreaChart, BarList, Donut } from '../../components/charts';
import { ErrorBox, Spinner } from '../../components/ui';
import { api, errMsg } from '../../lib/api';

function Kpi({
  emoji,
  label,
  value,
  sub,
  to,
  alert = false,
}: {
  emoji: string;
  label: string;
  value: number;
  sub?: string;
  to?: string;
  alert?: boolean;
}) {
  const body = (
    <div className={`card flex h-full items-center gap-3.5 p-4 ${alert ? 'animate-pulse-glow border-rose-400/70' : ''} ${to ? 'card-glow' : ''}`}>
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-lilac-400/20 text-2xl shadow-[0_0_16px_rgb(157_113_232/0.45)]" aria-hidden>
        {emoji}
      </div>
      <div className="min-w-0">
        <p className="truncate text-xs text-lilac-200">{label}</p>
        <p className="text-glow font-display text-3xl font-bold leading-tight text-lilac-50">{value.toLocaleString('th-TH')}</p>
        {sub && <p className="truncate text-xs text-emerald-300">{sub}</p>}
      </div>
    </div>
  );
  return to ? (
    <Link to={to} className="block">
      {body}
    </Link>
  ) : (
    body
  );
}

function Panel({ title, total, children }: { title: string; total?: string; children: ReactNode }) {
  return (
    <section className="card p-5">
      <div className="mb-3 flex items-baseline justify-between gap-2">
        <h2 className="text-base font-semibold">{title}</h2>
        {total && <span className="text-xs text-lilac-200">{total}</span>}
      </div>
      {children}
    </section>
  );
}

export default function AdminOverviewPage() {
  const [data, setData] = useState<AdminOverview | null>(null);
  const [error, setError] = useState('');

  const load = () => {
    setError('');
    api
      .get<AdminOverview>('/admin/overview')
      .then((r) => setData(r.data))
      .catch((e) => setError(errMsg(e)));
  };
  useEffect(load, []);

  if (error) return <ErrorBox message={error} onRetry={load} />;
  if (!data) return <Spinner />;

  const { kpis } = data;
  const sum = (rows: { count: number }[]) => rows.reduce((s, r) => s + r.count, 0);
  const products = data.listingsByCategory.filter((c) => typeOfSubcategory(c.subcategory) === 'PRODUCT').reduce((s, c) => s + c.count, 0);
  const services = data.listingsByCategory.filter((c) => typeOfSubcategory(c.subcategory) === 'SERVICE').reduce((s, c) => s + c.count, 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">📊 ภาพรวมระบบ</h1>
        <p className="text-sm text-lilac-200">ตัวเลขสำคัญและแนวโน้ม 30 วันล่าสุด (เวลาไทย)</p>
      </div>

      {/* ตัวเลขสำคัญ (บน) */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
        <Kpi emoji="👥" label="ผู้ใช้งานทั้งหมด" value={kpis.totalUsers} sub={kpis.newUsers7d > 0 ? `▲ +${kpis.newUsers7d} ใน 7 วัน` : undefined} to="/admin/users" />
        <Kpi emoji="🛍️" label="โพสต์ที่กำลังขาย" value={kpis.activeListings} />
        <Kpi emoji="✅" label="ขายแล้ว" value={kpis.soldListings} />
        <Kpi emoji="🚩" label="รายงานที่รอตรวจสอบ" value={kpis.pendingReports} to="/admin/reports" alert={kpis.pendingReports > 0} />
        <Kpi emoji="🆕" label="สมัครใหม่ใน 7 วัน" value={kpis.newUsers7d} />
        <Kpi emoji="⛔" label="บัญชีที่ถูกแบน" value={kpis.bannedUsers} to="/admin/users" />
      </div>

      {/* กราฟ (ล่าง) */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="👥 ผู้ใช้ใหม่รายวัน" total={`รวม ${sum(data.usersPerDay)} คน`}>
          <AreaChart data={data.usersPerDay} color="#9D71E8" unit="คน" />
        </Panel>
        <Panel title="🛍️ ประกาศใหม่รายวัน" total={`รวม ${sum(data.listingsPerDay)} รายการ`}>
          <AreaChart data={data.listingsPerDay} color="#D1B8FF" unit="รายการ" />
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="🧩 สินค้า vs บริการ" total="เฉพาะที่กำลังขาย">
          <Donut
            segments={[
              { label: '🛍️ สินค้า', value: products, color: '#9D71E8' },
              { label: '🧑‍💻 บริการ', value: services, color: '#F2E9FF' },
            ]}
            center={
              <>
                <span className="text-glow font-display text-3xl font-bold">{products + services}</span>
                <span className="text-xs text-lilac-200">ประกาศ</span>
              </>
            }
          />
        </Panel>
        <Panel title="🧭 ประกาศแยกตามหมวด">
          <BarList
            rows={data.listingsByCategory.map((c) => ({
              key: c.subcategory,
              label: `${SUBCATEGORY_EMOJI[c.subcategory]} ${SUBCATEGORY_LABELS[c.subcategory]}`,
              value: c.count,
            }))}
          />
        </Panel>
        <Panel title="🚩 รายงานแยกตามเหตุผล" total="ทั้งหมดที่เคยได้รับ">
          <BarList
            color="#FB7185"
            rows={data.reportsByReason.map((r) => ({
              key: r.reason,
              label: `${REPORT_REASON_EMOJI[r.reason]} ${REPORT_REASON_LABELS[r.reason]}`,
              value: r.count,
            }))}
          />
        </Panel>
      </div>
    </div>
  );
}
