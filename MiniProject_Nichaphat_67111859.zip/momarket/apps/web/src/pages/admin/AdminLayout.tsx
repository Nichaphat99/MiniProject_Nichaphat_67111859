import { NavLink, Outlet } from 'react-router-dom';

const ITEMS = [
  { to: '/admin', end: true, emoji: '📊', label: 'ภาพรวม' },
  { to: '/admin/reports', end: false, emoji: '🚩', label: 'รายงาน' },
  { to: '/admin/users', end: false, emoji: '👥', label: 'ผู้ใช้งาน' },
  { to: '/admin/category-images', end: false, emoji: '🖼️', label: 'รูปภาพหมวดหมู่' },
];

/** โครงหน้าแอดมิน: เมนูอยู่ด้านซ้าย (มือถือเป็นแถบด้านบน) */
export default function AdminLayout() {
  return (
    <div className="grid gap-5 lg:grid-cols-[212px_minmax(0,1fr)]">
      <aside className="self-start lg:sticky lg:top-24">
        <nav className="card flex gap-1.5 overflow-x-auto p-2 lg:flex-col lg:gap-1 lg:p-3" aria-label="เมนูแอดมิน">
          <p className="hidden px-2 pb-1 pt-1 font-display text-sm font-semibold text-lilac-200 lg:block">🛡️ เมนูแอดมิน</p>
          {ITEMS.map((i) => (
            <NavLink
              key={i.to}
              to={i.to}
              end={i.end}
              className={({ isActive }) =>
                `flex shrink-0 items-center gap-2.5 whitespace-nowrap rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
                  isActive
                    ? 'bg-lilac-600 text-white shadow-[0_0_18px_rgb(106_47_200/0.9)]'
                    : 'text-lilac-100 hover:bg-lilac-400/15 hover:text-white'
                }`
              }
            >
              <span className="text-lg" aria-hidden>
                {i.emoji}
              </span>
              {i.label}
            </NavLink>
          ))}
          <p className="mt-2 hidden rounded-xl bg-lilac-400/10 p-2.5 text-xs leading-relaxed text-lilac-200 lg:block">
            ℹ️ ผู้ดูแลระบบตรวจรายงานและจัดการผู้ใช้เท่านั้น ลงประกาศซื้อขายไม่ได้
          </p>
        </nav>
      </aside>
      <section className="min-w-0">
        <Outlet />
      </section>
    </div>
  );
}
