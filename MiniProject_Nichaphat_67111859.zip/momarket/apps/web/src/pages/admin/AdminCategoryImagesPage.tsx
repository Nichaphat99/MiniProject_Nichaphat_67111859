import { useEffect, useState } from 'react';
import {
  ALL_SUBCATEGORIES,
  PRODUCT_SUBCATEGORIES,
  SUBCATEGORY_LABELS,
  type Subcategory,
  type ListingType,
  typeOfSubcategory,
} from '@momarket/shared';
import ImageUploader from '../../components/ImageUploader';
import { ErrorBox, Spinner } from '../../components/ui';
import { api, errMsg } from '../../lib/api';

interface CategoryImageRow {
  subcategory: Subcategory;
  imageUrl: string | null;
}

export default function AdminCategoryImagesPage() {
  const [rows, setRows] = useState<CategoryImageRow[]>([]);
  const [heroImageUrl, setHeroImageUrl] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState<Subcategory | null>(null);
  const [savingHero, setSavingHero] = useState(false);

  const load = () => {
    setError('');
    Promise.all([
      api.get<CategoryImageRow[]>('/admin/category-images'),
      api.get<{ imageUrl: string | null }>('/admin/category-images/hero-banner'),
    ])
      .then(([categories, hero]) => {
        setRows(categories.data);
        setHeroImageUrl(hero.data.imageUrl);
      })
      .catch((e) => setError(errMsg(e)));
  };
  useEffect(load, []);

  const save = async (subcategory: Subcategory, urls: string[]) => {
    setSaving(subcategory);
    setError('');
    try {
      const imageUrl = urls[0] ?? null;
      await api.put('/admin/category-images', { subcategory, imageUrl });
      setRows((current) =>
        current.map((row) => (row.subcategory === subcategory ? { ...row, imageUrl } : row)),
      );
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setSaving(null);
    }
  };

  const saveHero = async (urls: string[]) => {
    setSavingHero(true);
    setError('');
    try {
      const imageUrl = urls[0] ?? null;
      await api.put('/admin/category-images/hero-banner', { imageUrl });
      setHeroImageUrl(imageUrl);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setSavingHero(false);
    }
  };

  if (error && rows.length === 0) return <ErrorBox message={error} onRetry={load} />;
  if (rows.length === 0) return <Spinner />;

  const renderGroup = (type: ListingType) => (
    <section>
      <h2 className="mb-3 text-base font-semibold text-lilac-100">
        {type === 'PRODUCT' ? 'ซื้อขายสินค้า' : 'บริการและรับจ้าง'}
      </h2>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {rows
          .filter((row) => typeOfSubcategory(row.subcategory) === type)
          .map((row) => (
            <div key={row.subcategory} className="card p-4">
              <div className="mb-3">
                <p className="font-semibold">{SUBCATEGORY_LABELS[row.subcategory]}</p>
                <p className="mt-0.5 text-xs text-lilac-200">{row.subcategory}</p>
              </div>
              <ImageUploader
                value={row.imageUrl ? [row.imageUrl] : []}
                onChange={(urls) => void save(row.subcategory, urls)}
                max={1}
              />
              {saving === row.subcategory && <p className="mt-2 text-xs text-lilac-200">กำลังบันทึก...</p>}
            </div>
          ))}
      </div>
    </section>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">รูปภาพหมวดหมู่</h1>
        <p className="text-sm text-lilac-200">อัปโหลดหรือเปลี่ยนภาพแบนเนอร์และภาพหน้าปกที่แสดงบนหน้าแรก</p>
      </div>
      {error && <div className="rounded-xl border border-rose-400/50 bg-rose-400/10 p-3 text-sm text-rose-200">{error}</div>}
      <section className="card p-5">
        <div className="mb-3">
          <h2 className="text-base font-semibold">รูปภาพพื้นหลังแบนเนอร์หน้าแรก (Hero Banner Image)</h2>
          <p className="mt-1 text-sm text-lilac-200">แสดงเต็มกรอบด้านบนหน้าแรก หากไม่กำหนดจะใช้ Gradient ม่วงเดิม</p>
        </div>
        <ImageUploader
          value={heroImageUrl ? [heroImageUrl] : []}
          onChange={(urls) => void saveHero(urls)}
          max={1}
        />
        {savingHero && <p className="mt-2 text-xs text-lilac-200">กำลังบันทึก...</p>}
      </section>
      {renderGroup('PRODUCT')}
      {renderGroup('SERVICE')}
    </div>
  );
}
