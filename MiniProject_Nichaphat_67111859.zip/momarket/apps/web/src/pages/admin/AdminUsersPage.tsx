import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import type { AdminUserDTO, Paginated } from '@momarket/shared';
import UserActionModal, { type UserAction } from '../../components/admin/UserActionModal';
import { EmptyState, ErrorBox, Spinner, UserLabel } from '../../components/ui';
import { api, errMsg } from '../../lib/api';
import { formatDateTime, timeAgo } from '../../lib/format';

type Filter = 'ALL' | 'ACTIVE' | 'BANNED' | 'ADMIN';
const FILTERS: { key: Filter; label: string }[] = [
  { key: 'ALL', label: '👥 ทั้งหมด' },
  { key: 'ACTIVE', label: '🟢 ปกติ' },
  { key: 'BANNED', label: '⛔ ถูกแบน' },
  { key: 'ADMIN', label: '🛡️ แอดมิน' },
];

function StatusBadge({ u }: { u: AdminUserDTO }) {
  if (u.role === 'ADMIN') return <span className="chip bg-amber-400/25 text-amber-100">🛡️ แอดมิน</span>;
  if (u.accountStatus === 'PERMANENT_BANNED') return <span className="chip bg-rose-600 text-white">⛔ แบนถาวร</span>;
  if (u.accountStatus === 'TEMP_BANNED')
    return <span className="chip bg-orange-500 text-white">⏳ แบนชั่วคราว</span>;
  return <span className="chip bg-emerald-400/20 text-emerald-200">🟢 ปกติ</span>;
}

export default function AdminUsersPage() {
  const [search, setSearch] = useState('');
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<Filter>('ALL');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Paginated<AdminUserDTO> | null>(null);
  const [error, setError] = useState('');
  const [action, setAction] = useState<{ kind: UserAction; user: AdminUserDTO } | null>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      setQ(search.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(() => {
    setError('');
    api
      .get<Paginated<AdminUserDTO>>('/admin/users', { params: { ...(q ? { q } : {}), status: filter, page, limit: 20 } })
      .then((r) => setData(r.data))
      .catch((e) => setError(errMsg(e)));
  }, [q, filter, page]);

  useEffect(() => {
    setData(null);
    load();
  }, [load]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">👥 ผู้ใช้งานทั้งหมด</h1>
        <p className="text-sm text-lilac-200">
          {data ? `พบ ${data.total.toLocaleString('th-TH')} บัญชี` : 'กำลังโหลด…'} · ค้นหาด้วยชื่อ อีเมล หรือรหัสนักศึกษา
        </p>
      </div>

      <div className="card space-y-3 p-4">
        <div className="relative">
          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" aria-hidden>
            🔍
          </span>
          <input
            type="search"
            className="input pl-10"
            placeholder="ค้นหาชื่อ / อีเมล / รหัสนักศึกษา…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="ค้นหาผู้ใช้"
          />
        </div>
        <div className="flex flex-wrap gap-1.5" role="tablist">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              type="button"
              role="tab"
              aria-selected={filter === f.key}
              onClick={() => {
                setFilter(f.key);
                setPage(1);
              }}
              className={`chip cursor-pointer px-3.5 py-1.5 text-[13px] transition ${
                filter === f.key ? 'bg-lilac-600 text-white shadow-[0_0_14px_rgb(106_47_200/0.9)]' : 'bg-lilac-400/15 text-lilac-50 hover:bg-lilac-400/25'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {error && <ErrorBox message={error} onRetry={load} />}

      {!data ? (
        <Spinner />
      ) : data.items.length === 0 ? (
        <EmptyState emoji="🕵️" title="ไม่พบผู้ใช้ที่ตรงกับเงื่อนไข" hint="ลองเปลี่ยนคำค้นหาหรือตัวกรอง" />
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="border-b border-lilac-400/30 bg-lilac-400/10 text-xs uppercase tracking-wide text-lilac-100">
              <tr>
                <th className="px-4 py-3">ผู้ใช้</th>
                <th className="px-4 py-3">สถานะ</th>
                <th className="px-4 py-3 text-center">ประกาศ</th>
                <th className="px-4 py-3 text-center">เตือน</th>
                <th className="px-4 py-3 text-center">ถูกรายงาน</th>
                <th className="px-4 py-3">สมัคร / ล็อกอินล่าสุด</th>
                <th className="px-4 py-3">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-lilac-400/15 align-top">
              {data.items.map((u) => {
                const isAdmin = u.role === 'ADMIN';
                const banned = u.accountStatus !== 'ACTIVE';
                return (
                  <tr key={u.id} className="transition hover:bg-lilac-400/5">
                    <td className="px-4 py-3">
                      <Link to={`/sellers/${u.id}`} className="hover:text-white hover:underline">
                        <UserLabel name={u.name} studentId={u.studentId} className="text-lilac-50" />
                      </Link>
                      <p className="mt-0.5 break-all text-xs text-lilac-200">{u.email}</p>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge u={u} />
                    </td>
                    <td className="px-4 py-3 text-center font-display font-semibold">{u.listingCount}</td>
                    <td className={`px-4 py-3 text-center font-display font-semibold ${u.warningCount > 0 ? 'text-amber-200' : ''}`}>{u.warningCount}</td>
                    <td className={`px-4 py-3 text-center font-display font-semibold ${u.reportCount > 0 ? 'text-rose-300' : ''}`}>{u.reportCount}</td>
                    <td className="px-4 py-3 text-xs text-lilac-200">
                      <p>📅 {new Date(u.createdAt).toLocaleDateString('th-TH', { dateStyle: 'medium' })}</p>
                      <p>🕒 {timeAgo(u.lastLoginAt)}</p>
                    </td>
                    <td className="px-4 py-3">
                      {isAdmin ? (
                        <span className="text-xs text-lilac-200/70">—</span>
                      ) : (
                        <div className="flex max-w-[170px] flex-wrap gap-1.5">
                          <button type="button" className="btn-secondary btn-sm" onClick={() => setAction({ kind: 'warn', user: u })}>
                            ⚠️ ส่งคำเตือน
                          </button>
                          {banned ? (
                            <button type="button" className="btn-secondary btn-sm" onClick={() => setAction({ kind: 'unban', user: u })}>
                              ↩️ ปลดแบน
                            </button>
                          ) : (
                            <>
                              <button type="button" className="btn-secondary btn-sm" onClick={() => setAction({ kind: 'ban-temp', user: u })}>
                                ⏳ แบน 7 วัน
                              </button>
                              <button type="button" className="btn-secondary btn-sm text-rose-300" onClick={() => setAction({ kind: 'ban-permanent', user: u })}>
                                ⛔ แบนถาวร
                              </button>
                            </>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {data && totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 text-sm">
          <button type="button" className="btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            ← ก่อนหน้า
          </button>
          <span className="text-lilac-200">
            หน้า {page} / {totalPages}
          </span>
          <button type="button" className="btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
            ถัดไป →
          </button>
        </div>
      )}

      {action && (
        <UserActionModal
          action={action.kind}
          user={action.user}
          onClose={() => setAction(null)}
          onDone={() => {
            setAction(null);
            load();
          }}
        />
      )}
    </div>
  );
}
