import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { ALLOWED_EMAIL_DOMAIN, COMMUNITY_RULES, type AuthConfig, type AuthMeResponse } from '@momarket/shared';
import { Logo } from '../components/Layout';
import { Spinner } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { api, parseApiError } from '../lib/api';
import { loadGoogleScript, microsoftLoginPopup } from '../lib/loaders';

export default function LoginPage() {
  const navigate = useNavigate();
  const { applyMe, notice, setNotice } = useAuth();
  const [config, setConfig] = useState<AuthConfig | null>(null);
  const [accepted, setAccepted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [devEmail, setDevEmail] = useState('');
  const googleRef = useRef<HTMLDivElement>(null);
  const acceptedRef = useRef(false);
  acceptedRef.current = accepted;

  useEffect(() => {
    api
      .get<AuthConfig>('/auth/config')
      .then((r) => setConfig(r.data))
      .catch((e) => setError(parseApiError(e).message));
  }, []);

  const finish = useCallback(
    (me: AuthMeResponse) => {
      applyMe(me);
      navigate('/', { replace: true });
    },
    [applyMe, navigate],
  );

  const run = useCallback(
    async (fn: () => Promise<AuthMeResponse>) => {
      setBusy(true);
      setError(null);
      setNotice(null);
      try {
        finish(await fn());
      } catch (e) {
        setError(parseApiError(e).message);
      } finally {
        setBusy(false);
      }
    },
    [finish, setNotice],
  );

  // Google Identity Services
  useEffect(() => {
    if (!config?.google) return;
    const clientId = config.google.clientId;
    let cancelled = false;
    loadGoogleScript()
      .then(() => {
        if (cancelled || !googleRef.current || !window.google) return;
        window.google.accounts.id.initialize({
          client_id: clientId,
          callback: (r) => {
            if (!acceptedRef.current) return;
            void run(async () => (await api.post<AuthMeResponse>('/auth/google', { credential: r.credential })).data);
          },
        });
        window.google.accounts.id.renderButton(googleRef.current, {
          theme: 'outline',
          size: 'large',
          shape: 'pill',
          text: 'signin_with',
          locale: 'th',
          width: 300,
        });
      })
      .catch((e: Error) => setError(e.message));
    return () => {
      cancelled = true;
    };
  }, [config, run]);

  const loginMicrosoft = () => {
    if (!config?.microsoft) return;
    const { clientId, tenantId } = config.microsoft;
    void run(async () => {
      const idToken = await microsoftLoginPopup(clientId, tenantId);
      return (await api.post<AuthMeResponse>('/auth/microsoft', { idToken })).data;
    });
  };

  const loginDev = (e: FormEvent) => {
    e.preventDefault();
    void run(async () => (await api.post<AuthMeResponse>('/auth/dev-login', { email: devEmail })).data);
  };

  const shownError = notice ?? error;
  const noProvider = config && !config.google && !config.microsoft && !config.devLogin;

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gradient-to-br from-ink-950 via-ink-900 to-lilac-700 px-4 py-10">
      <div className="pointer-events-none absolute -left-24 -top-24 h-80 w-80 rounded-full bg-lilac-500/30 blur-3xl" />
      {['🛍️', '🎓', '📸', '🍜', '💜', '✨'].map((e, i) => (
        <span
          key={e}
          aria-hidden
          className="pointer-events-none absolute animate-float select-none text-3xl opacity-60 drop-shadow-[0_0_12px_rgb(157,113,232)]"
          style={{ left: `${8 + i * 17}%`, top: `${i % 2 ? 12 : 82}%`, animationDelay: `${i * 0.7}s` }}
        >
          {e}
        </span>
      ))}
      <div className="pointer-events-none absolute -bottom-32 -right-20 h-96 w-96 rounded-full bg-lilac-400/20 blur-3xl" />

      <div className="relative w-full max-w-md">
        <div className="mb-5 flex justify-center">
          <Logo light />
        </div>

        <div className="rounded-3xl border border-lilac-300/60 bg-ink-900/95 p-6 shadow-[0_0_40px_rgb(157_113_232/0.45)] backdrop-blur sm:p-8">
          <h1 className="text-center text-2xl font-bold text-lilac-50">👋 เข้าสู่ระบบ</h1>
          <p className="mt-1 text-center text-sm text-lilac-200">
            🛍️ ตลาดซื้อขายสินค้าและบริการสำหรับชาว DPU
            <br />
            🎓 ใช้ได้เฉพาะอีเมล <b className="text-lilac-200">@{ALLOWED_EMAIL_DOMAIN}</b> เท่านั้น
          </p>

          <section className="mt-5 rounded-2xl border border-lilac-400/40 bg-lilac-400/10 p-4" aria-labelledby="rules-title">
            <h2 id="rules-title" className="mb-2 text-sm font-semibold text-lilac-50">
              📜 กฎกติกาการใช้งาน
            </h2>
            <ol className="list-decimal space-y-1.5 pl-5 text-[13px] leading-relaxed text-lilac-50">
              {COMMUNITY_RULES.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ol>
            <p className="mt-2 text-[11px] text-lilac-200">
              🔒 ระบบเก็บชื่อและอีเมล @{ALLOWED_EMAIL_DOMAIN} ของคุณเพื่อยืนยันตัวตน และแสดงชื่อผู้ขายในประกาศ
              รวมถึงช่องทางติดต่อที่คุณกรอกเอง
            </p>
          </section>

          <label className="mt-4 flex cursor-pointer items-start gap-2.5 text-sm text-lilac-50">
            <input
              type="checkbox"
              checked={accepted}
              onChange={(e) => setAccepted(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-lilac-500"
            />
            <span>ฉันได้อ่านและยอมรับกฎกติกาการใช้งานข้างต้น</span>
          </label>

          {shownError && (
            <div className="mt-4 rounded-xl border border-rose-400/50 bg-rose-500/15 px-3.5 py-2.5 text-sm text-rose-200" role="alert">
              {shownError}
            </div>
          )}

          <div className={`mt-4 flex flex-col items-center gap-3 transition ${accepted ? '' : 'pointer-events-none opacity-50'}`}>
            {!config && !error && <Spinner />}

            {config?.google && <div ref={googleRef} className="min-h-[44px]" />}

            {config?.microsoft && (
              <button
                type="button"
                onClick={loginMicrosoft}
                disabled={busy || !accepted}
                className="btn w-[300px] max-w-full rounded-full border border-lilac-400/30 bg-ink-900 py-2.5 text-lilac-50 shadow-[0_0_12px_rgb(157_113_232/0.35)] hover:bg-lilac-400/15"
              >
                <span className="grid h-4 w-4 grid-cols-2 gap-px" aria-hidden>
                  <i className="bg-[#f25022]" />
                  <i className="bg-[#7fba00]" />
                  <i className="bg-[#00a4ef]" />
                  <i className="bg-[#ffb900]" />
                </span>
                เข้าสู่ระบบด้วย Microsoft @{ALLOWED_EMAIL_DOMAIN}
              </button>
            )}

            {config?.devLogin && (
              <form onSubmit={loginDev} className="w-full rounded-2xl border border-dashed border-amber-400 bg-amber-400/15 p-3">
                <p className="mb-2 text-xs font-semibold text-amber-100">🧪 โหมดทดสอบ (DEV_LOGIN) — ล็อกอินจำลอง</p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    required
                    className="input"
                    placeholder={`ชื่อ@${ALLOWED_EMAIL_DOMAIN}`}
                    value={devEmail}
                    onChange={(e) => setDevEmail(e.target.value)}
                    disabled={!accepted}
                  />
                  <button type="submit" className="btn-primary shrink-0" disabled={busy || !accepted}>
                    เข้าสู่ระบบ
                  </button>
                </div>
              </form>
            )}

            {noProvider && (
              <p className="text-center text-sm text-lilac-200">🚧 ระบบเข้าสู่ระบบยังไม่ได้ตั้งค่า กรุณาติดต่อผู้ดูแลระบบ</p>
            )}
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-lilac-200">
          💜 momarket เป็นเพียงพื้นที่ลงประกาศ ไม่มีการชำระเงินหรือแชทในเว็บไซต์
        </p>
      </div>
    </div>
  );
}
