import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import { Spinner } from './components/ui';
import { useAuth } from './context/AuthContext';
import AdminLayout from './pages/admin/AdminLayout';
import AdminOverviewPage from './pages/admin/AdminOverviewPage';
import AdminReportsPage from './pages/admin/AdminReportsPage';
import AdminUsersPage from './pages/admin/AdminUsersPage';
import AdminCategoryImagesPage from './pages/admin/AdminCategoryImagesPage';
import FeedPage from './pages/FeedPage';
import HomePage from './pages/HomePage';
import ListingDetailPage from './pages/ListingDetailPage';
import ListingFormPage from './pages/ListingFormPage';
import LoginPage from './pages/LoginPage';
import ProfilePage from './pages/ProfilePage';
import SellerPage from './pages/SellerPage';

function RequireAuth({ children }: { children: JSX.Element }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner full />;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

/** เฉพาะแอดมิน (role=ADMIN) */
function RequireAdmin({ children }: { children: JSX.Element }) {
  const { user } = useAuth();
  return user?.role === 'ADMIN' ? children : <Navigate to="/" replace />;
}

/** ผู้ดูแลระบบลงประกาศไม่ได้ — เด้งกลับหน้าแรก */
function BlockAdmin({ children }: { children: JSX.Element }) {
  const { user } = useAuth();
  return user?.role === 'ADMIN' ? <Navigate to="/" replace /> : children;
}

export default function App() {
  const { user, loading } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={loading ? <Spinner full /> : user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route
        element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }
      >
        <Route index element={<HomePage />} />
        <Route path="market" element={<FeedPage />} />
        <Route
          path="listings/new"
          element={
            <BlockAdmin>
              <ListingFormPage />
            </BlockAdmin>
          }
        />
        <Route path="listings/:id" element={<ListingDetailPage />} />
        <Route
          path="listings/:id/edit"
          element={
            <BlockAdmin>
              <ListingFormPage />
            </BlockAdmin>
          }
        />
        <Route path="sellers/:id" element={<SellerPage />} />
        <Route path="me" element={<ProfilePage />} />
        <Route
          path="admin"
          element={
            <RequireAdmin>
              <AdminLayout />
            </RequireAdmin>
          }
        >
          <Route index element={<AdminOverviewPage />} />
          <Route path="reports" element={<AdminReportsPage />} />
          <Route path="users" element={<AdminUsersPage />} />
          <Route path="category-images" element={<AdminCategoryImagesPage />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
