import { Router } from 'express';
import type { SellerProfileDTO } from '@momarket/shared';
import { prisma } from '../db';
import { notFound } from '../errors';
import { accountStatus } from '../lib/accountStatus';
import { toCard, toPublicUser } from '../lib/serializers';
import { currentUser, requireAuth } from '../middleware/auth';

export const usersRouter = Router();
usersRouter.use(requireAuth);

/** GET /api/users/:id — หน้าโปรไฟล์ผู้ขาย (ประกาศทั้งหมดของเขา) */
usersRouter.get('/:id', async (req, res) => {
  const me = currentUser(req);
  const seller = await prisma.user.findUnique({ where: { id: String(req.params.id) } });
  if (!seller) throw notFound('ไม่พบผู้ใช้นี้');

  // ผู้ถูกแบน / แอดมิน: ผู้ใช้ทั่วไปมองไม่เห็น
  const hidden = accountStatus(seller) !== 'ACTIVE' || seller.role === 'ADMIN';
  if (hidden && me.role !== 'ADMIN') throw notFound('ไม่พบผู้ใช้นี้');

  const rows = await prisma.listing.findMany({
    where: { userId: seller.id, deletedAt: null },
    orderBy: [{ bumpedAt: 'desc' }, { id: 'desc' }],
    take: 60,
  });

  const body: SellerProfileDTO = {
    user: toPublicUser(seller),
    joinedAt: seller.createdAt.toISOString(),
    activeCount: rows.filter((l) => l.status === 'ACTIVE').length,
    soldCount: rows.filter((l) => l.status === 'SOLD').length,
    items: rows.map(toCard),
  };
  res.json(body);
});
