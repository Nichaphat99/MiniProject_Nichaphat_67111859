import { Router } from 'express';
import multer from 'multer';
import { ALLOWED_IMAGE_MIME, MAX_IMAGES, MAX_IMAGE_BYTES } from '@momarket/shared';
import { HttpError } from '../errors';
import { saveImage } from '../lib/images';
import { requireAuth } from '../middleware/auth';
import { uploadLimiter } from '../middleware/security';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IMAGE_BYTES, files: MAX_IMAGES },
  fileFilter: (_req, file, cb) => {
    if ((ALLOWED_IMAGE_MIME as readonly string[]).includes(file.mimetype)) cb(null, true);
    else cb(new HttpError(400, 'รองรับเฉพาะไฟล์ JPG, PNG, WebP', 'UPLOAD'));
  },
});

export const uploadsRouter = Router();

/** POST /api/uploads  (multipart/form-data, field: "files") → { urls: string[] } */
uploadsRouter.post('/', requireAuth, uploadLimiter, upload.array('files', MAX_IMAGES), async (req, res) => {
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  if (files.length === 0) throw new HttpError(400, 'ไม่พบไฟล์รูปภาพ', 'UPLOAD');
  const urls: string[] = [];
  for (const f of files) urls.push(await saveImage(f.buffer));
  res.status(201).json({ urls });
});
