import { Router } from 'express';
import type { WarningDTO } from '@momarket/shared';
import { prisma } from '../db';
import { currentUser, requireAuth } from '../middleware/auth';

export const warningsRouter = Router();
warningsRouter.use(requireAuth);

/** ประวัติคำเตือนของฉัน (แสดงในหน้าโปรไฟล์) */
warningsRouter.get('/', async (req, res) => {
  const me = currentUser(req);
  const rows = await prisma.warning.findMany({
    where: { userId: me.id },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  const items: WarningDTO[] = rows.map((w) => ({
    id: w.id,
    message: w.message,
    createdAt: w.createdAt.toISOString(),
    acknowledgedAt: w.acknowledgedAt?.toISOString() ?? null,
  }));
  res.json({ items });
});

/** กดรับทราบคำเตือนทั้งหมดที่ค้างอยู่ (ปิด Blocking Modal) */
warningsRouter.post('/acknowledge', async (req, res) => {
  const me = currentUser(req);
  const r = await prisma.warning.updateMany({
    where: { userId: me.id, acknowledgedAt: null },
    data: { acknowledgedAt: new Date() },
  });
  res.json({ acknowledged: r.count });
});
