import { Router } from 'express';
import { Prisma } from '@prisma/client';
import {
  BUMP_COOLDOWN_HOURS,
  PRODUCT_SUBCATEGORIES,
  SERVICE_SUBCATEGORIES,
  listingInputSchema,
  listingQuerySchema,
  reportInputSchema,
  statusChangeSchema,
  typeOfSubcategory,
  type ListingCardDTO,
  type MyListingDTO,
  type Paginated,
} from '@momarket/shared';
import { prisma } from '../db';
import { HttpError, badRequest, notFound } from '../errors';
import { activeOwnerWhere } from '../lib/accountStatus';
import { listingDataFromInput, nextBumpAt, snapshotOf, toCard, toDetail, toMyListing } from '../lib/serializers';
import { currentUser, forbidAdmin, requireAuth } from '../middleware/auth';
import { createListingLimiter, reportLimiter } from '../middleware/security';

export const listingsRouter = Router();
listingsRouter.use(requireAuth);

const idOf = (v: unknown) => String(v);

/* ---------- Feed ---------- */

listingsRouter.get('/', async (req, res) => {
  const q = listingQuerySchema.parse(req.query);
  if (q.subcategory) {
    const pool: readonly string[] = q.type === 'PRODUCT' ? PRODUCT_SUBCATEGORIES : SERVICE_SUBCATEGORIES;
    if (!pool.includes(q.subcategory)) throw badRequest('หมวดหมู่ย่อยไม่ตรงกับประเภทที่เลือก');
  }

  const where: Prisma.ListingWhereInput = {
    deletedAt: null,
    type: q.type,
    user: activeOwnerWhere(),
    ...(q.subcategory ? { subcategory: q.subcategory } : {}),
    ...(q.hideSold ? { status: 'ACTIVE' } : {}),
    ...(q.meetup ? { meetupLocation: q.meetup } : {}),
    ...(q.q ? { title: { contains: q.q, mode: 'insensitive' } } : {}),
  };

  const orderBy: Prisma.ListingOrderByWithRelationInput[] =
    q.sort === 'price_asc'
      ? [{ price: 'asc' }, { bumpedAt: 'desc' }, { id: 'desc' }]
      : q.sort === 'price_desc'
        ? [{ price: 'desc' }, { bumpedAt: 'desc' }, { id: 'desc' }]
        : [{ bumpedAt: 'desc' }, { id: 'desc' }];

  const [total, rows] = await prisma.$transaction([
    prisma.listing.count({ where }),
    prisma.listing.findMany({ where, orderBy, skip: (q.page - 1) * q.limit, take: q.limit }),
  ]);

  const body: Paginated<ListingCardDTO> = {
    items: rows.map(toCard),
    total,
    page: q.page,
    pageSize: q.limit,
  };
  res.json(body);
});

/* ---------- ประกาศของฉัน (ต้องอยู่ก่อน /:id) ---------- */

listingsRouter.get('/mine', async (req, res) => {
  const me = currentUser(req);
  const rows = await prisma.listing.findMany({
    where: { userId: me.id, deletedAt: null },
    orderBy: [{ bumpedAt: 'desc' }, { id: 'desc' }],
  });
  const items: MyListingDTO[] = rows.map(toMyListing);
  res.json({ items });
});

/* ---------- สร้าง ---------- */

listingsRouter.post('/', forbidAdmin, createListingLimiter, async (req, res) => {
  const me = currentUser(req);
  const input = listingInputSchema.parse(req.body);
  const listing = await prisma.listing.create({
    data: { ...listingDataFromInput(input), userId: me.id },
  });
  res.status(201).json({ id: listing.id });
});

/* ---------- รายละเอียด ---------- */

listingsRouter.get('/:id', async (req, res) => {
  const me = currentUser(req);
  const l = await prisma.listing.findUnique({ where: { id: idOf(req.params.id) }, include: { user: true } });
  if (!l) throw notFound('ไม่พบประกาศนี้');

  const isAdmin = me.role === 'ADMIN';
  const ownerBanned =
    l.user.isPermanentlyBanned || (l.user.bannedUntil !== null && l.user.bannedUntil > new Date());
  // ประกาศที่ถูกลบ / เจ้าของถูกแบน: เห็นได้เฉพาะแอดมิน (เพื่อตรวจสอบรายงาน)
  if ((l.deletedAt || ownerBanned) && !isAdmin) throw notFound('ไม่พบประกาศนี้ หรือประกาศถูกลบแล้ว');

  res.json(toDetail(l, me.id));
});

/* ---------- แก้ไข / ลบ / สถานะ / ดัน ---------- */

async function findOwned(id: string, userId: string) {
  const l = await prisma.listing.findFirst({ where: { id, userId, deletedAt: null } });
  if (!l) throw notFound('ไม่พบประกาศนี้');
  return l;
}

listingsRouter.put('/:id', forbidAdmin, createListingLimiter, async (req, res) => {
  const me = currentUser(req);
  const existing = await findOwned(idOf(req.params.id), me.id);
  const input = listingInputSchema.parse(req.body);
  if (input.subcategory !== existing.subcategory) {
    // เปลี่ยนหมวดย่อยไม่ได้ ให้ลบแล้วสร้างใหม่ (กันฟิลด์เฉพาะหมวดปนกัน)
    throw badRequest('ไม่สามารถเปลี่ยนหมวดหมู่ของประกาศได้');
  }
  const data = listingDataFromInput(input);
  if (typeOfSubcategory(input.subcategory) !== existing.type) throw badRequest('ประเภทประกาศไม่ถูกต้อง');
  await prisma.listing.update({ where: { id: existing.id }, data });
  res.json({ id: existing.id });
});

listingsRouter.patch('/:id/status', async (req, res) => {
  const me = currentUser(req);
  const { status } = statusChangeSchema.parse(req.body);
  const existing = await findOwned(idOf(req.params.id), me.id);
  const updated = await prisma.listing.update({ where: { id: existing.id }, data: { status } });
  res.json(toMyListing(updated));
});

listingsRouter.post('/:id/bump', async (req, res) => {
  const me = currentUser(req);
  const id = idOf(req.params.id);
  const now = new Date();
  const threshold = new Date(now.getTime() - BUMP_COOLDOWN_HOURS * 3600 * 1000);

  // อัปเดตแบบ atomic: สำเร็จเฉพาะเมื่อพ้นช่วงรอ 24 ชม. (กันกดซ้อนหลายคำขอพร้อมกัน)
  const r = await prisma.listing.updateMany({
    where: { id, userId: me.id, deletedAt: null, status: 'ACTIVE', bumpedAt: { lte: threshold } },
    data: { bumpedAt: now },
  });

  if (r.count === 0) {
    const l = await findOwned(id, me.id);
    if (l.status === 'SOLD') throw badRequest('ประกาศที่ขายแล้วไม่สามารถดันได้');
    const next = nextBumpAt(l, now);
    throw new HttpError(
      429,
      `ดันประกาศได้วันละ 1 ครั้ง (ดันได้อีกครั้งหลัง ${next?.toLocaleString('th-TH', {
        timeZone: 'Asia/Bangkok',
        dateStyle: 'medium',
        timeStyle: 'short',
      })} น.)`,
      'BUMP_COOLDOWN',
      { nextBumpAt: next?.toISOString() ?? null },
    );
  }
  const updated = await prisma.listing.findUniqueOrThrow({ where: { id } });
  res.json(toMyListing(updated));
});

listingsRouter.delete('/:id', async (req, res) => {
  const me = currentUser(req);
  const existing = await findOwned(idOf(req.params.id), me.id);
  await prisma.listing.update({ where: { id: existing.id }, data: { deletedAt: new Date() } });
  res.json({ ok: true });
});

/* ---------- รายงานประกาศ ---------- */

listingsRouter.post('/:id/reports', reportLimiter, async (req, res) => {
  const me = currentUser(req);
  const input = reportInputSchema.parse(req.body);
  const l = await prisma.listing.findFirst({
    where: { id: idOf(req.params.id), deletedAt: null, user: activeOwnerWhere() },
  });
  if (!l) throw notFound('ไม่พบประกาศนี้');
  if (l.userId === me.id) throw badRequest('ไม่สามารถรายงานประกาศของตนเองได้');

  try {
    await prisma.report.create({
      data: {
        listingId: l.id,
        reporterId: me.id,
        reportedUserId: l.userId,
        reason: input.reason,
        detail: input.detail ?? null,
        snapshot: snapshotOf(l) as unknown as Prisma.InputJsonValue,
      },
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
      throw new HttpError(409, 'คุณได้รายงานประกาศนี้ไปแล้ว ผู้ดูแลระบบกำลังตรวจสอบ', 'ALREADY_REPORTED');
    }
    throw e;
  }
  res.status(201).json({ ok: true });
});
