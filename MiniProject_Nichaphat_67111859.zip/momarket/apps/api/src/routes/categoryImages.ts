import { Router } from 'express';
import { ALL_SUBCATEGORIES, type Subcategory } from '@momarket/shared';
import { z } from 'zod';
import { prisma } from '../db';
import { badRequest } from '../errors';

export const categoryImagesRouter = Router();

categoryImagesRouter.get('/hero-banner', async (_req, res) => {
  const row = await prisma.heroBannerImage.findUnique({ where: { id: 'hero' } });
  res.json({ imageUrl: row?.imageUrl ?? null });
});

categoryImagesRouter.get('/', async (_req, res) => {
  const rows = await prisma.categoryImage.findMany();
  res.json(Object.fromEntries(rows.map((row) => [row.subcategory, row.imageUrl])));
});

export const categoryImagesAdminRouter = Router();

const updateCategoryImageSchema = z.object({
  subcategory: z.enum(ALL_SUBCATEGORIES),
  imageUrl: z.string().nullable(),
});

categoryImagesAdminRouter.get('/', async (_req, res) => {
  const rows = await prisma.categoryImage.findMany();
  const images = Object.fromEntries(rows.map((row) => [row.subcategory, row.imageUrl])) as Partial<Record<Subcategory, string>>;
  res.json(ALL_SUBCATEGORIES.map((subcategory) => ({ subcategory, imageUrl: images[subcategory] ?? null })));
});

categoryImagesAdminRouter.put('/', async (req, res) => {
  const parsed = updateCategoryImageSchema.safeParse(req.body);
  if (!parsed.success) throw badRequest('ข้อมูลรูปหมวดหมู่ไม่ถูกต้อง');
  const { subcategory, imageUrl } = parsed.data;
  if (imageUrl) {
    await prisma.categoryImage.upsert({
      where: { subcategory },
      create: { subcategory, imageUrl },
      update: { imageUrl },
    });
  } else {
    await prisma.categoryImage.deleteMany({ where: { subcategory } });
  }
  res.json({ subcategory, imageUrl });
});

categoryImagesAdminRouter.get('/hero-banner', async (_req, res) => {
  const row = await prisma.heroBannerImage.findUnique({ where: { id: 'hero' } });
  res.json({ imageUrl: row?.imageUrl ?? null });
});

categoryImagesAdminRouter.put('/hero-banner', async (req, res) => {
  const parsed = z.object({ imageUrl: z.string().nullable() }).safeParse(req.body);
  if (!parsed.success) throw badRequest('ข้อมูลรูปแบนเนอร์ไม่ถูกต้อง');
  const { imageUrl } = parsed.data;
  if (imageUrl) {
    await prisma.heroBannerImage.upsert({
      where: { id: 'hero' },
      create: { id: 'hero', imageUrl },
      update: { imageUrl },
    });
  } else {
    await prisma.heroBannerImage.deleteMany({ where: { id: 'hero' } });
  }
  res.json({ imageUrl });
});
