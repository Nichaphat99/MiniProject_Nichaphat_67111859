import { Router } from 'express';
import type { User } from '@prisma/client';
import {
  DISPLAY_NAME_COOLDOWN_DAYS,
  DISPLAY_NAME_GRACE_MINUTES,
  RESERVED_NAME_PATTERN,
  WARNING_BANNER_DAYS,
  devLoginSchema,
  displayNameSchema,
  googleLoginSchema,
  microsoftLoginSchema,
  type AuthConfig,
  type AuthMeResponse,
} from '@momarket/shared';
import { config } from '../config';
import { prisma } from '../db';
import { HttpError } from '../errors';
import { accountStatus, banMessage } from '../lib/accountStatus';
import { verifyGoogle, verifyMicrosoft, type VerifiedIdentity } from '../lib/providers';
import { clearSession, issueSession } from '../lib/session';
import { currentUser, requireAuth } from '../middleware/auth';
import { authLimiter } from '../middleware/security';
import { toPublicUser } from '../lib/serializers';
import type { Response } from 'express';

export const authRouter = Router();

/** วันที่แก้ชื่อได้ครั้งถัดไป (null = แก้ได้เลย) */
function nextNameChangeAt(user: User, now = new Date()): Date | null {
  if (!user.displayName || !user.displayNameChangedAt) return null;
  const sinceMs = now.getTime() - user.displayNameChangedAt.getTime();
  if (sinceMs < DISPLAY_NAME_GRACE_MINUTES * 60 * 1000) return null; // ช่วงแก้คำผิดหลังตั้งชื่อใหม่
  const next = new Date(user.displayNameChangedAt.getTime() + DISPLAY_NAME_COOLDOWN_DAYS * 24 * 3600 * 1000);
  return next > now ? next : null;
}

export async function buildMe(user: User): Promise<AuthMeResponse> {
  const since = new Date(Date.now() - WARNING_BANNER_DAYS * 24 * 3600 * 1000);
  const [pending, recentWarningCount] = await Promise.all([
    prisma.warning.findMany({
      where: { userId: user.id, acknowledgedAt: null },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.warning.count({ where: { userId: user.id, createdAt: { gte: since } } }),
  ]);
  return {
    user: {
      ...toPublicUser(user),
      email: user.email,
      role: user.role,
      needsProfile: user.displayName === null,
      nextNameChangeAt: nextNameChangeAt(user)?.toISOString() ?? null,
    },
    pendingWarnings: pending.map((w) => ({
      id: w.id,
      message: w.message,
      createdAt: w.createdAt.toISOString(),
      acknowledgedAt: null,
    })),
    recentWarningCount,
  };
}

async function loginWithIdentity(identity: VerifiedIdentity, res: Response) {
  const isAdminEmail = config.adminEmails.has(identity.email);
  const existing = await prisma.user.findUnique({ where: { email: identity.email } });

  // บัญชีที่ถูกแบนไม่สามารถล็อกอินได้ (ครอบคลุมแบนถาวรที่บล็อกอีเมลไว้ด้วย)
  if (existing && accountStatus(existing) !== 'ACTIVE') {
    const info = banMessage(existing);
    throw new HttpError(403, info.message, 'BANNED', { permanent: info.permanent, bannedUntil: info.bannedUntil });
  }

  const user = await prisma.user.upsert({
    where: { email: identity.email },
    create: {
      email: identity.email,
      name: identity.name,
      avatarUrl: identity.avatarUrl,
      role: isAdminEmail ? 'ADMIN' : 'USER',
    },
    update: {
      name: identity.name,
      ...(identity.avatarUrl ? { avatarUrl: identity.avatarUrl } : {}),
      lastLoginAt: new Date(),
      ...(isAdminEmail ? { role: 'ADMIN' as const } : {}),
    },
  });

  await issueSession(res, user.id);
  res.json(await buildMe(user));
}

/** GET /api/auth/config — ให้ frontend รู้ว่าเปิดปุ่มล็อกอินแบบไหนบ้าง */
authRouter.get('/config', (_req, res) => {
  const body: AuthConfig = {
    google: config.google,
    microsoft: config.microsoft,
    devLogin: config.devLogin,
  };
  res.json(body);
});

authRouter.post('/google', authLimiter, async (req, res) => {
  const { credential } = googleLoginSchema.parse(req.body);
  await loginWithIdentity(await verifyGoogle(credential), res);
});

authRouter.post('/microsoft', authLimiter, async (req, res) => {
  const { idToken } = microsoftLoginSchema.parse(req.body);
  await loginWithIdentity(await verifyMicrosoft(idToken), res);
});

/** ล็อกอินจำลองสำหรับพัฒนา — เปิดได้เฉพาะ NODE_ENV != production และ DEV_LOGIN=true */
authRouter.post('/dev-login', authLimiter, async (req, res) => {
  if (!config.devLogin) throw new HttpError(404, 'ไม่พบเส้นทางนี้');
  const { email, name } = devLoginSchema.parse(req.body);
  await loginWithIdentity({ email, name: name ?? email.split('@')[0]!, avatarUrl: null }, res);
});

authRouter.post('/logout', (_req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

authRouter.get('/me', requireAuth, async (req, res) => {
  res.json(await buildMe(currentUser(req)));
});

/** ตั้ง/แก้ชื่อที่แสดง — ครั้งแรกหลังล็อกอินบังคับตั้ง, หลังจากนั้นแก้ได้ทุก DISPLAY_NAME_COOLDOWN_DAYS วัน */
authRouter.patch('/profile', requireAuth, async (req, res) => {
  const me = currentUser(req);
  const { displayName } = displayNameSchema.parse(req.body);

  if (me.role !== 'ADMIN' && RESERVED_NAME_PATTERN.test(displayName)) {
    throw new HttpError(400, 'ชื่อนี้ใช้ไม่ได้ (ห้ามใช้คำที่แอบอ้างเป็นผู้ดูแลระบบหรือ momarket)', 'RESERVED_NAME');
  }

  const now = new Date();
  const next = nextNameChangeAt(me, now);
  if (next) {
    throw new HttpError(
      429,
      `แก้ชื่อได้ทุก ${DISPLAY_NAME_COOLDOWN_DAYS} วัน (แก้ได้อีกครั้งหลัง ${next.toLocaleDateString('th-TH', {
        timeZone: 'Asia/Bangkok',
        dateStyle: 'long',
      })})`,
      'NAME_COOLDOWN',
      { nextNameChangeAt: next.toISOString() },
    );
  }

  // ถ้าแก้ในช่วงผ่อนผัน (ชั่วโมงแรกหลังตั้ง) ไม่เริ่มนับรอบใหม่
  const inGrace =
    me.displayName !== null &&
    me.displayNameChangedAt !== null &&
    now.getTime() - me.displayNameChangedAt.getTime() < DISPLAY_NAME_GRACE_MINUTES * 60 * 1000;

  const updated = await prisma.user.update({
    where: { id: me.id },
    data: { displayName, ...(inGrace ? {} : { displayNameChangedAt: now }) },
  });
  res.json(await buildMe(updated));
});
