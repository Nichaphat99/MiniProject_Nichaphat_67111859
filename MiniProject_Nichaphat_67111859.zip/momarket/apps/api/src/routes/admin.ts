import { Router } from 'express';
import { Prisma } from '@prisma/client';
import {
  ALL_SUBCATEGORIES,
  REPORT_STATUSES,
  TEMP_BAN_DAYS,
  adminBanSchema,
  adminDeleteListingSchema,
  adminResolveSchema,
  adminUsersQuerySchema,
  adminWarnSchema,
  studentIdFromEmail,
  type AdminOverview,
  type AdminReportDTO,
  type AdminUserDTO,
  type DayCount,
  type Paginated,
  type ReportSnapshot,
} from '@momarket/shared';
import { z } from 'zod';
import { prisma } from '../db';
import { badRequest, forbidden, notFound } from '../errors';
import { accountStatus } from '../lib/accountStatus';
import { effectiveName } from '../lib/serializers';
import { currentUser, requireAdmin, requireAuth } from '../middleware/auth';
import { categoryImagesAdminRouter } from './categoryImages';

export const adminRouter = Router();
adminRouter.use(requireAuth, requireAdmin);
adminRouter.use('/category-images', categoryImagesAdminRouter);

const idOf = (v: unknown) => String(v);

/* ---------- ภาพรวม (KPI + กราฟ) ---------- */

const DAYS = 30;
const DAY_MS = 24 * 3600 * 1000;
const bangkokDay = (d: Date) => new Date(d.getTime() + 7 * 3600 * 1000).toISOString().slice(0, 10);

/** เติมวันที่ไม่มีข้อมูลให้เป็น 0 เพื่อให้กราฟต่อเนื่อง 30 วันล่าสุด (เวลาไทย) */
function fillDays(rows: { day: string; count: number }[]): DayCount[] {
  const map = new Map(rows.map((r) => [r.day, r.count]));
  const out: DayCount[] = [];
  for (let i = DAYS - 1; i >= 0; i--) {
    const day = bangkokDay(new Date(Date.now() - i * DAY_MS));
    out.push({ day, count: map.get(day) ?? 0 });
  }
  return out;
}

adminRouter.get('/overview', async (_req, res) => {
  const now = new Date();
  const since = new Date(now.getTime() - (DAYS + 1) * DAY_MS);
  const weekAgo = new Date(now.getTime() - 7 * DAY_MS);

  const [
    totalUsers,
    newUsers7d,
    activeListings,
    soldListings,
    pendingReports,
    bannedUsers,
    usersRaw,
    listingsRaw,
    byCategory,
    byReason,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { createdAt: { gte: weekAgo } } }),
    prisma.listing.count({ where: { deletedAt: null, status: 'ACTIVE' } }),
    prisma.listing.count({ where: { deletedAt: null, status: 'SOLD' } }),
    prisma.report.count({ where: { status: 'PENDING' } }),
    prisma.user.count({ where: { OR: [{ isPermanentlyBanned: true }, { bannedUntil: { gt: now } }] } }),
    prisma.$queryRaw<{ day: string; count: number }[]>(Prisma.sql`
      SELECT to_char(("createdAt" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Bangkok', 'YYYY-MM-DD') AS day, count(*)::int AS count
      FROM "User" WHERE "createdAt" >= ${since} GROUP BY 1`),
    prisma.$queryRaw<{ day: string; count: number }[]>(Prisma.sql`
      SELECT to_char(("createdAt" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Bangkok', 'YYYY-MM-DD') AS day, count(*)::int AS count
      FROM "Listing" WHERE "createdAt" >= ${since} AND "deletedAt" IS NULL GROUP BY 1`),
    prisma.listing.groupBy({
      by: ['subcategory'],
      where: { deletedAt: null, status: 'ACTIVE' },
      _count: { _all: true },
    }),
    prisma.report.groupBy({ by: ['reason'], _count: { _all: true } }),
  ]);

  const body: AdminOverview = {
    kpis: { totalUsers, newUsers7d, activeListings, soldListings, pendingReports, bannedUsers },
    usersPerDay: fillDays(usersRaw),
    listingsPerDay: fillDays(listingsRaw),
    listingsByCategory: byCategory
      .map((c) => ({ subcategory: c.subcategory, count: c._count._all }))
      .sort((a, b) => b.count - a.count),
    reportsByReason: byReason.map((r) => ({ reason: r.reason, count: r._count._all })).sort((a, b) => b.count - a.count),
  };
  res.json(body);
});

/* ---------- รายชื่อผู้ใช้ ---------- */

adminRouter.get('/users', async (req, res) => {
  const q = adminUsersQuerySchema.parse(req.query);
  const now = new Date();
  const and: Prisma.UserWhereInput[] = [];

  if (q.q) {
    and.push({
      OR: [
        { displayName: { contains: q.q, mode: 'insensitive' } },
        { name: { contains: q.q, mode: 'insensitive' } },
        { email: { contains: q.q, mode: 'insensitive' } },
      ],
    });
  }
  if (q.status === 'ADMIN') and.push({ role: 'ADMIN' });
  if (q.status === 'BANNED') and.push({ OR: [{ isPermanentlyBanned: true }, { bannedUntil: { gt: now } }] });
  if (q.status === 'ACTIVE') {
    and.push({ role: 'USER', isPermanentlyBanned: false, OR: [{ bannedUntil: null }, { bannedUntil: { lte: now } }] });
  }
  const where: Prisma.UserWhereInput = and.length ? { AND: and } : {};

  const [total, rows] = await prisma.$transaction([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (q.page - 1) * q.limit,
      take: q.limit,
      include: {
        _count: {
          select: { listings: { where: { deletedAt: null } }, warningsReceived: true, reportsAgainst: true },
        },
      },
    }),
  ]);

  const items: AdminUserDTO[] = rows.map((u) => ({
    id: u.id,
    name: effectiveName(u),
    studentId: studentIdFromEmail(u.email),
    email: u.email,
    role: u.role,
    accountStatus: accountStatus(u),
    bannedUntil: u.bannedUntil?.toISOString() ?? null,
    listingCount: u._count.listings,
    warningCount: u._count.warningsReceived,
    reportCount: u._count.reportsAgainst,
    createdAt: u.createdAt.toISOString(),
    lastLoginAt: u.lastLoginAt.toISOString(),
  }));
  const body: Paginated<AdminUserDTO> = { items, total, page: q.page, pageSize: q.limit };
  res.json(body);
});

/* ---------- รายงาน ---------- */

const reportsQuery = z.object({
  status: z.enum([...REPORT_STATUSES, 'ALL']).default('PENDING'),
  page: z.coerce.number().int().min(1).max(1000).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

adminRouter.get('/reports', async (req, res) => {
  const q = reportsQuery.parse(req.query);
  const where: Prisma.ReportWhereInput = q.status === 'ALL' ? {} : { status: q.status };

  const [total, rows] = await prisma.$transaction([
    prisma.report.count({ where }),
    prisma.report.findMany({
      where,
      orderBy: { createdAt: q.status === 'PENDING' ? 'asc' : 'desc' },
      skip: (q.page - 1) * q.limit,
      take: q.limit,
      include: { reporter: true, reportedUser: true, listing: true, resolvedBy: true },
    }),
  ]);

  const userIds = [...new Set(rows.map((r) => r.reportedUserId))];
  const [warningCounts, reportCounts] = await Promise.all([
    prisma.warning.groupBy({ by: ['userId'], where: { userId: { in: userIds } }, _count: { _all: true } }),
    prisma.report.groupBy({ by: ['reportedUserId'], where: { reportedUserId: { in: userIds } }, _count: { _all: true } }),
  ]);
  const warnMap = new Map(warningCounts.map((c) => [c.userId, c._count._all]));
  const repMap = new Map(reportCounts.map((c) => [c.reportedUserId, c._count._all]));

  const items: AdminReportDTO[] = rows.map((r) => ({
    id: r.id,
    reason: r.reason,
    detail: r.detail,
    status: r.status,
    createdAt: r.createdAt.toISOString(),
    resolvedAt: r.resolvedAt?.toISOString() ?? null,
    resolutionNote: r.resolutionNote,
    resolvedByName: r.resolvedBy ? effectiveName(r.resolvedBy) : null,
    reporter: {
      id: r.reporter.id,
      name: effectiveName(r.reporter),
      studentId: studentIdFromEmail(r.reporter.email),
      email: r.reporter.email,
    },
    reportedUser: {
      id: r.reportedUser.id,
      name: effectiveName(r.reportedUser),
      studentId: studentIdFromEmail(r.reportedUser.email),
      email: r.reportedUser.email,
      role: r.reportedUser.role,
      accountStatus: accountStatus(r.reportedUser),
      bannedUntil: r.reportedUser.bannedUntil?.toISOString() ?? null,
      warningCount: warnMap.get(r.reportedUserId) ?? 0,
      reportCount: repMap.get(r.reportedUserId) ?? 0,
    },
    listing: { id: r.listing.id, title: r.listing.title, deleted: r.listing.deletedAt !== null },
    snapshot: r.snapshot as unknown as ReportSnapshot,
  }));

  const body: Paginated<AdminReportDTO> = { items, total, page: q.page, pageSize: q.limit };
  res.json(body);
});

adminRouter.post('/reports/:id/resolve', async (req, res) => {
  const admin = currentUser(req);
  const { status, note } = adminResolveSchema.parse(req.body);
  const id = idOf(req.params.id);
  const r = await prisma.report.updateMany({
    where: { id, status: 'PENDING' },
    data: { status, resolvedById: admin.id, resolvedAt: new Date(), resolutionNote: note ?? null },
  });
  if (r.count === 0) throw badRequest('ไม่พบรายงาน หรือรายงานนี้ถูกจัดการไปแล้ว');
  await prisma.moderationLog.create({
    data: { adminId: admin.id, action: `REPORT_${status}`, reportId: id, note: note ?? null },
  });
  res.json({ ok: true });
});

/* ---------- จัดการประกาศ ---------- */

adminRouter.post('/listings/:id/delete', async (req, res) => {
  const admin = currentUser(req);
  const { reportId } = adminDeleteListingSchema.parse(req.body ?? {});
  const id = idOf(req.params.id);
  const l = await prisma.listing.findUnique({ where: { id } });
  if (!l) throw notFound('ไม่พบประกาศนี้');

  const now = new Date();
  await prisma.$transaction([
    prisma.listing.update({ where: { id }, data: { deletedAt: l.deletedAt ?? now } }),
    // ปิดรายงานที่ค้างอยู่ของประกาศนี้ทั้งหมด
    prisma.report.updateMany({
      where: { listingId: id, status: 'PENDING' },
      data: { status: 'RESOLVED', resolvedById: admin.id, resolvedAt: now, resolutionNote: 'ลบประกาศโดยผู้ดูแลระบบ' },
    }),
    prisma.moderationLog.create({
      data: { adminId: admin.id, action: 'DELETE_LISTING', listingId: id, targetUserId: l.userId, reportId: reportId ?? null },
    }),
  ]);
  res.json({ ok: true });
});

/* ---------- จัดการผู้ใช้ ---------- */

async function manageableUser(targetId: string, adminId: string) {
  const user = await prisma.user.findUnique({ where: { id: targetId } });
  if (!user) throw notFound('ไม่พบผู้ใช้นี้');
  if (user.id === adminId) throw forbidden('ไม่สามารถดำเนินการกับบัญชีของตนเองได้');
  if (user.role === 'ADMIN') throw forbidden('ไม่สามารถดำเนินการกับบัญชีผู้ดูแลระบบได้');
  return user;
}

async function resolveReportIfAny(reportId: string | undefined, adminId: string, note: string) {
  if (!reportId) return;
  await prisma.report.updateMany({
    where: { id: reportId, status: 'PENDING' },
    data: { status: 'RESOLVED', resolvedById: adminId, resolvedAt: new Date(), resolutionNote: note },
  });
}

adminRouter.post('/users/:id/warn', async (req, res) => {
  const admin = currentUser(req);
  const { message, reportId } = adminWarnSchema.parse(req.body);
  const target = await manageableUser(idOf(req.params.id), admin.id);

  await prisma.warning.create({
    data: { userId: target.id, issuedById: admin.id, message, reportId: reportId ?? null },
  });
  await prisma.moderationLog.create({
    data: { adminId: admin.id, action: 'WARN', targetUserId: target.id, reportId: reportId ?? null, note: message },
  });
  await resolveReportIfAny(reportId, admin.id, 'ส่งคำเตือนให้ผู้ใช้');
  res.json({ ok: true });
});

adminRouter.post('/users/:id/ban-temp', async (req, res) => {
  const admin = currentUser(req);
  const { reason, reportId } = adminBanSchema.parse(req.body ?? {});
  const target = await manageableUser(idOf(req.params.id), admin.id);

  const until = new Date(Date.now() + TEMP_BAN_DAYS * 24 * 3600 * 1000);
  await prisma.user.update({
    where: { id: target.id },
    data: { bannedUntil: until, banReason: reason ?? null },
  });
  await prisma.moderationLog.create({
    data: { adminId: admin.id, action: 'BAN_TEMP', targetUserId: target.id, reportId: reportId ?? null, note: reason ?? null },
  });
  await resolveReportIfAny(reportId, admin.id, `แบนชั่วคราว ${TEMP_BAN_DAYS} วัน`);
  res.json({ ok: true, bannedUntil: until.toISOString() });
});

adminRouter.post('/users/:id/ban-permanent', async (req, res) => {
  const admin = currentUser(req);
  const { reason, reportId } = adminBanSchema.parse(req.body ?? {});
  const target = await manageableUser(idOf(req.params.id), admin.id);

  await prisma.user.update({
    where: { id: target.id },
    data: { isPermanentlyBanned: true, banReason: reason ?? null },
  });
  await prisma.moderationLog.create({
    data: { adminId: admin.id, action: 'BAN_PERMANENT', targetUserId: target.id, reportId: reportId ?? null, note: reason ?? null },
  });
  await resolveReportIfAny(reportId, admin.id, 'แบนถาวร');
  res.json({ ok: true });
});

adminRouter.post('/users/:id/unban', async (req, res) => {
  const admin = currentUser(req);
  const target = await manageableUser(idOf(req.params.id), admin.id);
  await prisma.user.update({
    where: { id: target.id },
    data: { isPermanentlyBanned: false, bannedUntil: null, banReason: null },
  });
  await prisma.moderationLog.create({
    data: { adminId: admin.id, action: 'UNBAN', targetUserId: target.id },
  });
  res.json({ ok: true });
});
