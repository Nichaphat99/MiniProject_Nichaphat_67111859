import type { RequestHandler } from 'express';
import rateLimit from 'express-rate-limit';
import { config } from '../config';
import { HttpError } from '../errors';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/** กัน CSRF เพิ่มอีกชั้น: คำขอที่เปลี่ยนข้อมูลต้องมาจาก origin ของเว็บเราเท่านั้น (ถ้ามี header Origin) */
export const originCheck: RequestHandler = (req, _res, next) => {
  if (SAFE_METHODS.has(req.method)) return next();
  const origin = req.headers.origin;
  if (origin && origin !== config.webOrigin) {
    // อนุญาตกรณี same-origin (เช่น serve เว็บจาก Express เอง บน host อื่นที่ไม่ได้ตั้ง WEB_ORIGIN ตรง ๆ)
    const host = req.headers.host;
    let sameHost = false;
    try {
      sameHost = !!host && new URL(origin).host === host;
    } catch {
      /* ignore */
    }
    if (!sameHost) return next(new HttpError(403, 'คำขอไม่ได้รับอนุญาต', 'BAD_ORIGIN'));
  }
  next();
};

const limiter = (windowMinutes: number, max: number, message: string) =>
  rateLimit({
    windowMs: windowMinutes * 60 * 1000,
    limit: max,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { message, code: 'RATE_LIMITED' },
  });

export const globalLimiter = limiter(15, 600, 'ส่งคำขอถี่เกินไป กรุณารอสักครู่');
export const authLimiter = limiter(15, 30, 'พยายามเข้าสู่ระบบบ่อยเกินไป กรุณารอ 15 นาที');
export const createListingLimiter = limiter(60, 30, 'สร้างประกาศบ่อยเกินไป กรุณารอสักครู่');
export const uploadLimiter = limiter(60, 60, 'อัปโหลดรูปบ่อยเกินไป กรุณารอสักครู่');
export const reportLimiter = limiter(60, 20, 'รายงานบ่อยเกินไป กรุณารอสักครู่');
