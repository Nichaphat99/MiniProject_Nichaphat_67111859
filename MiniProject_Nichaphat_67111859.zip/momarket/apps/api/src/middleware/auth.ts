import type { Request, RequestHandler } from 'express';
import type { User } from '@prisma/client';
import { prisma } from '../db';
import { HttpError, forbidden, unauthorized } from '../errors';
import { accountStatus, banMessage } from '../lib/accountStatus';
import { SESSION_COOKIE, clearSession, readSession } from '../lib/session';

declare module 'express-serve-static-core' {
  interface Request {
    user?: User;
  }
}

/** ต้องล็อกอิน + ไม่ถูกแบน — ตรวจสถานะแบนจากฐานข้อมูลทุกคำขอ (โทเค็นเดิมใช้ไม่ได้ทันทีที่ถูกแบน) */
export const requireAuth: RequestHandler = async (req, res, next) => {
  const userId = await readSession(req.cookies?.[SESSION_COOKIE]);
  if (!userId) throw unauthorized();
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    clearSession(res);
    throw unauthorized();
  }
  if (accountStatus(user) !== 'ACTIVE') {
    clearSession(res);
    const info = banMessage(user);
    throw new HttpError(403, info.message, 'BANNED', { permanent: info.permanent, bannedUntil: info.bannedUntil });
  }
  req.user = user;
  next();
};

export const requireAdmin: RequestHandler = (req, _res, next) => {
  if (req.user?.role !== 'ADMIN') throw forbidden('เฉพาะผู้ดูแลระบบเท่านั้น');
  next();
};

export function currentUser(req: Request): User {
  if (!req.user) throw unauthorized();
  return req.user;
}

/** ผู้ดูแลระบบมีหน้าที่ตรวจรายงานเท่านั้น ลงประกาศซื้อขายไม่ได้ */
export const forbidAdmin: RequestHandler = (req, _res, next) => {
  if (req.user?.role === 'ADMIN') {
    throw new HttpError(403, 'ผู้ดูแลระบบไม่สามารถลงประกาศซื้อขายได้ (มีหน้าที่ตรวจสอบรายงานเท่านั้น)', 'ADMIN_CANNOT_SELL');
  }
  next();
};
