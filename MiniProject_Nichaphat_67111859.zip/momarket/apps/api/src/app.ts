import fs from 'node:fs';
import path from 'node:path';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { config } from './config';
import { errorHandler, notFoundHandler } from './errors';
import { globalLimiter, originCheck } from './middleware/security';
import { adminRouter } from './routes/admin';
import { authRouter } from './routes/auth';
import { listingsRouter } from './routes/listings';
import { uploadsRouter } from './routes/uploads';
import { usersRouter } from './routes/users';
import { warningsRouter } from './routes/warnings';
import { categoryImagesRouter } from './routes/categoryImages';

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy ? 1 : false);

  app.use(
    helmet({
      // popup ของ Microsoft/Google ต้องคุยกลับหน้าเดิมได้
      crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          'script-src': ["'self'", 'https://accounts.google.com'],
          'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://accounts.google.com'],
          'font-src': ["'self'", 'https://fonts.gstatic.com'],
          'img-src': ["'self'", 'data:', 'blob:', 'https://img.youtube.com', 'https://*.googleusercontent.com'],
          'connect-src': ["'self'", 'https://login.microsoftonline.com', 'https://accounts.google.com'],
          'frame-src': ['https://accounts.google.com'],
          'upgrade-insecure-requests': config.isProd ? [] : null,
        },
      },
    }),
  );
  app.use(cors({ origin: config.webOrigin, credentials: true }));
  app.use(cookieParser());
  app.use(express.json({ limit: '100kb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.use('/api', globalLimiter, originCheck);
  app.use('/api/auth', authRouter);
  app.use('/api/uploads', uploadsRouter);
  app.use('/api/listings', listingsRouter);
  app.use('/api/users', usersRouter);
  app.use('/api/warnings', warningsRouter);
  app.use('/api/category-images', categoryImagesRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api', notFoundHandler);

  // รูปที่อัปโหลด: ชื่อไฟล์เป็น UUID ไม่ซ้ำ จึง cache ได้นาน
  app.use(
    '/uploads',
    express.static(config.uploadDir, {
      maxAge: '30d',
      immutable: true,
      index: false,
      dotfiles: 'deny',
      setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff'),
    }),
  );

  // production: เสิร์ฟเว็บที่ build แล้ว (apps/web/dist) จาก Express ตัวเดียวกัน
  const indexHtml = path.join(config.webDistDir, 'index.html');
  if (fs.existsSync(indexHtml)) {
    app.use(express.static(config.webDistDir, { index: false, maxAge: '1h' }));
    app.use((req, res, next) => {
      if (req.method !== 'GET' || req.path.startsWith('/api') || req.path.startsWith('/uploads')) return next();
      res.sendFile(indexHtml);
    });
  }

  app.use(errorHandler);
  return app;
}
