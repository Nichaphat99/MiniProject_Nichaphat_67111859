import type { ErrorRequestHandler, RequestHandler } from 'express';
import { ZodError } from 'zod';
import type { ApiErrorBody } from '@momarket/shared';

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
    public extra?: Record<string, unknown>,
  ) {
    super(message);
  }
}

export const badRequest = (m: string) => new HttpError(400, m);
export const unauthorized = (m = 'กรุณาเข้าสู่ระบบ') => new HttpError(401, m, 'UNAUTHENTICATED');
export const forbidden = (m = 'คุณไม่มีสิทธิ์ทำรายการนี้') => new HttpError(403, m, 'FORBIDDEN');
export const notFound = (m = 'ไม่พบข้อมูลที่ต้องการ') => new HttpError(404, m, 'NOT_FOUND');

export const notFoundHandler: RequestHandler = (_req, _res, next) => next(notFound('ไม่พบเส้นทางนี้'));

export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  if (err instanceof ZodError) {
    const issues = err.issues.map((i) => ({ path: i.path.join('.'), message: i.message }));
    const body: ApiErrorBody = {
      message: issues[0]?.message ?? 'ข้อมูลไม่ถูกต้อง',
      code: 'VALIDATION',
      issues,
    };
    res.status(400).json(body);
    return;
  }
  if (err instanceof HttpError) {
    const body: ApiErrorBody = { message: err.message, code: err.code, ...err.extra };
    res.status(err.status).json(body);
    return;
  }
  // multer
  if (err?.name === 'MulterError') {
    const msg =
      err.code === 'LIMIT_FILE_SIZE'
        ? 'ไฟล์รูปใหญ่เกินไป (สูงสุด 5MB ต่อรูป)'
        : err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE'
          ? 'อัปโหลดได้สูงสุด 5 รูปต่อครั้ง'
          : 'อัปโหลดไฟล์ไม่สำเร็จ';
    res.status(400).json({ message: msg, code: 'UPLOAD' } satisfies ApiErrorBody);
    return;
  }
  // body-parser: JSON พัง / ใหญ่เกิน
  if (err?.type === 'entity.parse.failed') {
    res.status(400).json({ message: 'รูปแบบข้อมูลไม่ถูกต้อง' } satisfies ApiErrorBody);
    return;
  }
  if (err?.type === 'entity.too.large') {
    res.status(413).json({ message: 'ข้อมูลใหญ่เกินไป' } satisfies ApiErrorBody);
    return;
  }
  console.error(err);
  res.status(500).json({ message: 'เกิดข้อผิดพลาดภายในระบบ' } satisfies ApiErrorBody);
};
