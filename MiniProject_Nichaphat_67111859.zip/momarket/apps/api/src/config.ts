import path from 'node:path';
import { z } from 'zod';

const bool = (def = false) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v === '' ? def : ['1', 'true', 'yes'].includes(v.toLowerCase())));

const emptyToUndef = (v: unknown) => (v === '' ? undefined : v);

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().default(4000),
  WEB_ORIGIN: z.string().url().default('http://localhost:5173'),
  TRUST_PROXY: bool(false),
  DATABASE_URL: z.string().min(1, 'ต้องตั้งค่า DATABASE_URL'),
  SESSION_SECRET: z.string().min(32, 'SESSION_SECRET ต้องยาวอย่างน้อย 32 ตัวอักษร'),
  SESSION_DAYS: z.coerce.number().int().min(1).max(60).default(7),
  ADMIN_EMAILS: z.string().default(''),
  GOOGLE_CLIENT_ID: z.preprocess(emptyToUndef, z.string().optional()),
  MS_CLIENT_ID: z.preprocess(emptyToUndef, z.string().optional()),
  MS_TENANT_ID: z.preprocess(emptyToUndef, z.string().optional()),
  DEV_LOGIN: bool(false),
  UPLOAD_DIR: z.string().default('./uploads'),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error('❌ ค่า environment ไม่ถูกต้อง:');
  for (const i of parsed.error.issues) console.error(`  - ${i.path.join('.')}: ${i.message}`);
  process.exit(1);
}
const env = parsed.data;

export const config = {
  isProd: env.NODE_ENV === 'production',
  port: env.PORT,
  webOrigin: env.WEB_ORIGIN.replace(/\/$/, ''),
  trustProxy: env.TRUST_PROXY,
  sessionSecret: new TextEncoder().encode(env.SESSION_SECRET),
  sessionDays: env.SESSION_DAYS,
  adminEmails: new Set(
    env.ADMIN_EMAILS.split(',')
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean),
  ),
  google: env.GOOGLE_CLIENT_ID ? { clientId: env.GOOGLE_CLIENT_ID } : null,
  microsoft:
    env.MS_CLIENT_ID && env.MS_TENANT_ID
      ? { clientId: env.MS_CLIENT_ID, tenantId: env.MS_TENANT_ID }
      : null,
  // ปิดเสมอใน production ต่อให้ตั้ง DEV_LOGIN=true ก็ตาม
  devLogin: env.DEV_LOGIN && env.NODE_ENV !== 'production',
  uploadDir: path.resolve(env.UPLOAD_DIR),
  webDistDir: path.resolve(import.meta.dirname, '../../web/dist'),
} as const;

if (!config.google && !config.microsoft && !config.devLogin) {
  console.warn('⚠️  ยังไม่ได้ตั้งค่า GOOGLE_CLIENT_ID / MS_CLIENT_ID+MS_TENANT_ID และปิด DEV_LOGIN — จะล็อกอินไม่ได้');
}
