import { OAuth2Client } from 'google-auth-library';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { ALLOWED_EMAIL_DOMAIN, isDpuEmail } from '@momarket/shared';
import { config } from '../config';
import { HttpError } from '../errors';

export interface VerifiedIdentity {
  email: string;
  name: string;
  avatarUrl: string | null;
}

const invalid = (msg = 'ไม่สามารถยืนยันตัวตนได้ กรุณาลองใหม่อีกครั้ง') => new HttpError(401, msg, 'AUTH_FAILED');
const notDpu = () =>
  new HttpError(403, `อนุญาตเฉพาะอีเมล @${ALLOWED_EMAIL_DOMAIN} ของมหาวิทยาลัยธุรกิจบัณฑิตย์เท่านั้น`, 'NOT_DPU_EMAIL');

/* ---------- Google Workspace ---------- */

const googleClient = new OAuth2Client();

export async function verifyGoogle(credential: string): Promise<VerifiedIdentity> {
  if (!config.google) throw new HttpError(503, 'ยังไม่เปิดใช้การเข้าสู่ระบบด้วย Google', 'PROVIDER_DISABLED');
  let payload;
  try {
    const ticket = await googleClient.verifyIdToken({ idToken: credential, audience: config.google.clientId });
    payload = ticket.getPayload();
  } catch {
    throw invalid();
  }
  if (!payload?.email) throw invalid();
  const email = payload.email.toLowerCase();
  // ตรวจทั้งอีเมลที่ยืนยันแล้ว, โดเมนอีเมล และ hosted domain (hd) ของ Google Workspace
  if (payload.email_verified !== true) throw invalid('อีเมลนี้ยังไม่ได้รับการยืนยันจาก Google');
  if (!isDpuEmail(email) || payload.hd !== ALLOWED_EMAIL_DOMAIN) throw notDpu();
  return { email, name: payload.name?.trim() || email.split('@')[0], avatarUrl: payload.picture ?? null };
}

/* ---------- Microsoft 365 / Entra ID ---------- */

let msJwks: ReturnType<typeof createRemoteJWKSet> | null = null;

export async function verifyMicrosoft(idToken: string): Promise<VerifiedIdentity> {
  if (!config.microsoft) throw new HttpError(503, 'ยังไม่เปิดใช้การเข้าสู่ระบบด้วย Microsoft', 'PROVIDER_DISABLED');
  const { clientId, tenantId } = config.microsoft;
  msJwks ??= createRemoteJWKSet(new URL(`https://login.microsoftonline.com/${tenantId}/discovery/v2.0/keys`));
  let payload;
  try {
    // ผูก issuer กับ tenant ของ DPU เท่านั้น — บัญชีจาก tenant อื่นจะไม่ผ่าน
    ({ payload } = await jwtVerify(idToken, msJwks, {
      issuer: `https://login.microsoftonline.com/${tenantId}/v2.0`,
      audience: clientId,
    }));
  } catch {
    throw invalid();
  }
  const raw = (payload.email as string | undefined) ?? (payload.preferred_username as string | undefined);
  if (!raw) throw invalid();
  const email = raw.toLowerCase();
  if (!isDpuEmail(email)) throw notDpu();
  return { email, name: (payload.name as string | undefined)?.trim() || email.split('@')[0], avatarUrl: null };
}
