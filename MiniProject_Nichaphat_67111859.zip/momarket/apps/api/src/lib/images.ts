import { randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { config } from '../config';
import { HttpError } from '../errors';

export async function ensureUploadDir() {
  await fs.mkdir(config.uploadDir, { recursive: true });
}

/**
 * ตรวจว่าเป็นรูปจริง (sharp อ่านไม่ได้ = ปฏิเสธ), หมุนตาม EXIF, ย่อไม่เกิน 1600px,
 * แปลงเป็น WebP (ตัด metadata เช่นพิกัด GPS ออก) แล้วเก็บเป็นชื่อสุ่ม
 */
export async function saveImage(buffer: Buffer): Promise<string> {
  const name = `${randomUUID()}.webp`;
  try {
    await sharp(buffer, { failOn: 'error', limitInputPixels: 50_000_000 })
      .rotate()
      .resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 82 })
      .toFile(path.join(config.uploadDir, name));
  } catch {
    throw new HttpError(400, 'ไฟล์นี้ไม่ใช่รูปภาพที่รองรับ (รองรับ JPG, PNG, WebP)', 'UPLOAD');
  }
  return `/uploads/${name}`;
}
