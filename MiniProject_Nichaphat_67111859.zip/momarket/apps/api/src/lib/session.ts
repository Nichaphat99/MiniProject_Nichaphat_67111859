import type { CookieOptions, Response } from 'express';
import { SignJWT, jwtVerify } from 'jose';
import { config } from '../config';

export const SESSION_COOKIE = 'momarket_session';

const cookieOptions = (): CookieOptions => ({
  httpOnly: true,
  secure: config.isProd,
  sameSite: 'lax',
  path: '/',
});

export async function issueSession(res: Response, userId: string) {
  const token = await new SignJWT({})
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(userId)
    .setIssuedAt()
    .setExpirationTime(`${config.sessionDays}d`)
    .sign(config.sessionSecret);
  res.cookie(SESSION_COOKIE, token, {
    ...cookieOptions(),
    maxAge: config.sessionDays * 24 * 60 * 60 * 1000,
  });
}

export function clearSession(res: Response) {
  res.clearCookie(SESSION_COOKIE, cookieOptions());
}

/** คืน userId หรือ null ถ้าโทเค็นไม่ถูกต้อง/หมดอายุ */
export async function readSession(token: string | undefined): Promise<string | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, config.sessionSecret, { algorithms: ['HS256'] });
    return typeof payload.sub === 'string' ? payload.sub : null;
  } catch {
    return null;
  }
}
