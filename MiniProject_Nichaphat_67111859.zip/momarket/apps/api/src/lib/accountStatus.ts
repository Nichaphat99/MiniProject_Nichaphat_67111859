import type { Prisma } from '@prisma/client';
import type { AccountStatus } from '@momarket/shared';

interface BanFields {
  bannedUntil: Date | null;
  isPermanentlyBanned: boolean;
}

export function accountStatus(u: BanFields, now = new Date()): AccountStatus {
  if (u.isPermanentlyBanned) return 'PERMANENT_BANNED';
  if (u.bannedUntil && u.bannedUntil > now) return 'TEMP_BANNED';
  return 'ACTIVE';
}

/** เงื่อนไข Prisma: เจ้าของประกาศต้องไม่ถูกแบน (ประกาศของคนโดนแบนจะถูกซ่อนจาก feed) */
export function activeOwnerWhere(now = new Date()): Prisma.UserWhereInput {
  return {
    isPermanentlyBanned: false,
    OR: [{ bannedUntil: null }, { bannedUntil: { lte: now } }],
  };
}

export function banMessage(u: BanFields & { banReason?: string | null }) {
  if (u.isPermanentlyBanned) {
    return {
      message: 'บัญชีนี้ถูกแบนถาวร ไม่สามารถเข้าใช้งาน momarket ได้',
      permanent: true,
      bannedUntil: null,
    };
  }
  return {
    message: `บัญชีนี้ถูกแบนชั่วคราวจนถึง ${u.bannedUntil?.toLocaleString('th-TH', {
      timeZone: 'Asia/Bangkok',
      dateStyle: 'long',
      timeStyle: 'short',
    })} น.`,
    permanent: false,
    bannedUntil: u.bannedUntil?.toISOString() ?? null,
  };
}
