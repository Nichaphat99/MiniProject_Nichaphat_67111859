import type { Condition, Listing, Prisma, ServiceAreaType, User } from '@prisma/client';
import {
  BUMP_COOLDOWN_HOURS,
  studentIdFromEmail,
  typeOfSubcategory,
  youtubeThumbnail,
  type ListingCardDTO,
  type ListingDetailDTO,
  type ListingInput,
  type MyListingDTO,
  type PublicUser,
  type ReportSnapshot,
} from '@momarket/shared';

const coverOf = (l: Pick<Listing, 'imageUrls' | 'videoUrl'>): string | null =>
  l.imageUrls[0] ?? youtubeThumbnail(l.videoUrl);

/** ชื่อที่แสดง: ชื่อที่ผู้ใช้ตั้งเอง ถ้ายังไม่ตั้งใช้ชื่อจากบัญชี DPU */
export const effectiveName = (u: Pick<User, 'name' | 'displayName'>): string => u.displayName ?? u.name;

export function toPublicUser(u: Pick<User, 'id' | 'name' | 'displayName' | 'email' | 'avatarUrl'>): PublicUser {
  return { id: u.id, name: effectiveName(u), studentId: studentIdFromEmail(u.email), avatarUrl: u.avatarUrl };
}

export function toCard(l: Listing): ListingCardDTO {
  return {
    id: l.id,
    type: l.type,
    subcategory: l.subcategory,
    title: l.title,
    price: l.price,
    status: l.status,
    meetupLocation: l.meetupLocation,
    coverUrl: coverOf(l),
    bumpedAt: l.bumpedAt.toISOString(),
    createdAt: l.createdAt.toISOString(),
  };
}

export function nextBumpAt(l: Pick<Listing, 'bumpedAt'>, now = new Date()): Date | null {
  const next = new Date(l.bumpedAt.getTime() + BUMP_COOLDOWN_HOURS * 3600 * 1000);
  return next > now ? next : null;
}

export function toMyListing(l: Listing): MyListingDTO {
  return { ...toCard(l), nextBumpAt: nextBumpAt(l)?.toISOString() ?? null };
}

export function toDetail(l: Listing & { user: User }, viewerId: string): ListingDetailDTO {
  return {
    ...toCard(l),
    description: l.description,
    condition: l.condition,
    meetupNote: l.meetupNote,
    contactLine: l.contactLine,
    contactInstagram: l.contactInstagram,
    contactFacebook: l.contactFacebook,
    imageUrls: l.imageUrls,
    videoUrl: l.videoUrl,
    waitDays: l.waitDays,
    trackingUrl: l.trackingUrl,
    ownWorkConfirmed: l.ownWorkConfirmed,
    serviceAreaType: l.serviceAreaType,
    serviceAreaDetail: l.serviceAreaDetail,
    updatedAt: l.updatedAt.toISOString(),
    deletedAt: l.deletedAt?.toISOString() ?? null,
    seller: toPublicUser(l.user),
    isOwner: l.userId === viewerId,
  };
}

/** แปลง input ที่ validate แล้วเป็นข้อมูลสำหรับบันทึกลงตาราง Listing (ฟิลด์ที่ไม่เกี่ยวกับหมวดจะเป็น null) */
export function listingDataFromInput(
  input: ListingInput,
): Omit<Prisma.ListingUncheckedCreateInput, 'userId' | 'id'> {
  let condition: Condition | null = null;
  let waitDays: number | null = null;
  let trackingUrl: string | null = null;
  let ownWorkConfirmed = false;
  let serviceAreaType: ServiceAreaType | null = null;
  let serviceAreaDetail: string | null = null;
  let videoUrl: string | null = null;

  switch (input.subcategory) {
    case 'PROXY_ORDER':
      waitDays = input.waitDays;
      trackingUrl = input.trackingUrl;
      break;
    case 'PHOTOGRAPHY':
      ownWorkConfirmed = true;
      serviceAreaType = input.serviceAreaType;
      serviceAreaDetail = input.serviceAreaDetail ?? null;
      break;
    case 'VIDEO_EDITING':
      ownWorkConfirmed = true;
      videoUrl = input.videoUrl;
      break;
    case 'GRAPHIC_DESIGN':
      ownWorkConfirmed = true;
      break;
    default:
      condition = input.condition;
  }

  return {
    type: typeOfSubcategory(input.subcategory),
    subcategory: input.subcategory,
    title: input.title,
    description: input.description,
    price: input.price,
    condition,
    meetupLocation: input.meetupLocation,
    meetupNote: input.meetupNote ?? null,
    contactLine: input.contactLine ?? null,
    contactInstagram: input.contactInstagram ?? null,
    contactFacebook: input.contactFacebook ?? null,
    imageUrls: input.images,
    waitDays,
    trackingUrl,
    ownWorkConfirmed,
    serviceAreaType,
    serviceAreaDetail,
    videoUrl,
  };
}

export function snapshotOf(l: Listing): ReportSnapshot {
  return {
    type: l.type,
    subcategory: l.subcategory,
    title: l.title,
    description: l.description,
    price: l.price,
    imageUrls: l.imageUrls,
    meetupLocation: l.meetupLocation,
    meetupNote: l.meetupNote,
    contactLine: l.contactLine,
    contactInstagram: l.contactInstagram,
    contactFacebook: l.contactFacebook,
    videoUrl: l.videoUrl,
    trackingUrl: l.trackingUrl,
  };
}
