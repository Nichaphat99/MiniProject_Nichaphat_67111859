import { createApp } from './app';
import { config } from './config';
import { prisma } from './db';
import { ensureUploadDir } from './lib/images';

await ensureUploadDir();

const app = createApp();
const server = app.listen(config.port, () => {
  console.log(`🛒 momarket API พร้อมใช้งานที่ http://localhost:${config.port}  (${config.isProd ? 'production' : 'development'})`);
  if (config.devLogin) console.log('⚠️  DEV_LOGIN เปิดอยู่ — ล็อกอินจำลองด้วยอีเมล @dpu.ac.th ได้ (ห้ามใช้ใน production)');
});

const shutdown = () => {
  server.close(async () => {
    await prisma.$disconnect();
    process.exit(0);
  });
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
