CREATE TABLE "CategoryImage" (
    "subcategory" "Subcategory" NOT NULL,
    "imageUrl" TEXT NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CategoryImage_pkey" PRIMARY KEY ("subcategory")
);
