CREATE TABLE "HeroBannerImage" (
    "id" TEXT NOT NULL,
    "imageUrl" TEXT NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "HeroBannerImage_pkey" PRIMARY KEY ("id")
);
