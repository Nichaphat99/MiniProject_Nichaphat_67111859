-- AlterTable: ชื่อที่ผู้ใช้ตั้งเอง
ALTER TABLE "User" ADD COLUMN     "displayName" TEXT,
ADD COLUMN     "displayNameChangedAt" TIMESTAMP(3);

-- แอดมินที่มีอยู่แล้วไม่ต้องถูกบังคับตั้งชื่อ
UPDATE "User" SET "displayName" = 'ผู้ดูแลระบบ' WHERE "role" = 'ADMIN' AND "displayName" IS NULL;
