/**
 * Seed: สร้างบัญชีแอดมินจาก ADMIN_EMAILS
 * ใส่ --demo เพื่อสร้างผู้ขายและประกาศตัวอย่าง (ไม่มีรูปภาพ จะแสดงภาพ placeholder)
 *
 *   npm run db:seed                  (เฉพาะแอดมิน)
 *   npm run db:seed -- --demo        (แอดมิน + ข้อมูลตัวอย่าง)
 */
import { PrismaClient, type Prisma } from '@prisma/client';

const prisma = new PrismaClient();

const adminEmails = (process.env.ADMIN_EMAILS ?? '')
  .split(',')
  .map((s) => s.trim().toLowerCase())
  .filter(Boolean);

async function main() {
  if (adminEmails.length === 0) console.warn('⚠️  ไม่พบ ADMIN_EMAILS — ข้ามการสร้างแอดมิน');

  for (const email of adminEmails) {
    if (!email.endsWith('@dpu.ac.th')) {
      console.warn(`⚠️  ข้าม ${email} (ต้องเป็น @dpu.ac.th)`);
      continue;
    }
    await prisma.user.upsert({
      where: { email },
      create: { email, name: 'ผู้ดูแลระบบ momarket', displayName: 'ผู้ดูแลระบบ', role: 'ADMIN' },
      update: { role: 'ADMIN' },
    });
    console.log(`✅ แอดมิน: ${email}`);
  }

  if (!process.argv.includes('--demo')) return;

  const seller = await prisma.user.upsert({
    where: { email: 'demo.seller@dpu.ac.th' },
    create: { email: 'demo.seller@dpu.ac.th', name: 'น้องมอ (ตัวอย่าง)', displayName: 'น้องมอ ตัวอย่าง' },
    update: {},
  });

  const base = {
    userId: seller.id,
    meetupLocation: 'โรงอาหาร',
    contactLine: 'momarket.demo',
    imageUrls: [] as string[],
  };

  const demo: Prisma.ListingUncheckedCreateInput[] = [
    { ...base, type: 'PRODUCT', subcategory: 'FOOD', title: 'คุกกี้เนยสด โฮมเมด (กล่อง 6 ชิ้น)', description: 'อบสดใหม่ทุกวัน ไม่ใส่วัตถุกันเสีย', price: 59, condition: 'NEW' },
    { ...base, type: 'PRODUCT', subcategory: 'STATIONERY', title: 'เครื่องคิดเลข Casio fx-991EX', description: 'ใช้งานน้อย สภาพดี แถมเคส', price: 450, condition: 'USED', meetupLocation: 'อาคาร 4' },
    { ...base, type: 'PRODUCT', subcategory: 'CLOTHING', title: 'เสื้อช็อป DPU ไซส์ M', description: 'ใส่ไม่กี่ครั้ง ซักสะอาด', price: 150, condition: 'USED', meetupLocation: 'อาคาร 1' },
    { ...base, type: 'PRODUCT', subcategory: 'HANDMADE', title: 'พวงกุญแจถักไหมพรม', description: 'ทำมือ เลือกสีได้', price: 35, condition: 'NEW', status: 'SOLD' },
    {
      ...base, type: 'SERVICE', subcategory: 'PROXY_ORDER', title: 'รับหิ้วขนมญี่ปุ่นจาก Don Don Donki', description: 'รอบหิ้วทุกเดือน ค่าหิ้วชิ้นละ 20 บาท',
      price: 20, waitDays: 7, trackingUrl: 'https://line.me/ti/g2/demo', meetupLocation: 'ลานจอดรถ',
    },
    {
      ...base, type: 'SERVICE', subcategory: 'PHOTOGRAPHY', title: 'ถ่ายภาพรับปริญญา / พอร์ตโฟลิโอ', description: 'ช่างภาพนักศึกษา อุปกรณ์ครบ ส่งงานใน 3 วัน',
      price: 800, ownWorkConfirmed: true, serviceAreaType: 'ON_CAMPUS', meetupLocation: 'DPU Place',
    },
    {
      ...base, type: 'SERVICE', subcategory: 'VIDEO_EDITING', title: 'ตัดต่อวิดีโอรายงาน / คลิปสั้น', description: 'ตัดต่อ ใส่ซับ เสียงดนตรี',
      price: 300, ownWorkConfirmed: true, videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', meetupLocation: 'อาคาร 22',
    },
    {
      ...base, type: 'SERVICE', subcategory: 'GRAPHIC_DESIGN', title: 'ออกแบบโปสเตอร์ / โลโก้ / พรีเซนต์', description: 'แก้ไขได้ 2 รอบ',
      price: 250, ownWorkConfirmed: true, meetupLocation: 'อาคารเกตุพิทักษ์',
    },
  ];

  const existing = await prisma.listing.count({ where: { userId: seller.id } });
  if (existing > 0) {
    console.log('ℹ️  มีข้อมูลตัวอย่างอยู่แล้ว ข้าม');
    return;
  }
  await prisma.listing.createMany({ data: demo });
  console.log(`✅ สร้างประกาศตัวอย่าง ${demo.length} รายการ`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
